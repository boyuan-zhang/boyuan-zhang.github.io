function saveas_eps(fig,savefilename)
% save file as eps
saveas(fig, savefilename, 'psc2');

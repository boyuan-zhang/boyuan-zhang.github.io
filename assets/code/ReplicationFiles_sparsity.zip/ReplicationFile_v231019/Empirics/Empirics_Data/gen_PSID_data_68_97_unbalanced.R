# =========================================================================== #
# Generate PSID data from the scratch (raw dataset)
# =========================================================================== #
# Creation: 03/25/2021
# Last modification: 10/24/2023
# Version: unbalanced
# =========================================================================== #
# Notes: 
# (1) we don't have to download the packaged data from PSID website, as package
#     psidR will download them if we don't have them locally.
# 
# (2) function build.panel automatically includes the interview ID in 1968
#
# (3) what to prepare: a table of variable names in each year.
#     https://simba.isr.umich.edu/DC/s.aspx
#     or use function getNamesPSID once you know some of them in a certain year.
#
# (4) Github: https://github.com/floswald/psidR
# =========================================================================== #

# Clear workspace 
rm(list = ls())
graphics.off()

# packages
library(psidR) # https://github.com/floswald/psidR
library(data.table)
library(readxl)
library(tidyverse)
library(haven)
library(tidyr)
library(xtable)
library(dplyr)
library(lubridate)

# working directory
wd = '~/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/'
setwd(wd)

paths = list(data = "Empirics_Data")

paths$raw_data = paste0(paths$data, '/psid_raw/')
dir.create(file.path(paths$raw_data), showWarnings = FALSE)

paths$panel_unbal = paste0(paths$data, '/data_unbalanced/')
dir.create(file.path(paths$panel_unbal), showWarnings = FALSE)

# =========================================================================== #
#  1. load in variable names
# =========================================================================== #

# variables to be retrieved from family files.
f = read.csv( paste0(paths$data,'/famvars_68_97.csv'))

# variables to be retrieved from individual files.
i = read.csv( paste0(paths$data,'/indvars_68_97.csv'))

# we retrieve a unbalanced panel for heads only in all samples including SRC, SEO, immegrant and latino.
# this function download raw data from PSID database; need to sign in PSID account
# the download process may take around 50 minutes for the first time
d = build.panel(datadir = paths$raw_data, fam.vars = f, ind.vars = i, heads.only = TRUE, sample = 'NULL', design = "all")

# summary(d)



# extra variables:
# interview: the variables interview number in each family file map to the interview number variable of a given year in the individual file.
# ID1968 (ER30001): Family identifier
# pernum (ER30002): Personal identifier
# pid: the variable pid is the unique person identifier, constructed from ID1968 and pernum.




# =========================================================================== #
#  2. data cleaning
# =========================================================================== #

colnames(d)

psid_clean = 
  d %>%
  select(-interview, -pernum, -sequence, -relation.head) %>%
  arrange(pid, year, age) %>%
  relocate(pid, year) %>%
  filter(!ID1968 %in% c(5000:6999, 7000:9308)) %>% # SEO: 5000-6999, Immigrant: 3000-4999, Latino: 7000 - 9308
  filter(sex == 1) %>% # drop female head
  filter(self == 1) %>% # We eliminate those with a spell of self-employment over the sample period, 1: work for someone else only
  filter(empstat %in% 1:3) %>% # we keep those obs that are in the labor force
  filter(race != 9) %>% # remove missing value
  filter(!marit %in% 8:9) %>% # remove missing value (9), and unknown code (8)
  filter(!region %in% c(6,9)) %>% # remove missing value (9), and Foreign country (6)
  filter(state %in% 1:51) %>% # remove outside US head
  filter(((!educ %in% c(9,99)) & (!edu_year %in% c(99)))) %>% # missing education information (edu_year does not exclude obs of 0 or 99)
  relocate(educ, .after = edu_year) %>% # put education variables together
  filter(laby > 0) # positive income

# create unique individual IDs, replace pid
psid_clean$newid = psid_clean %>% group_by(pid) %>% group_indices(pid)

psid_clean = as.data.frame(psid_clean)







# =========================================================================== #
#  3. correct inconsistent age
# =========================================================================== #

# calculate mode
getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

# individual ID
list.id = unique(psid_clean$pid)
n.id    = length(list.id)

psid_clean$age2 = psid_clean$age
psid_clean = as.data.frame(psid_clean)

# double check age (someone had type, such as duplicated age)
for (i in 1:n.id){
  
  temp.pos = which(psid_clean$pid == list.id[i])
  temp = psid_clean[temp.pos, ]
  
  # if there is no error in age, go to next
  if ( all(diff(temp$age) == 1) ) next
  
  # if there is error(s)
  # psid_clean[temp.pos, 'age2'] = as.numeric( psid_clean[temp.pos[1], 'age']  - psid_clean[temp.pos[1], 'year'] ) + psid_clean[temp.pos, 'year']
  psid_clean[temp.pos, 'age2'] = temp$year + getmode(temp$age - temp$year)
  
}

# lots of mismatches...
table(psid_clean$age2 - psid_clean$age)

# remove age and use age2
psid_clean$age = psid_clean$age2


psid_clean = 
  psid_clean %>%
  relocate(newid) %>% # move newid to the first
  select(-age2, -pid, -self) %>% # drop useless variable 
  filter(age %in% 25:55) # keep who aged 25 to 55 over this period








# =========================================================================== #
#  4. create education group
# =========================================================================== #

psid_clean = 
  psid_clean %>% 
  mutate(edu_grp = case_when(
    # for year 68-90 (10 levels)
    educ %in% 0:3 & year <= 1990 ~ 1, # High School dropouts: (those with less than 12 grades of schooling)
    educ %in% 4:6 & year <= 1990 ~ 2, # High School graduates (those with at least a High School diploma, but no College degree)
    educ %in% 7:8 & year <= 1990 ~ 3,  # College graduates (those with a College degree or more)
    # for year 68-90 (10 levels), but NA in educ (educ = 9)
    educ == 9 & year <= 1990 & edu_year %in% 1:11 ~ 1, # High School dropouts: (those with less than 12 grades of schooling)
    educ == 9 & year <= 1990 & edu_year %in% 12:15 ~ 2, # High School graduates (those with at least a High School diploma, but no College degree)
    educ == 9 & year <= 1990 & edu_year %in% 16:17 ~ 3,  # College graduates (those with a College degree or more)
    # for year 91-93 (actual years)
    educ < 12 & year > 1990 ~ 1, # High School dropouts: (those with less than 12 grades of schooling)
    educ %in% 12:15 & year > 1990 ~ 2, # High School graduates (those with at least a High School diploma, but no College degree)
    educ %in% 16:17 & year > 1990 ~ 3,  # College graduates (those with a College degree or more)
    # for year 94- (actual years)
    educ == 99 & year > 1993 & edu_year %in% 1:11 ~ 1, # High School dropouts: (those with less than 12 grades of schooling)
    educ == 99 & year > 1993 & edu_year %in% 12:15 ~ 2, # High School graduates (those with at least a High School diploma, but no College degree)
    educ == 99 & year > 1993 & edu_year %in% 16:17 ~ 3  # College graduates (those with a College degree or more)
  ))









# =========================================================================== #
#  5. create experience
# =========================================================================== #

aggregate(edu_year ~ newid, data = psid_clean, FUN = function(x) unique(x))

# all missing values in edu_year are due to the lost of related variable for year 1969
sum(which(is.na(psid_clean$edu_year)) - which(psid_clean$year == 1969)) # = 0


# individual ID
list.id = unique(psid_clean$newid)

# impute NA and 0 with mode
for (i in list.id) {
  
  temp.pos = which(psid_clean$newid == i)
  
  if ( any(psid_clean[temp.pos, "edu_year"] > 0, na.rm = T) ) { # if edu_year is available for some years
    
    temp.mode = getmode(psid_clean[temp.pos[!psid_clean[temp.pos, "edu_year"] %in% c('NA', 0)], "edu_year"])
    psid_clean[temp.pos, "edu_year"] = temp.mode
  }
}

table(psid_clean$edu_year)

# there are some NA left since those individuals don't have edu_year available in other years
sum(is.na(psid_clean$edu_year))

# drop obs with edu_year = 0 or NA
psid_clean = 
  psid_clean %>%
  filter((!edu_year %in% c(0, NA)))



# Create experience
# psid_clean$exp = psid_clean$age - sapply(psid_clean$edu_year, function(x) max(x, 12)) - 6 # Follow Gu and Koenker (2017), p.8
psid_clean$exp = psid_clean$age - psid_clean$edu_year - 6







# =========================================================================== #
#  6. check hourly wage and wage
# =========================================================================== #

# impute NA in avgh = laby / hour
psid_clean$avhy[is.na(psid_clean$avhy)] = psid_clean$laby[is.na(psid_clean$avhy)] / psid_clean$hour[is.na(psid_clean$avhy)]





# =========================================================================== #
#  7. load in PCE deflector and adjust for inflation
# =========================================================================== #

price = read.csv( paste0(paths$data,'/PCE.csv'))
price$DATE = as.Date(price$DATE, format = '%m/%d/%Y')

price = 
  price %>%
  mutate(year = year(DATE) + 1) %>% # use +1 because PSID data is for previous year 
  select(-DATE) %>%
  relocate(year) %>%
  rename(price = PCE)

# base year = 1992 (+1 for PSID data)
bm_price = price$price[price$year == 1993]

# merge price level
psid_clean = left_join(psid_clean, price, by = 'year')

# adjust for inflation and calculate log real earning
psid_clean$ly = log(psid_clean$laby/psid_clean$price*bm_price)

# eliminate observations with outlying earnings records
psid_clean = psid_clean %>% group_by(newid) %>% 
  mutate(d_ly = c(0, diff(ly))) %>% 
  mutate(bad_ly = as.numeric(d_ly > 2 | d_ly < -1)) %>% 
  filter(bad_ly == 0) %>%
  group_by(newid) %>% mutate(nobs = n()) # count the number of obs for each head

psid_clean$year = psid_clean$year - 1900 - 1 # -1 because the labor income is for previous year

psid_clean = as.data.frame(psid_clean)






# =========================================================================== #
#  8. first stage regression
# =========================================================================== #

stage1.reg = lm(ly ~ -1 + factor(year) + factor(race) + factor(edu_grp) + factor(region) + factor(marit), data = psid_clean)
summary(stage1.reg)
anova(stage1.reg)

# use the residuals
psid_clean$resid = resid(stage1.reg)




# =========================================================================== #
#  9. construct unbalanced sample
# =========================================================================== #

# create a panel data
temp_smpl = psid_clean[,c('newid','year','ly')]
data_wide = spread(temp_smpl, year, ly) # row = newid, col = year, value = log income
data_wide = as.data.frame(data_wide)
rownames(data_wide) = data_wide$newid
data_wide = data_wide[,-1]


# find consecutive obs for each unit
n.period = ncol(data_wide)
n.ind    = nrow(data_wide)

select_id = data_wide * NA
# rownames(select_id) = 1:nrow(select_id)

### Procedure to select HH
n.obs.required = 9

# select consecutive period for each ind
for (i in 1:n.ind){
  # i = 84
  temp_data = as.numeric(data_wide[i,])
  temp_in   = cumsum(is.na(temp_data))
  split_list = split(na.omit(temp_data), temp_in[!is.na(temp_data)])
  
  if (is_empty(split_list) == FALSE) {

    # lengths of each piece of consecutive obs
    len_list = lengths(split_list)
    
    # final pick
    pick_list = which(len_list >= n.obs.required)
    
    # pick the longest or nearest
    if (length(pick_list) > 1) { 
      if (len_list[1] > len_list[2]) {
        pick_list = 1
      } else if (len_list[1] < len_list[2]) {
        pick_list = 2
      } else { # at par, choose the nearest
        pick_list = 2
      }
    }
  
    select_id[i, temp_in == names(split_list[pick_list])] = as.logical(1)
  }
}


# find the newid and year for the final sample
valid_id = as.data.frame(which(select_id == 1, arr.ind = T))
valid_id$row = as.numeric(row.names(select_id)[valid_id$row])
valid_id$col = as.numeric(colnames(select_id)[valid_id$col])
colnames(valid_id) = c('newid','year')

## create final sample; version 1: no NA
final_smpl = left_join(valid_id, psid_clean, by = c('newid' = 'newid', 'year' = 'year')) %>%
  select('newid','year','resid','empstat','exp') %>% 
  arrange(year, newid)


# save table
write.table(final_smpl,
            file = paste0(paths$panel_unbal, "unbalanced_data.txt"),
            row.names = FALSE, col.names = FALSE)


## create final sample; version 2: include NA

# full list
newid_list = sort(unique(final_smpl$newid))
year_list  = sort(unique(final_smpl$year))

expand_list = expand.grid(newid_list, year_list)
colnames(expand_list) = c('newid', 'year')

final_smpl2 = left_join(expand_list, final_smpl, by = c('newid' = 'newid', 'year' = 'year')) %>%
  arrange(year, newid)


# save table
write.table(final_smpl2,
            file = paste0(paths$panel_unbal, "unbalanced_data_incl_NA.txt"),
            row.names = FALSE, col.names = FALSE)


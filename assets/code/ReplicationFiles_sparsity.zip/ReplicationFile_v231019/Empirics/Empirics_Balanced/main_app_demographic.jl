####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Empirical Analysis, unbalanced Panel
#####################################################################################################

#* This script generates histograms of demographic characteristics of units in balanced sample (figure 8)

####################################################################################################
#                             Part 0: INTRO
####################################################################################################

cd()
wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Balanced/"
cd(wd)

version = "_balanced"

wd_data = string(wd, "data", version, "/")

# directory of posterior draw
wd_jld = string(wd, "Estimates/M2/jld_temp/")

# directory of 
wd_plots = string(wd, "Plots/")
# create folder for posterior hpdi
wd_demo = string(wd_plots, "Core_Demo/")
if !isdir(wd_demo)
   mkdir(wd_demo)
end

# load packages (install them with Pkg.add() if needed)
using JLD2, Distributions, StatisticalRethinking, DelimitedFiles, Random, Colors
using Plots, StatsPlots
using PlotlyJS, DelimitedFiles, Plots, JLD2, Distributions, StatsPlots, StatisticalRethinking




####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# starting year
yr0 = 91

# long panel (T = 25)
T = 20
T2 = T + 2
# select indiividuals
label = "T$(T)_tau$(yr0)_"
println("Load dataset: ", label)

# load the data
raw = readdlm(string(wd_data, label, "data.txt"), ' ')

id = round.(Int, unique(raw[:,1]))
N  = length(id)

Y = zeros(T2, N)
h = zeros(T2, N)
for t = 1:T2
   for i = 1:N
      selected = (abs.(raw[:,1] .- id[i]) .< 0.05) .& (abs.(raw[:,2] .- (yr0-T2+t)) .< 0.05)
      Y[t,i] = raw[selected, 3][1]
      h[t,i] = raw[selected, 5][1]
   end
end

# in-sample observations
Y_is = Y[2:(end-1), :]

# out-of--sample observations
Y_oos = Y[end, :]


# load posterior draws in JLD2 file
label_est = "T$(T)_tau$(yr0)_"
temp = load(wd_jld * "$(label_est)output.jld2")
post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

# create a vector of color for core group and deviator
id_deviator = collect(1:N)[median(post_draw_ss_hetsk.delta_alpha_draw, dims = 1)[1,:,:]'[:,1] .!= 0]
id_core     = setdiff(1:N, id_deviator)


# load demographic information 
raw_demo = readdlm(string(wd_data, label, "data_demographic.txt"), ' '; header = true)
raw_demo_data = raw_demo[1]
raw_demo_col  = raw_demo[2][1,:]




####################################################################################################
#                             Part 2: DRAW FIGURES
####################################################################################################

# age
select_col_id = 2
select_col = Int.(raw_demo_data[:,select_col_id])

fig = PlotlyJS.plot(
    [
     PlotlyJS.histogram(x = raw_demo_data[id_deviator,select_col_id],
               histnorm = "probability density",
               name = "deviator",
               xbins_start = minimum(select_col),
               xbins_end = maximum(select_col),
               xbins_size = 1,
               marker_color = "#009BFA",
               opacity = 0.75),

     PlotlyJS.histogram(x = raw_demo_data[id_core,select_col_id],
               histnorm = "probability density",
               name = "core",
               xbins_start = minimum(select_col),
               xbins_end = maximum(select_col),
               xbins_size = 1,
               marker_color = "#E36F47",
               opacity = 0.75)
    ],
    Layout(title = "", 
          plot_bgcolor = "white",
          yaxis = attr(showline=true, linewidth=1, linecolor="black", mirror=true),
          xaxis = attr(showline=true, linewidth=1, linecolor="black", mirror=true,
                       tickvals = minimum(select_col)+0.5:1:maximum(select_col)-0.5,
                       ticktext = minimum(select_col):1:maximum(select_col)-1),
          bargap = 0.2,
          legendfontsize=14,
          width = 300, height = 200, dpi = 600,
          margin = attr(l=5,r=5,t=20,b=20),
          legend = attr(x=0.02, y=0.97,orientation="v",
                    # font=attr(size=10),
                    bordercolor="Black",
                    borderwidth= 0.5))
)

PlotlyJS.savefig(fig, wd_demo * "fig_emp_dev_vs_core_age_T$(T)_tau$(yr0).png", width = 300, height = 200, scale = 3)



# edu_year
select_col_id = 12
select_col = Int.(raw_demo_data[:,select_col_id])

trace1 = PlotlyJS.histogram(x = select_col[id_deviator],
          histnorm = "probability",
          name = "deviator",
          xbins_start = minimum(select_col),
          xbins_end = maximum(select_col),
          xbins_size = 1,
          marker_color = "#009BFA",
          opacity = 0.75)

trace2 = PlotlyJS.histogram(x = select_col[id_core],
          histnorm = "probability",
          name = "core",
          xbins_start = minimum(select_col),
          xbins_end = maximum(select_col),
          xbins_size = 1,
          marker_color = "#E36F47",
          opacity = 0.75)

layout =  Layout(title = "", 
          # xaxis_title = "Age", 
          # yaxis_title = "Shares",
          plot_bgcolor = "white",
          yaxis = attr(showline=true, linewidth=1, linecolor="black", mirror=true),
          xaxis = attr(showline=true, linewidth=1, linecolor="black", mirror=true,
                         tickvals = minimum(select_col)+0.5:1:maximum(select_col)-0.5,
                         ticktext = minimum(select_col):1:maximum(select_col)-1),
          bargap = 0.2,
          legendfontsize=14,
          width = 300, height = 200, dpi = 600,
          margin = attr(l=5,r=5,t=20,b=20),
          legend = attr(x=0.02, y=0.97,orientation="v",
                    # font=attr(size=10),
                    bordercolor="Black",
                    borderwidth= 0.5))

fig = PlotlyJS.plot([trace1, trace2], layout)

PlotlyJS.savefig(fig, wd_demo * "fig_emp_dev_vs_core_edu_year_T$(T)_tau$(yr0).png", width = 300, height = 200, scale = 3)







# average of hourly earnings
select_col_id = 18
select_col = raw_demo_data[:,select_col_id]

bin_size = 2
bin_list = collect(floor(minimum(select_col)):bin_size:ceil(maximum(select_col)))
bin_list_2plot = (bin_list[2:end] + bin_list[1:end-1])/2
pushfirst!(bin_list_2plot, floor(minimum(select_col)))
push!(bin_list_2plot, ceil(maximum(select_col)))

bin_share = fit(Histogram,select_col[id_core],bin_list,closed = :left).weights/length(select_col[id_core])
pushfirst!(bin_share, bin_share[1])
push!(bin_share, bin_share[end])

trace1 = PlotlyJS.histogram(x = select_col[id_deviator],
          histnorm = "probability",
          name = "deviator",
          xbins_start = floor(minimum(select_col)),
          xbins_end = ceil(maximum(select_col)),
          xbins_size = bin_size,
          marker_color = "#009BFA",
          opacity = 0.75)

trace3 = PlotlyJS.scatter(x = bin_list_2plot, 
          y = bin_share,
          name = "core",
          marker_color = "#E36F47",
          opacity = 0.75)


layout = Layout(title = "", 
          # xaxis_title = "Age", 
          # yaxis_title = "Shares",
          plot_bgcolor = "white",
          yaxis = attr(showline=true, linewidth=1, linecolor="black", mirror=true, range = [0,0.3]),
          xaxis = attr(showline=true, linewidth=1, linecolor="black", mirror=true),
          # xaxis = attr(showline=true, linewidth=1, linecolor="black", mirror=true,
          #      tickvals = x_tickvals,
          #      ticktext = x_ticktext),
          bargap = 0.2,
          legendfontsize=14,
          width = 300, height = 200, dpi = 600,
          margin = attr(l=5,r=5,t=20,b=20),
          legend = attr(x=0.62, y=0.97,orientation="v",
                    # font=attr(size=10),
                    bordercolor="Black",
                    borderwidth= 0.5))

fig = PlotlyJS.plot([trace1,trace3], layout)

PlotlyJS.savefig(fig, wd_demo * "fig_emp_dev_vs_core_avg_avhy_T$(T)_tau$(yr0).png", width = 300, height = 200, scale = 3)






# std of income 
select_col_id = 15
select_col = raw_demo_data[:,select_col_id]

bin_size = 0.05
bin_list = collect(floor(minimum(select_col); digits = 2):bin_size:ceil(maximum(select_col); digits = 2))
bin_list_2plot = (bin_list[2:end] + bin_list[1:end-1])/2
pushfirst!(bin_list_2plot, floor(minimum(select_col); digits = 2))
push!(bin_list_2plot, ceil(maximum(select_col); digits = 2))

bin_share = fit(Histogram,select_col[id_core],bin_list,closed = :left).weights/length(select_col[id_core])
pushfirst!(bin_share, bin_share[1])
push!(bin_share, bin_share[end])

trace1 = PlotlyJS.histogram(x = select_col[id_deviator],
          histnorm = "probability",
          name = "deviator",
          xbins_start = floor(minimum(select_col)),
          xbins_end = ceil(maximum(select_col)),
          xbins_size = bin_size,
          marker_color = "#009BFA",
          opacity = 0.75)

trace2 = PlotlyJS.scatter(x = bin_list_2plot, 
          y = bin_share,
          name = "core",
          mode = "lines",
          marker_color = "#E36F47",
          opacity = 0.75)


layout = Layout(title = "", 
          plot_bgcolor = "white",
          yaxis = attr(showline=true, linewidth=1, linecolor="black", mirror=true, range = [0,0.32]),
          xaxis = attr(showline=true, linewidth=1, linecolor="black", mirror=true),
          bargap = 0.2,
          legendfontsize=14,
          width = 300, height = 200, dpi = 600,
          margin = attr(l=5,r=5,t=20,b=20),
          legend = attr(x=0.62, y=0.97,orientation="v",
                    # font=attr(size=10),
                    bordercolor="Black",
                    borderwidth= 0.5))

fig = PlotlyJS.plot([trace1,trace2], layout)

PlotlyJS.savefig(fig, wd_demo * "fig_emp_dev_vs_core_std_income_residual_T$(T)_tau$(yr0).png", width = 300, height = 200, scale = 3)
####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Content: This file contains helpers functions used in the empirical application
#  Author: Boyuan Zhang
#  Creation: 03/15/2022
#  Last change: 04/27/2023
#####################################################################################################

##################################################################################
# auxiliary functions
function kalman_filter(y, Psi_i0, Psi_i1, Phi_i1, sigma2_u_it, sigma2_e_it, s00, P00)
    # Kalman filtering

    #? Model:
    #? y_it = Psi_i0 + Psi_i1 * s_it + u_it,  u_it ~ N(0, Σ^u_it)
    #? s_it = Phi_i1 * s_it-1 + e_it,       e_it ~ N(0, Σ^e_it)

    #! Initial conditions:
    #! s00 = E(s_0|y0),  P00 = var(s_0|y0)

    #* Dimensions:
    #* y: T x N. Psi_i0: T x N. Psi_i1: N x 1. Phi_i1: N x Ns. 
    #* sigma2_u_it: T x N. sigma2_u_it: T x N.
    #* s00: 1 x 1;  P00: Ns x Ns

    # i = 1
    # Psi_i0 = zeros(T, N)
    # for ii in 1:N
    #     Psi_i0[:,ii] = H[:,ii,:] * delta_alpha_draw[i, :,ii]
    # end
    # Psi_i1 = ones(N,1)
    # Phi_i1 = rho_draw[i] .+ delta_rho_draw[i,:]
    # sigma2_u_it = kron(sigma2_u_draw[i,:], delta_sigma_u_draw[i,:]') # T x N
    # sigma2_e_it = kron(sigma2_e_draw[i,:], delta_sigma_e_draw[i,:]') # T x N
    # s00 = 0
    # P00 = eta
    
    # y = y_all
    # Psi_i0 = zeros(T, N)
    # for ii in 1:N
    #     Psi_i0[:,ii] = H[:,ii,:] * delta_alpha[:,ii]
    # end
    # Psi_i1 = ones(N,1)
    # Phi_i1 = theta.rho .+ delta_rho
    # sigma2_u_it = kron(sigma2_u, delta_sigma_u_draw[i,:]') # T x N
    # sigma2_e_it = kron(sigma2_e, delta_sigma_e_draw[i,:]') # T x N
    # s00 = 0
    # P00 = eta

    # housekeeping
    T, N = size(y)

    # t | t-1
    s_fore = zeros(T, N)
    P_fore = zeros(T, N)

    # t | t
    s_update = zeros(T, N)
    P_update = zeros(T, N)

    F = zeros(T, N)
 
    #  Kalman Filter
    for i in 1:N

        for t in 1:T

            # Prediction
            if t == 1
                s_fore[t, i] = Phi_i1[i] * s00
                P_fore[t, i] = Phi_i1[i] * P00 * Phi_i1[i]' + sigma2_e_it[t, i]
            else
                s_fore[t, i] = Phi_i1[i] * s_update[t-1, i]
                P_fore[t, i] = Phi_i1[i] * P_update[t-1, i] * Phi_i1[i]' + sigma2_e_it[t, i]
            end

            P_fore[t, i] = P_fore[t, i].*(abs(P_fore[t, i])>1e-10);

            # Updating
            F[t, i] = Psi_i1[i] * P_fore[t, i] * Psi_i1[i]' + sigma2_u_it[t, i]

            s_update[t, i] = s_fore[t, i] + P_fore[t, i] * Psi_i1[i]' * F[t, i]^-1 * (y[t, i] - Psi_i0[t, i] - Psi_i1[i] * s_fore[t, i])
            P_update[t, i] = P_fore[t, i] - P_fore[t, i] * Psi_i1[i]' * F[t, i]^-1 * Psi_i1[i] * P_fore[t, i]'

            P_update[t, i] = P_update[t, i].*(abs(P_update[t, i])>1e-10);
        end

    end

    return s_fore, P_fore, s_update, P_update
 
end
 


function simulation_smoother(P_fore, s_update, P_update, Phi_i1, s00, P00)
    # Kalman smoother

    T, N = size(P_fore)

    s_draw_temp  = zeros(T, N)
    s0_draw_temp = zeros(N, 1)

    # Loop Parallelization with @threads
    Threads.@threads for i = 1:N
        for t = T:-1:0
            if t == T
                s_draw_temp[t, i] = rand(Normal(s_update[t, i], sqrt(P_update[t, i])))
            elseif t == 0
                s_back = s00 + P00 * Phi_i1[i]' * P_fore[t+1, i]^-1 * (s_draw_temp[t+1, i] - Phi_i1[i] * s00)
                P_back = P00 - P00 * Phi_i1[i]' * P_fore[t+1, i]^-1 * Phi_i1[i] * P00
                P_back = P_back.*(abs(P_back)>1e-10);
                s0_draw_temp[i] = rand(Normal(s_back, sqrt(P_back)))
            else
                s_back = s_update[t, i] + P_update[t, i] * Phi_i1[i]' * P_fore[t+1, i]^-1 * (s_draw_temp[t+1, i] - Phi_i1[i] * s_update[t, i])
                P_back = P_update[t, i] - P_update[t, i] * Phi_i1[i]' * P_fore[t+1, i]^-1 * Phi_i1[i] * P_update[t, i]
                P_back = P_back.*(abs(P_back)>1e-10);
                s_draw_temp[t, i] = rand(Normal(s_back, sqrt(P_back)))
            end
        end
    end

    return s0_draw_temp, s_draw_temp
 end
 








 function direct_draw_S(y, Psi_i0, rho_i, sigma2_u_it, sigma2_e_it, s0_var)
    # Given delta-alpha, draw S

    T, N = size(y)
    # s0_var = s0_var_draw[i]

    # covarance matrix for s
    var_s = zeros(T,N)
    for t = 1:T
        if t == 1
            var_s[t,:] = rho_i.^2 * s0_var .+ sigma2_e_it[t,:]
        else
            var_s[t,:] = rho_i.^2 .* var_s[t-1,:] .+ sigma2_e_it[t,:]
        end
    end

    cov_s = zeros(T, T, N)
    for t1 = 1:T
        for t2 = t1:T
            tm = min(t1, t2)
            h  = abs(t1-t2)
            cov_s[t1, t2, :] = rho_i.^h .* var_s[tm,:]
            cov_s[t2, t1, :] = cov_s[t1, t2, :]
        end
    end

    # covarance matrix for y
    cov_y = copy(cov_s)
    for ii in 1:N
        cov_y[:,:,ii] = cov_y[:,:,ii] + diagm(sigma2_u_it[:,ii])
    end

    cov_sy = copy(cov_s)

    # mean of s
    post_mean_s = [cov_sy[:,:,ii] * inv(cov_y[:,:,ii]) * (y[:,ii] - Psi_i0[:,ii]) for ii in 1:N]
    post_mean_s = reduce(vcat,transpose(post_mean_s))'

    # covariance of s
    post_cov_s = [cov_s[:,:,ii] - cov_sy[:,:,ii] * inv(cov_y[:,:,ii]) * cov_sy[:,:,ii]' for ii in 1:N]

    for ii in 1:N
        post_cov_s[ii] = 0.5*(post_cov_s[ii] + post_cov_s[ii]')
    end

    return post_mean_s, post_cov_s
end
 




 
function cov2cor(x)
    # convert covariance matrix to correlation matrix

    N = size(x,1)
    x2 = copy(x)
    for i in 1:N
        for j in 1:N
            x2[i,j] = x[i,j] / sqrt(x[i,i]*x[j,j])
        end
    end
    return x2
end
 





function make_symmetric(x)
    # make matrix symmetric and remove tiny elements

    y = 0.5*(x + x')
    y = y.*(abs.(y) .> 1e-10)
    return (y)
end





function robust_var(x)
    # Robust estimator for x, see Geweke (1999)

    bw = Int(floor(0.08*length(x)))

    cov_mat = zeros(bw,1)
    for i = 1:bw
        cov_mat[i] = autocov(x,[i-1])[1]
    end

    weight = ones(bw,1)
    weight[2:end] = 2*collect(1 .- (1:bw-1)/bw)

    rob_var = cov_mat' * weight

    return rob_var[1]
end




function inv_chol(x) 
    # calculate matrix inversion using cholesky decomp

    inv_x = LinearAlgebra.inv!(cholesky!(x))
    # inv_x = inv_x.*(abs.(inv_x) .> 1e-10)
    return inv_x
end


function cummean(x)
    # calculate cumulative mean
    
    results = cumsum(x) ./ (1:length(x))
    return results
end


# find the position of first nonNAN entry of consecutive obs
find_first_nonNA(x) = findfirst(.!isnan.(x))

# find the position of last nonNAN entry of consecutive obs
find_last_nonNA(x) = findlast(.!isnan.(x))


####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Empirical Analysis, Balanced Panel
#  Creation: 11/29/2019
#  Last change: 10/24/2024
#####################################################################################################

#* Version: balanced panels, M2-HIP

####################################################################################################
#                             Part 0: INTRO
####################################################################################################
cd()

using Distributed
rmprocs(workers())

#Add workers
println("Adding workers... ")
addprocs(7)
println("Number of active processors = $(nprocs())")

wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Balanced/"

version = "_balanced"

wd_data = string(wd, "data", version, "/")

# create folder: Results (csv etc.)
wd_results = string(wd, "Results/")
if !isdir(wd_results)
   mkdir(wd_results)
end

# create folder: estimation output
wd_estimate = string(wd, "Estimates/")
if !isdir(wd_estimate)
   mkdir(wd_estimate)
end

# create folder: estimation output
wd_output = string(wd_estimate, "M2_HIP/")
if !isdir(wd_output)
   mkdir(wd_output)
end

# create temp folder for jld2 outout for hist
wd_jld = string(wd_output, "jld_temp/")
if !isdir(wd_jld)
   mkdir(wd_jld)
end

# create folder: Plots
wd_plots = string(wd, "Plots/")
if !isdir(wd_plots)
   mkdir(wd_plots)
end

# create hist folder
wd_hist = string(wd_plots, "Hist/")
if !isdir(wd_hist)
   mkdir(wd_hist)
end

# create folder: Plots
wd_hist = string(wd_hist, "M2_HIP/")
if !isdir(wd_hist)
   mkdir(wd_hist)
end

cd(wd)

# load packages (install them with Pkg.add() if needed)
@everywhere using JLD2, FileIO, MutableNamedTuples, Random, Distributions, LinearAlgebra, SharedArrays, SpecialFunctions, DelimitedFiles, MAT

# load subfunction files
@everywhere include("functions_emp.jl")
@everywhere include("functions_helpers.jl")

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# starting year
@everywhere yr0 = 67
# end year (= 92(96) if last year = 1993(1997))
@everywhere yr1 = 96
# number of observations in the sample
# bigT = [4, 6, 10]
# @everywhere bigT = [4, 6, 10, 15, 20, 25, 28]
@everywhere bigT = [20]
## MCMC settings

# number of MCMC draws
@everywhere nMCMC = 10000
@everywhere burnin = Int(floor(0.5*nMCMC))+2
# target acceptance rate of RWMH
@everywhere opt_ar = 0.44

####################################################################################################
#                             Part 2: ESTIMATION
####################################################################################################
# helper functions
@everywhere IG_nu(mean, sd) = 4+2*mean^2/sd^2
@everywhere IG_tau(mean, sd) = 2*mean*(1+mean^2/sd^2)

##########################
# GLP, spike-and-slab
#########################

# Hyperparameter in the prior of v_δ^α (Inverse Wishart)
@everywhere nu_vdelta_alpha  = 5.05
# Psi_vdelta_alpha = Matrix(1.0I, 2, 2)
@everywhere Psi_vdelta_alpha = [0.5 0; 0 0.1]

# Hyperparameter in the prior of v_δ^ρ (Inverse Gamma)
@everywhere prior_mean_delta_rho = 0.5^2 # 0.01^2
@everywhere prior_sd_delta_rho   = 0.1 # 0.5
@everywhere nu_vdelta_rho  = IG_nu(prior_mean_delta_rho, prior_sd_delta_rho)
@everywhere tau_vdelta_rho = IG_tau(prior_mean_delta_rho, prior_sd_delta_rho)

# Hyperparameter in the prior of the implied variance v_δ^σ_u (Inverse Gamma)
@everywhere prior_mean_vdelta_sigma_u = 1
@everywhere prior_sd_vdelta_sigma_u   = 0.5
@everywhere nu_vdelta_sigma_u  = IG_nu(prior_mean_vdelta_sigma_u, prior_sd_vdelta_sigma_u)
@everywhere tau_vdelta_sigma_u = IG_tau(prior_mean_vdelta_sigma_u, prior_sd_vdelta_sigma_u)

# Hyperparameter in the prior of the implied variance v_δ^σ_ϵ (Inverse Gamma)
@everywhere prior_mean_vdelta_sigma_e = 1
@everywhere prior_sd_vdelta_sigma_e   = 0.5
@everywhere nu_vdelta_sigma_e  = IG_nu(prior_mean_vdelta_sigma_e, prior_sd_vdelta_sigma_e)
@everywhere tau_vdelta_sigma_e = IG_tau(prior_mean_vdelta_sigma_e, prior_sd_vdelta_sigma_e)

# Hyperparameter in the prior of σ_u (Inverse Gamma)
@everywhere prior_mean_sigma_u = 0.05
@everywhere prior_sd_sigma_u   = 0.05
@everywhere nu_sigma_u  = IG_nu(prior_mean_sigma_u, prior_sd_sigma_u)
@everywhere tau_sigma_u = IG_tau(prior_mean_sigma_u, prior_sd_sigma_u)

@everywhere prior_mean_sigma_e = 0.05
@everywhere prior_sd_sigma_e   = 0.05
@everywhere nu_sigma_e  = IG_nu(prior_mean_sigma_e, prior_sd_sigma_e)
@everywhere tau_sigma_e = IG_tau(prior_mean_sigma_e, prior_sd_sigma_e)

# Hyperparameter in the prior of the variance s0 (Inverse Gamma)
@everywhere prior_mean_sigma_s0 = 0.05
@everywhere prior_sd_sigma_s0   = 0.05
@everywhere nu_sigma_s0  = IG_nu(prior_mean_sigma_s0, prior_sd_sigma_s0)
@everywhere tau_sigma_s0 = IG_tau(prior_mean_sigma_s0, prior_sd_sigma_s0)

# # hyperparameters
@everywhere lambda = (mu_alpha = [0,0], valpha = [1 0; 0 1], mu_rho = 0.8, vrho = 1, 
         nu_vdelta_alpha = nu_vdelta_alpha, Psi_vdelta_alpha = Psi_vdelta_alpha,
         nu_vdelta_rho = nu_vdelta_rho, tau_vdelta_rho = tau_vdelta_rho,
         nu_vdelta_sigma_u = nu_vdelta_sigma_u, tau_vdelta_sigma_u = tau_vdelta_sigma_u,
         nu_vdelta_sigma_e = nu_vdelta_sigma_e, tau_vdelta_sigma_e = tau_vdelta_sigma_e,
         nu_sigma_u = nu_sigma_u, tau_sigma_u = tau_sigma_u, 
         nu_sigma_e = nu_sigma_e, tau_sigma_e = tau_sigma_e, 
         a = 1, b = 1,
         mu_s0 = 0, v_s0 = 0.05,
         nu_sigma_s0 = nu_sigma_s0, tau_sigma_s0 = tau_sigma_s0)

@everywhere control = (true_alpha = false, true_delta_alpha = false, true_vdelta_alpha = false, 
         true_rho = false, true_delta_rho = false, true_vdelta_rho = false,
         true_delta_sigma_u = false, true_vdelta_sigma_u = false,
         true_delta_sigma_e = false, true_vdelta_sigma_e = false,
         true_s = false, true_sigma2_e = false, true_sigma2_u = false)

@everywhere seed = 0606


for T = bigT
#  T = 4
   T2 = T + 2

   @sync @distributed for t_smpl = (yr0 + T2 - 1):yr1

   #  t_smpl = yr0 + T2 - 1

      # set random seed
      Random.seed!(100*T + t_smpl)

      # preparation
      label = "T$(T)_tau$(t_smpl)_"
      println(label)

      # load the data
      raw = readdlm(string(wd_data, label, "data.txt"), ' ')

      id = unique(raw[:,1])
      N  = length(id)

      Y = zeros(T2, N)
      h = zeros(T2, N)
      for t = 1:T2
         for i = 1:N
            selected = (abs.(raw[:,1] .- id[i]) .< 0.05) .& (abs.(raw[:,2] .- (t_smpl-T2+t)) .< 0.05)
            Y[t,i] = raw[selected, 3][1]
            h[t,i] = raw[selected, 5][1]
         end
      end

      # remove the last observation
      y_all = Y[1:end-1,:]
      h_all = h[1:end-1,:]

      # variables in age-earning portfolio (in-sample)
      H = zeros(T2-1, N, 2)
      H[:,:,1] .= 1
      H[:,:,2] = h_all/10

      ##########################
      # GLP, spike-and-slab
      #########################

      seed = 100*T + t_smpl

      post_mean_ss_hetsk, post_draw_ss_hetsk = est_M2_HIP(y_all, H, lambda, opt_ar, nMCMC, seed);
      
      # OOS forecast
      H_last = [ones(N,1) h[end,:]/10];

      alpha = post_mean_ss_hetsk.alpha_hat
      delta_alpha = post_mean_ss_hetsk.delta_alpha_hat
      delta_rho = post_mean_ss_hetsk.delta_rho_hat
      rho = post_mean_ss_hetsk.rho_hat
      s_last = post_mean_ss_hetsk.s_hat[end,:]

      fcst = sum(H_last .* (alpha' .+ delta_alpha), dims = 2) + s_last .* (rho .+ delta_rho)

      # save lambda_i and rho_i in the case folder
      file = matopen(string(wd_output, label, "results.mat"), "w")
      post_mean_ss_hetsk_mat =(; post_mean_ss_hetsk..., fcst = fcst) # add fcst into final output
      write(file, "post_mean", post_mean_ss_hetsk_mat)
      close(file)
   
      # save everything for plotting histograms
      jldsave(wd_jld * "$(label)output.jld2"; post_mean_ss_hetsk = post_mean_ss_hetsk, post_draw_ss_hetsk = post_draw_ss_hetsk)

   end

end

rmprocs(workers())
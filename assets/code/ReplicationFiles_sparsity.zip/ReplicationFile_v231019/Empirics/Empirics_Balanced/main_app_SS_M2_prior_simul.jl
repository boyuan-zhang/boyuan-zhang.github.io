####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#####################################################################################################

#* This script generate table 5 in the paper.

####################################################################################################
#                             Part 0: INTRO
####################################################################################################
cd()

wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Balanced/"

cd(wd)


using MutableNamedTuples, Random, Distributions, LinearAlgebra, SpecialFunctions, DelimitedFiles

####################################################################################################
#                             Part 1: Hyperparameters
####################################################################################################
# helper functions
IG_nu(mean, sd) = 4+2*mean^2/sd^2
IG_tau(mean, sd) = 2*mean*(1+mean^2/sd^2)

##########################
# spike-and-slab
#########################

# Hyperparameter in the prior of v_δ^α (Inverse Wishart)
nu_vdelta_alpha  = 5.05
# Psi_vdelta_alpha = Matrix(1.0I, 2, 2)
Psi_vdelta_alpha = [0.5 0; 0 0.1]

# Hyperparameter in the prior of v_δ^ρ (Inverse Gamma)
prior_mean_delta_rho = 0.5^2 # 0.01^2
prior_sd_delta_rho   = 0.1 # 0.5
nu_vdelta_rho  = IG_nu(prior_mean_delta_rho, prior_sd_delta_rho)
tau_vdelta_rho = IG_tau(prior_mean_delta_rho, prior_sd_delta_rho)

# Hyperparameter in the prior of the implied variance v_δ^σ_u (Inverse Gamma)
prior_mean_vdelta_sigma_u = 1
prior_sd_vdelta_sigma_u   = 0.5
nu_vdelta_sigma_u  = IG_nu(prior_mean_vdelta_sigma_u, prior_sd_vdelta_sigma_u)
tau_vdelta_sigma_u = IG_tau(prior_mean_vdelta_sigma_u, prior_sd_vdelta_sigma_u)

# Hyperparameter in the prior of the implied variance v_δ^σ_ϵ (Inverse Gamma)
prior_mean_vdelta_sigma_e = 1
prior_sd_vdelta_sigma_e   = 0.5
nu_vdelta_sigma_e  = IG_nu(prior_mean_vdelta_sigma_e, prior_sd_vdelta_sigma_e)
tau_vdelta_sigma_e = IG_tau(prior_mean_vdelta_sigma_e, prior_sd_vdelta_sigma_e)

# Hyperparameter in the prior of σ_u (Inverse Gamma)
prior_mean_sigma_u = 0.05
prior_sd_sigma_u   = 0.05
nu_sigma_u  = IG_nu(prior_mean_sigma_u, prior_sd_sigma_u)
tau_sigma_u = IG_tau(prior_mean_sigma_u, prior_sd_sigma_u)

prior_mean_sigma_e = 0.05
prior_sd_sigma_e   = 0.05
nu_sigma_e  = IG_nu(prior_mean_sigma_e, prior_sd_sigma_e)
tau_sigma_e = IG_tau(prior_mean_sigma_e, prior_sd_sigma_e)

# Hyperparameter in the prior of the variance s0 (Inverse Gamma)
prior_mean_sigma_s0 = 0.05
prior_sd_sigma_s0   = 0.05
nu_sigma_s0  = IG_nu(prior_mean_sigma_s0, prior_sd_sigma_s0)
tau_sigma_s0 = IG_tau(prior_mean_sigma_s0, prior_sd_sigma_s0)

# # hyperparameters
lambda = (mu_alpha = [0,0], valpha = [1 0; 0 1], mu_rho = 0.8, vrho = 1, 
         nu_vdelta_alpha = nu_vdelta_alpha, Psi_vdelta_alpha = Psi_vdelta_alpha,
         nu_vdelta_rho = nu_vdelta_rho, tau_vdelta_rho = tau_vdelta_rho,
         nu_vdelta_sigma_u = nu_vdelta_sigma_u, tau_vdelta_sigma_u = tau_vdelta_sigma_u,
         nu_vdelta_sigma_e = nu_vdelta_sigma_e, tau_vdelta_sigma_e = tau_vdelta_sigma_e,
         nu_sigma_u = nu_sigma_u, tau_sigma_u = tau_sigma_u, 
         nu_sigma_e = nu_sigma_e, tau_sigma_e = tau_sigma_e, 
         a = 1, b = 1,
         mu_s0 = 0, v_s0 = 0.05,
         nu_sigma_s0 = nu_sigma_s0, tau_sigma_s0 = tau_sigma_s0)


####################################################################################################
#                             Part 2: Generate quantiles
####################################################################################################

dimH = length(lambda.mu_alpha)
nSim = 1000000

# helper function
get_quantile(x) = round.(quantile(x, (0.05,0.95)), digits = 2)

# alpha
round.(quantile(Normal(lambda.mu_alpha[1,1], sqrt(lambda.valpha[1,1])), [0.05,0.95]), digits = 2)

# rho
round.(quantile(Normal(lambda.mu_rho, sqrt(lambda.vrho)), [0.05,0.95]), digits = 2)

# sigma^2_u,t and sigma^2_e,t
round.(quantile(InverseGamma(lambda.nu_sigma_u/2, lambda.tau_sigma_u/2), [0.05,0.95]), digits = 2)

# mu_sigma_s0
round.(quantile(Normal(lambda.mu_s0, sqrt(lambda.v_s0)), [0.05,0.95]), digits = 2)

# v_sigma_s0
round.(quantile(InverseGamma(lambda.nu_sigma_s0/2, lambda.tau_sigma_s0/2), [0.05,0.95]), digits = 2)

# q
round.(quantile(Beta(lambda.a, lambda.b), [0.05,0.95]), digits = 2)

# vdelta_alpha
Random.seed!(1)
vdelta_alpha_draw = Array{Float64}(undef, nSim, 2, 2)
for i in 1:nSim
   vdelta_alpha_draw[i,:,:] = rand(InverseWishart(lambda.nu_vdelta_alpha, lambda.Psi_vdelta_alpha))
end

get_quantile(vdelta_alpha_draw[:,1,1])
get_quantile(vdelta_alpha_draw[:,2,2])
get_quantile(vdelta_alpha_draw[:,1,2])

# vdelta_rho
round.(quantile(InverseGamma(lambda.nu_vdelta_rho/2, lambda.tau_vdelta_rho/2), [0.05,0.95]), digits = 2)

# vdelta_simga
round.(quantile(InverseGamma(lambda.nu_vdelta_sigma_u/2, lambda.tau_vdelta_sigma_u/2), [0.05,0.95]), digits = 2)



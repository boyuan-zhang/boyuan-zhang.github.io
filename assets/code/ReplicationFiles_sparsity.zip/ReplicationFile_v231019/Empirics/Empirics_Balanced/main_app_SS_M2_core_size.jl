####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Empirical Analysis, Balanced Panel
#  Creation: 11/29/2019
#  Last change: 01/19/2022
#####################################################################################################

#* This script generate figure 5 in the paper

####################################################################################################
#                             Part 0: INTRO
####################################################################################################

cd()
wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Balanced/"
cd(wd)

estimator = "M2"

wd_plots = string(wd, "Plots/")

### create a folder under Plots
wd_core_plot = string(wd_plots, "Core_Size/")
if !isdir(wd_core_plot)
     mkdir(wd_core_plot)
end

# folder of jld2 outout
wd_hist_temp = string(wd, "Estimates/", estimator, "/jld_temp/")

### directory of the size of core groups
wd_results = string(wd, "Results/")
# create subfolder under Results
wd_core = string(wd_results, "Core_Size/")
if !isdir(wd_core)
     mkdir(wd_core)
end


# load packages (install them with Pkg.add() if needed)
using StatsPlots, KernelDensity, JLD2, Plots, SpecialFunctions, Distributions, StatisticalRethinking, DelimitedFiles

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# starting year
yr0 = 67
# end year (= 92(96) if last year = 1993(1997))
yr1 = 96
# number of observations in the sample
# bigT = [4, 6, 10]
bigT = [4, 6, 10, 15, 20, 25, 28]

####################################################################################################
#                             Part 3: DRAW FIGURES
####################################################################################################

#* Figure 5: Posterior densities for the sizes of α and ρ groups

## posterior densities for alpha and rho group sizes
T = 20
T2 = T + 2
t_smpl = 91 # and 91

# load posterior draws in JLD2 file
label = "T$(T)_tau$(t_smpl)_"

temp = load(wd_hist_temp * "$(label)output.jld2")
post_mean_ss_hetsk = temp["post_mean_ss_hetsk"]
post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

N = length(post_mean_ss_hetsk.delta_alpha_hat[:,1])


num_zero(x) = sum(x .== 0.0)

post_alpha_core_size = mapslices(num_zero, post_draw_ss_hetsk.delta_alpha_draw[:,1,:]; dims=2)[:,1]
post_rho_core_size = mapslices(num_zero, post_draw_ss_hetsk.delta_rho_draw; dims=2)[:,1]

histogram(post_alpha_core_size, nbin = 15, normalize = :probability,
         xtickfontsize = 8, ytickfontsize = 8, fillalpha = 0.7,
         label = "\$\\alpha\$", framestyle = :box, size = (300,200), dpi = 200)

histogram!(post_rho_core_size, nbin = 15, normalize = :probability,
         xtickfontsize = 8, ytickfontsize = 8, fillalpha = 0.7,
         label = "\$\\rho\$", framestyle = :box, size = (300,200), dpi = 200)
         
savefig(wd_core_plot * "fig_emp_hist_post_core_size_T$(T)_tau$(t_smpl).png")






### Calculate the size of core groups for all T
for T = bigT

   # T = 20
   T2 = T + 2
   @show T
   
   # initialize matrix to record size of core groups
   core_size = Array{Float32}(undef, yr1 - (yr0 + T2 - 1) + 1, 1+1+5+5)
   counter = 1

   for t_smpl = (yr0 + T2 - 1):yr1
      # t_smpl = (yr0 + T2 - 1)

      # load posterior draws in JLD2 file
      label = "T$(T)_tau$(t_smpl)_"

      temp = load(wd_hist_temp * "$(label)output.jld2")
      post_mean_ss_hetsk = temp["post_mean_ss_hetsk"]
      post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

      N = length(post_mean_ss_hetsk.delta_alpha_hat[:,1])

      # size of core group
      core_size[counter, 1]  = t_smpl
      core_size[counter, 2]  = N
      core_size[counter, 3]  = sum(median(post_draw_ss_hetsk.delta_alpha_draw[:,1,:], dims = 1) .== 0.0)
      core_size[counter, 3]  = sum(median(post_draw_ss_hetsk.z_alpha_draw, dims = 1) .== 0.0)
      core_size[counter, 4]  = core_size[counter, 3] / N 
      
      core_size[counter, 5]  = sum(median(post_draw_ss_hetsk.delta_alpha_draw[:,2,:], dims = 1) .== 0.0)
      core_size[counter, 6]  = core_size[counter, 5] / N 

      core_size[counter, 7]  = sum(median(post_draw_ss_hetsk.delta_rho_draw, dims = 1) .== 0.0)
      # core_size[counter, 3]  = sum(median(post_draw_ss_hetsk.z_rho_draw, dims = 1) .== 0.0)
      core_size[counter, 8]  = core_size[counter, 7] / N 
      core_size[counter, 9]  = sum(median(post_draw_ss_hetsk.delta_sigma_u_draw, dims = 1) .== 0.0)
      # core_size[counter, 3]  = sum(median(post_draw_ss_hetsk.z_sigma_u_draw, dims = 1) .== 0.0)
      core_size[counter, 10] = core_size[counter, 9] / N 
      core_size[counter, 11] = sum(median(post_draw_ss_hetsk.delta_sigma_e_draw, dims = 1) .== 0.0)
      core_size[counter, 12] = core_size[counter, 11] / N 

      counter += 1
   end
   header = ["T" "N" "alpha0" "alpha0_share" "alpha1" "alpha1_share" "rho" "rho_share" "sigma_u" "sigma_u_share" "sigma_e" "sigma_e_share"]
   writedlm( wd_core * "Core_size_T$(T)_$(estimator).csv", [header; core_size], ',')

end


println("Tables are ready.")

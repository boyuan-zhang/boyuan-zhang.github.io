####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Empirical Analysis, Balanced Panel
#####################################################################################################

#* This script generates figures of individual earnings forecasts (Figure 10)
#* and ratio of predictice interval widths (figure 11)


####################################################################################################
#                             Part 0: INTRO
####################################################################################################

cd()
wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Balanced/"
cd(wd)

estimator  = "AR"
estimator2 = "M2"
estimator3 = "M2_RIP"

version = "_balanced"

# directory of results
wd_results = string(wd, "Results/")
# create lps folder under Results
wd_mf = string(wd_results, "Multi_Fcst/")
if !isdir(wd_mf)
     mkdir(wd_mf)
end

# directory of posterior draw
wd_jld = string(wd, "Estimates/", estimator, "/jld_temp/")

wd_jld2 = string(wd, "Estimates/", estimator2, "/jld_temp/")

wd_jld3 = string(wd, "Estimates/", estimator3, "/jld_temp/")

# directory of data
wd_data = string(wd, "data", version, "/")

# create folder for posterior hpdi
wd_plots = string(wd, "Plots/")

wd_post = string(wd_plots, "Multi_Fcst", "/")
if !isdir(wd_post)
   mkdir(wd_post)
end

wd_line = string(wd_post, "lines", "/")
if !isdir(wd_line)
   mkdir(wd_line)
end

wd_scatter = string(wd_post, "scatter", "/")
if !isdir(wd_scatter)
   mkdir(wd_scatter)
end

# load packages (install them with Pkg.add() if needed)
using StatsPlots, JLD2, Plots, Distributions, StatisticalRethinking, DelimitedFiles, Random
using ProgressBars # for fun

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# horizons
horizon = 5
# starting year
yr0 = 91
# end year (= 92(96) if last year = 1993(1997))
yr1 = yr0 + horizon


####################################################################################################
#                             Part 3: DRAW HISTOGRAMS
####################################################################################################

# long panel (T = 25)
T = 25
T2 = T + 2
# select indiividuals
label = "T$(T)_tau$(yr1)_"
println("Load dataset: ", label)

# load the data
raw = readdlm(string(wd_data, label, "data.txt"), ' ')

id = round.(Int, unique(raw[:,1]))
N  = length(id)

Y = zeros(T2, N)
h = zeros(T2, N)
for t = 1:T2
   for i = 1:N
      selected = (abs.(raw[:,1] .- id[i]) .< 0.05) .& (abs.(raw[:,2] .- (yr1-T2+t)) .< 0.05)
      Y[t,i] = raw[selected, 3][1]
      h[t,i] = raw[selected, 5][1]
   end
end

# in-sample observations
Y_is = Y[1:(T2-horizon-1), :]

# out-of--sample observations
Y_oos = Y[(T2-horizon):(end-1), :]

# Get id information for the short panel
label_est = "T$(T-horizon)_tau$(yr0)_"
println("Load dataset: ", label_est)

# load the data
raw_short = readdlm(string(wd_data, label_est, "data.txt"), ' ')
id_short = round.(Int, unique(raw_short[:,1]))

# find the location of individuals with 25-year obs in the T=20 subsample
# id: unit id from T=25 sample; id_short: unit id from T=20 sample
id_loc = indexin(id, id_short)


### AR Model
# load posterior draws in JLD2 file
label_est = "T$(T-horizon)_tau$(yr0)_"
temp = load(wd_jld * "$(label_est)output.jld2")
post_mean_ss_hetsk = temp["post_mean_ss_hetsk"]
post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

nMCMC = length(post_draw_ss_hetsk.delta_rho_draw[:,1])

# Unit IDs with nonzero delta-alpha
# collect(1:82)[median(post_draw_ss_hetsk.delta_alpha_draw, dims = 1)[1,:,:]'[:,1] .!= 0]

# number of repetition for each posterior of parameters
nSim = 500

# generate forecast
fcst = zeros(length(id), horizon, nSim, nMCMC);

for i in ProgressBar(1:N)

     # i = 1
     loc = id_loc[i]

     # posterior draws of parameters
     delta_alpha = post_draw_ss_hetsk.delta_alpha_draw[:,:,loc]

     delta_rho = post_draw_ss_hetsk.delta_rho_draw[:,loc]

     delta_sigma_u = post_draw_ss_hetsk.delta_sigma_u_draw[:,loc]

     delta_sigma_e = post_draw_ss_hetsk.delta_sigma_e_draw[:,loc]

     # generate forecast
     for l in 1:nSim

          H_last = [1 h[T2-horizon,i]/10]
          s_last = post_draw_ss_hetsk.s_draw[:,loc,end]

          for j in 1:horizon
              
               Random.seed!(Int(10e10*i + 10e4*l + 10 *j))
               # j = 1; l = 1
               # forecast s
               s_fcst = delta_rho .* s_last + sqrt.(delta_sigma_e) .* randn(nMCMC)

               # forecast y
               y_fcst = delta_alpha * H_last' + s_fcst + sqrt.(delta_sigma_u) .* randn(nMCMC)

               # update last observation
               H_last[2] = H_last[2] + 1/10
               s_last    = s_fcst

               # save predicted value
               fcst[i,j,l,:] = y_fcst
          end
     end
end





### M2
# load posterior draws in JLD2 file
label_est = "T$(T-horizon)_tau$(yr0)_"
temp = load(wd_jld2 * "$(label_est)output.jld2")
post_mean_ss_hetsk = temp["post_mean_ss_hetsk"]
post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

nMCMC = length(post_draw_ss_hetsk.rho_draw)

# number of repetition for each posterior of parameters
nSim = 500

# generate forecast
fcst2 = zeros(length(id), horizon, nSim, nMCMC);

for i in ProgressBar(1:N)

     # i = 1, m = 1
     loc = id_loc[i]

     # posterior draws of parameters
     alpha = post_draw_ss_hetsk.alpha_draw
     delta_alpha = post_draw_ss_hetsk.delta_alpha_draw[:,:,loc]

     rho = post_draw_ss_hetsk.rho_draw
     delta_rho = post_draw_ss_hetsk.delta_rho_draw[:,loc]

     delta_sigma_u = post_draw_ss_hetsk.delta_sigma_u_draw[:,loc]
     sigma2_u = post_draw_ss_hetsk.sigma2_u_draw[:, end]

     delta_sigma_e = post_draw_ss_hetsk.delta_sigma_e_draw[:,loc]
     sigma2_e = post_draw_ss_hetsk.sigma2_e_draw[:, end]

     # generate forecast
     for l in 1:nSim

          H_last = [1 h[T2-horizon,i]/10]
          s_last = post_draw_ss_hetsk.s_draw[:,loc,end]

          for j in 1:horizon
              
               Random.seed!(Int(10e10*i + 10e4*l + 10 *j))
               # j = 1; l = 1
               # forecast s
               s_fcst = (rho + delta_rho) .* s_last + sqrt.(sigma2_e .* delta_sigma_e) .* randn(nMCMC)

               # forecast y
               y_fcst = (alpha .+ delta_alpha) * H_last' + s_fcst + sqrt.(sigma2_u .* delta_sigma_u) .* randn(nMCMC)

               # update last observation
               H_last[2] = H_last[2] + 1/10
               s_last    = s_fcst

               # save predicted value
               fcst2[i,j,l,:] = y_fcst
          end
     end
end

N20 = size(post_draw_ss_hetsk.delta_alpha_draw,3)
id_deviator_short = collect(1:N20)[median(post_draw_ss_hetsk.delta_alpha_draw, dims = 1)[1,:,:]'[:,1] .!= 0]

id_deviator = indexin(id_deviator_short, id_loc)
id_deviator = id_deviator[id_deviator .!= nothing]
id_core     = setdiff(1:length(id_loc), id_deviator)





### M2 (no parameter uncertainty)
# load posterior draws in JLD2 file
label_est = "T$(T-horizon)_tau$(yr0)_"
temp = load(wd_jld2 * "$(label_est)output.jld2")
post_mean_ss_hetsk = temp["post_mean_ss_hetsk"]
post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

nMCMC = length(post_draw_ss_hetsk.rho_draw)

# number of repetition for each posterior of parameters
nSim = 500

# generate forecast
fcst4 = zeros(length(id), horizon, nSim, nMCMC)

for i in ProgressBar(1:N)

     # i = 1
     loc = id_loc[i]

     # posterior draws of parameters
     alpha = vec(post_mean_ss_hetsk.alpha_hat)
     delta_alpha = vec(post_mean_ss_hetsk.delta_alpha_hat[loc,:])

     rho = post_mean_ss_hetsk.rho_hat
     delta_rho = post_mean_ss_hetsk.delta_rho_hat[loc]

     delta_sigma_u = post_mean_ss_hetsk.delta_sigma_u_hat[loc]
     sigma2_u = post_mean_ss_hetsk.sigma2_u_hat[end]

     delta_sigma_e = post_mean_ss_hetsk.delta_sigma_e_hat[loc]
     sigma2_e = post_mean_ss_hetsk.sigma2_e_hat[end]

     # generate forecast
     for l in 1:nSim

          H_last = [1 h[T2-horizon,i]/10]
          s_last = post_mean_ss_hetsk.s_hat[end,loc]

          for j in 1:horizon
               # j = 1; l = 1

               Random.seed!(Int(10e10*i + 10e4*l + 10 *j))
               # forecast s
               s_fcst = (rho + delta_rho) .* s_last .+ sqrt(sigma2_e * delta_sigma_e) * randn(nMCMC)

               # forecast y
               y_fcst = (H_last * (alpha + delta_alpha))[1] .+ s_fcst .+ sqrt(sigma2_u * delta_sigma_u) * randn(nMCMC)

               # update last observation
               H_last[2] = H_last[2] + 1/10
               s_last    = s_fcst

               # save predicted value
               fcst4[i,j,l,:] = y_fcst
          end
     end
end




### M2 (RIP)
# load posterior draws in JLD2 file
label_est = "T$(T-horizon)_tau$(yr0)_"
temp = load(wd_jld3 * "$(label_est)output.jld2")
post_mean_ss_hetsk = temp["post_mean_ss_hetsk"]
post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

nMCMC = length(post_draw_ss_hetsk.rho_draw)

# number of repetition for each posterior of parameters
nSim = 500

# generate forecast
fcst3 = zeros(length(id), horizon, nSim, nMCMC)

for i in ProgressBar(1:N)

     # i = 1, m = 1
     loc = id_loc[i]

     # posterior draws of parameters
     alpha = post_draw_ss_hetsk.alpha_draw
     delta_alpha = post_draw_ss_hetsk.delta_alpha_draw[:,:,loc]

     rho = post_draw_ss_hetsk.rho_draw
     delta_rho = post_draw_ss_hetsk.delta_rho_draw[:,loc]

     delta_sigma_u = post_draw_ss_hetsk.delta_sigma_u_draw[:,loc]
     sigma2_u = post_draw_ss_hetsk.sigma2_u_draw[:, end]

     delta_sigma_e = post_draw_ss_hetsk.delta_sigma_e_draw[:,loc]
     sigma2_e = post_draw_ss_hetsk.sigma2_e_draw[:, end]

     # generate forecast
     for l in 1:nSim

          H_last = [1 h[T2-horizon,i]/10]
          s_last = post_draw_ss_hetsk.s_draw[:,loc,end]

          for j in 1:horizon
              
               Random.seed!(Int(10e10*i + 10e4*l + 10 *j))
               # j = 1; l = 1
               # forecast s
               s_fcst = (rho + delta_rho) .* s_last + sqrt.(sigma2_e .* delta_sigma_e) .* randn(nMCMC)

               # forecast y
               y_fcst = (alpha .+ delta_alpha) * H_last' + s_fcst + sqrt.(sigma2_u .* delta_sigma_u) .* randn(nMCMC)

               # update last observation
               H_last[2] = H_last[2] + 1/10
               s_last    = s_fcst

               # save predicted value
               fcst3[i,j,l,:] = y_fcst
          end
     end
end



### Calculate quantiles
# create quantile list
n_quantile = 20

list_q = collect(0.05:(1/n_quantile):0.95)
deleteat!(list_q, list_q .== 0.5) # remove median

# calculate quantiles for each indiividuals (N x horizon x n_quantile)
ind_quantile  = mapslices(x -> quantile(x, list_q), fcst;  dims = (3,4))[:,:,:,1]
ind_quantile2 = mapslices(x -> quantile(x, list_q), fcst2; dims = (3,4))[:,:,:,1]
ind_quantile3 = mapslices(x -> quantile(x, list_q), fcst3; dims = (3,4))[:,:,:,1]
ind_quantile4 = mapslices(x -> quantile(x, list_q), fcst4; dims = (3,4))[:,:,:,1]



jldsave(wd_mf * "multi_step_quantile_AR_year$(yr0).jld2"; ind_quantile  = ind_quantile)
jldsave(wd_mf * "multi_step_quantile_M2_year$(yr0).jld2"; ind_quantile = ind_quantile2)
jldsave(wd_mf * "multi_step_quantile_M2_RIP_year$(yr0).jld2"; ind_quantile = ind_quantile3)
jldsave(wd_mf * "multi_step_quantile_M2_no_para_unc_year$(yr0).jld2"; ind_quantile = ind_quantile4)













############################################################################################################################################
### Individual Earnings Forecasts (Figure 10)
############################################################################################################################################

# selected ID
# target = [15 81 35 42]
target = id_loc
# short_list = indexin(target, id_loc)[1,:]

id_loc[id_core] # 19 or 71
id_loc[id_deviator] # 35 or 59

### Generate figures
for i in 1:length(target)

     # i = 1
     ind_obs = Y[2:(end-1),i]
     last_obs = Y[T2-horizon-1,i]

     ### AR
     p1 = plot(1:length(ind_obs), ind_obs, linewidth = 0.1,
          xlimits = (1, length(ind_obs)), grid = false,
          labels = "", legend = :bottomleft, framestyle = :box, size = (500,300), dpi = 200)
     xlabel!("Experience")
     vspan!([T-horizon, T], c = :gray, fillalpha = 0.15, labels = "")

     for k = 1:Int(n_quantile/2-1)
          lb = vcat(last_obs,ind_quantile[i,:,k])
          ub = vcat(last_obs,ind_quantile[i,:, n_quantile-1-k])

          display(plot!((T-horizon):T, lb, fillrange = ub, linewidth = 0, c = "#A1A5E6", fillalpha = 0.3 + k/100, labels = ""))
     end
     plot!(1:length(ind_obs), ind_obs, linewidth = 2, c = :black, labels = "")
     plot!(xticks=(5:5:25, floor.(Int, h[1 + 5:5:25, i])))

     savefig(wd_line * "fig_emp_multi_fcst_unit$(id_loc[i])_AR_T$(T-horizon)_tau$(yr0).png")

     ### M2
     p2 = plot(1:length(ind_obs), ind_obs, linewidth = 0.0001,
          xlimits = (1, length(ind_obs)), grid = false, 
          ylimits = collect(ylims(p1)),
          labels = "", legend = :bottomleft, framestyle = :box, size = (500,300), dpi = 200)
     xlabel!("Experience")
     vspan!([T-horizon, T], c = :gray, fillalpha = 0.15, labels = "")

     for k = 1:Int(n_quantile/2)
          lb = vcat(last_obs,ind_quantile2[i,:,k])
          ub = vcat(last_obs,ind_quantile2[i,:, n_quantile-1-k])

          display(plot!((T-horizon):T, lb, fillrange = ub, linewidth = 0, c = "#00BBDF", fillalpha = 0.2 + k/120, labels = ""))
     end
     plot!(1:length(ind_obs), ind_obs, linewidth = 2, c = :black, labels = "")
     plot!(xticks=(5:5:25, floor.(Int, h[1 + 5:5:25, i])))

     savefig(wd_line * "fig_emp_multi_fcst_unit$(id_loc[i])_M2_T$(T-horizon)_tau$(yr0).png")

     ### M2 (no parameter uncertainty)
     p3 = plot(1:length(ind_obs), ind_obs, linewidth = 0.0001,
          xlimits = (1, length(ind_obs)), grid = false, 
          ylimits = collect(ylims(p1)),
          labels = "", legend = :bottomleft, framestyle = :box, size = (500,300), dpi = 200)
     xlabel!("Experience")
     vspan!([T-horizon, T], c = :gray, fillalpha = 0.15, labels = "")

     for k = 1:Int(n_quantile/2)
          lb = vcat(last_obs,ind_quantile4[i,:,k])
          ub = vcat(last_obs,ind_quantile4[i,:, n_quantile-1-k])

          display(plot!((T-horizon):T, lb, fillrange = ub, linewidth = 0, c = :green, fillalpha = 0.2 + k/120, labels = ""))
     end
     plot!(1:length(ind_obs), ind_obs, linewidth = 2, c = :black, labels = "")
     plot!(xticks=(5:5:25, floor.(Int, h[1 + 5:5:25, i])))

     savefig(wd_line * "fig_emp_multi_fcst_unit$(id_loc[i])_M2_no_para_unc_T$(T-horizon)_tau$(yr0).png")

end



# ### AR
# ind_quantile = load(wd_mf * "multi_step_quantile_AR_year$(yr0).jld2", "ind_quantile")
# ### M2
# ind_quantile2 = load(wd_mf * "multi_step_quantile_M2_year$(yr0).jld2", "ind_quantile")
# ### M2-RIP
# ind_quantile3 = load(wd_mf * "multi_step_quantile_M2_RIP_year$(yr0).jld2", "ind_quantile")
# ### M2 no para unc
# ind_quantile4 = load(wd_mf * "multi_step_quantile_M2_RIP_year$(yr0).jld2", "ind_quantile")











############################################################################################################################################
### predictive interval length ratio (Figure 11)
############################################################################################################################################

ind_quantile_copy  = permutedims(ind_quantile, [1, 3, 2])
ind_quantile_copy2 = permutedims(ind_quantile2, [1, 3, 2])
ind_quantile_copy3 = permutedims(ind_quantile3, [1, 3, 2])
ind_quantile_copy4 = permutedims(ind_quantile4, [1, 3, 2])

### AR
ind_quantile_len = zeros(length(id), Int(length(list_q) / 2), horizon);

for ii in 0:(Int(length(list_q) / 2) - 1)
     ind_quantile_len[:, ii+1, :] = ind_quantile_copy[:, length(list_q) - ii, :] - ind_quantile_copy[:, ii+1, :]
end

### SS-HIP-Hetsk
ind_quantile_len2 = zeros(length(id), Int(length(list_q) / 2), horizon);

for ii in 0:(Int(length(list_q) / 2) - 1)
     ind_quantile_len2[:, ii+1, :] = ind_quantile_copy2[:, length(list_q) - ii, :] - ind_quantile_copy2[:, ii+1, :]
end


### SS-HIP-Hetsk-homo
ind_quantile_len3 = zeros(length(id), Int(length(list_q) / 2), horizon);

for ii in 0:(Int(length(list_q) / 2) - 1)
     ind_quantile_len3[:, ii+1, :] = ind_quantile_copy3[:, length(list_q) - ii, :] - ind_quantile_copy3[:, ii+1, :]
end


### SS-HIP-Hetsk (no para unc)
ind_quantile_len4 = zeros(length(id), Int(length(list_q) / 2), horizon);

for ii in 0:(Int(length(list_q) / 2) - 1)
     ind_quantile_len4[:, ii+1, :] = ind_quantile_copy4[:, length(list_q) - ii, :] - ind_quantile_copy4[:, ii+1, :]
end



### Plot of Length ratio (AR over M2)
ind_quantile_ratio = ind_quantile_len ./ ind_quantile_len2

exp = h[T2-horizon-1,:]

# create a vector of color for core group and deviator
point_color = ones(length(id_loc))
point_color[id_deviator] .= 2
point_color = Int.(point_color)

for ii in 1:Int(length(list_q) / 2)
     for hh in horizon:-1:1
          
          global ylimits

          if hh == horizon
               p = plot(exp, ind_quantile_ratio[:,ii,hh], seriestype = :scatter, markersize = 2.5, 
                    color = point_color, xticks = Int.(minimum(exp):2:maximum(exp)),
                    labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)
               ylimits = collect(ylims(p))
          else 
               p = plot(exp, ind_quantile_ratio[:,ii,hh], seriestype = :scatter, markersize = 2.5, 
                    ylimits = ylimits, color = point_color, xticks = Int.(minimum(exp):2:maximum(exp)),
                    labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)
          end

          savefig(wd_scatter * "fig_emp_multi_fcst_pi_ratio_ar_over_m2_year$(yr0)_P$(Int(ii*10))_H$(hh).png")

     end
end


### Plot of Length ratio (RIP over M2)
ind_quantile_ratio = ind_quantile_len3 ./ ind_quantile_len2

exp = h[T2-horizon-1,:]

# create a vector of color for core group and deviator
point_color = ones(length(id_loc))
point_color[id_deviator] .= 2
point_color = Int.(point_color)

for ii in 1:Int(length(list_q) / 2)
     for hh in horizon:-1:1
          
          global ylimits

          if hh == horizon
               p = plot(exp, ind_quantile_ratio[:,ii,hh], seriestype = :scatter, markersize = 2.5, 
                    color = point_color, xticks = Int.(minimum(exp):2:maximum(exp)),
                    labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)
               ylimits = collect(ylims(p))
          else 
               p = plot(exp, ind_quantile_ratio[:,ii,hh], seriestype = :scatter, markersize = 2.5, 
                    ylimits = ylimits, color = point_color, xticks = Int.(minimum(exp):2:maximum(exp)),
                    labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)
          end

          savefig(wd_scatter * "fig_emp_multi_fcst_pi_ratio_rip_over_m2_year$(yr0)_P$(Int(ii*10))_H$(hh).png")

     end
end




### Plot of Length ratio (M2 no para unc vs M2)
ind_quantile_ratio = ind_quantile_len4 ./ ind_quantile_len2

exp = h[T2-horizon-1,:]

point_color = ones(length(id_loc))
point_color[id_deviator] .= 2
point_color = Int.(point_color)

for ii in 1:Int(length(list_q) / 2)
     for hh in horizon:-1:1
          
          global ylimits

          if hh == horizon
               p = plot(exp, ind_quantile_ratio[:,ii,hh], seriestype = :scatter, markersize = 2.5, 
                    color = point_color,
                    xticks = minimum(exp):2:maximum(exp),
                    labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)
               ylimits = collect(ylims(p))
          else 
               p = plot(exp, ind_quantile_ratio[:,ii,hh], seriestype = :scatter, markersize = 2.5, 
                    ylimits = ylimits, color = point_color, 
                    xticks = minimum(exp):2:maximum(exp),
                    labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)
          end

          savefig(wd_scatter * "fig_emp_multi_fcst_pi_ratio_m2_no_para_unc_over_m2_year$(yr0)_P$(Int(ii*10))_H$(hh).png")

     end
end

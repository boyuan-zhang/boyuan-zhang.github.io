####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Empirical Analysis, Balanced Panel
#####################################################################################################

#* This script calculates MSE for each estimator

####################################################################################################
#                             Part 0: INTRO
####################################################################################################

cd()
wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Balanced/"
cd(wd)

version = "_balanced"


wd_results = string(wd, "Results/")
# directory of MSE
wd_mse = string(wd_results, "MSE/")
# directory of LPS
wd_lps = string(wd_results, "LPS/")
# directory of data
wd_data = string(wd, "data", version, "/")
# directory of plots
wd_plots = string(wd, "Plots/")

# create folder for MSE
wd_plots_mse = string(wd_plots, "MSE/")
if !isdir(wd_plots_mse)
   mkdir(wd_plots_mse)
end

# create folder for LPS
wd_plots_lps = string(wd_plots, "LPS/")
if !isdir(wd_plots_lps)
   mkdir(wd_plots_lps)
end

# load packages (install them with Pkg.add() if needed)
using DelimitedFiles, MAT, Distributions, Plots

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# starting year
yr0 = 67
# end year (= 92(96) if last year = 1993(1997))
yr1 = 96
# number of observations in the sample
# bigT = [4, 6, 10, 15, 20, 25, 28]
bigT = 20


####################################################################################################
#                             Part 3: DRAW HISTOGRAMS
####################################################################################################

estimator_list = ["M2","M2_homosk","M2_HIP", "M2_RIP"]

MSE_mat = zeros(9, 4)
LPS_mat = zeros(9, 4)

for j in eachindex(estimator_list)

     estimator = estimator_list[j]

     # Load MSE
     temp = readdlm(wd_mse * "MSE_$estimator.csv", ',')
     MSE_mat[:,j] = temp[:,3]

     # Load LPS
     temp = readdlm(wd_lps * "LPS_$estimator.csv", ',')
     LPS_mat[:,j] = temp[:,3]
end



# calculate differentials
LPS_2plot = LPS_mat .- LPS_mat[:,1] 
LPS_2plot = LPS_2plot[:,2:end]

# sort by LPS of M2-RIP
ordering = sortperm(LPS_2plot[:, end])
LPS_2plot = LPS_2plot[ordering,:]

# calculate differentials
MSE_2plot = (MSE_mat ./ MSE_mat[:,1] .- 1) * 100
MSE_2plot = MSE_2plot[:,2:end]

# sort by LPS of M2-RIP
MSE_2plot = MSE_2plot[ordering,:]




### Generate figures
# MSE
plot(1:9, MSE_2plot[:,1], linewidth = 2.5, c = RGB(0,0.25,0.75), markershape = :+, markersize = 8, labels = "",
 framestyle = :box, size = (150*4,150*3), dpi = 100, ylims = (-20,20),
 xtickfontsize=18,ytickfontsize=18)
plot!(1:9, MSE_2plot[:,2], linewidth = 2.5, c = RGB(0.75,0.5,0.5), markershape = :star6, markersize = 8, labels = "")
plot!(1:9, MSE_2plot[:,3], linewidth = 2.5, c = RGB(0,0.25,0.25), markershape = :xcross, markersize = 8, labels = "")
hline!([0 0], c = :black, labels = "")

savefig(wd_plots_mse * "T$(bigT)_msfe_all_models_sorted.png")


# LPS
plot(1:9, LPS_2plot[:,1], linewidth = 2.5, c = RGB(0,0.25,0.75), markershape = :+, markersize = 8, labels = "",
 framestyle = :box, size = (150*4,150*3), dpi = 100, ylims = (-0.2,0.6),
 xtickfontsize=18,ytickfontsize=18)
plot!(1:9, LPS_2plot[:,2], linewidth = 2.5, c = RGB(0.75,0.5,0.5), markershape = :star6, markersize = 8, labels = "")
plot!(1:9, LPS_2plot[:,3], linewidth = 2.5, c = RGB(0,0.25,0.25), markershape = :xcross, markersize = 8, labels = "")
hline!([0 0], c = :black, labels = "")

savefig(wd_plots_lps * "T$(bigT)_lps_all_models_sorted.png")

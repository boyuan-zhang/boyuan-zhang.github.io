####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Empirical Analysis, Balanced Panel
#  Generate figures
#  Creation: 11/29/2019
#  Last change: 01/19/2022
#####################################################################################################

#* This script generate figure 3 and 7 in the paper

####################################################################################################
#                             Part 0: INTRO
####################################################################################################

cd()
wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Balanced/"
cd(wd)

estimator = "M2"

wd_plots = string(wd, "Plots/")
# wd_hist = string(wd_plots, "Hist/HIP/")
wd_hist = string(wd_plots, "Hist/", estimator, "/")

# folder of jld2 outout
wd_hist_temp = string(wd, "Estimates/", estimator, "/jld_temp/")

# create temp folder for alpha
wd_hist_alpha = string(wd_hist, "alpha/")
if !isdir(wd_hist_alpha)
   mkdir(wd_hist_alpha)
end

# create temp folder for rho
wd_hist_rho = string(wd_hist, "rho/")
if !isdir(wd_hist_rho)
   mkdir(wd_hist_rho)
end

# create temp folder for sigma
wd_hist_sigma2 = string(wd_hist, "sigma/")
if !isdir(wd_hist_sigma2)
   mkdir(wd_hist_sigma2)
end

# create temp folder for q
wd_hist_q = string(wd_hist, "q/")
if !isdir(wd_hist_q)
   mkdir(wd_hist_q)
end

# create temp folder for q
wd_hist_s = string(wd_hist, "s/")
if !isdir(wd_hist_s)
   mkdir(wd_hist_s)
end

# create folder for posterior hpdi
wd_post = string(wd_plots, "Post/")
if !isdir(wd_post)
   mkdir(wd_post)
end

wd_post = string(wd_post, estimator, "/")
if !isdir(wd_post)
   mkdir(wd_post)
end



# load packages (install them with Pkg.add() if needed)
using StatsPlots, KernelDensity, JLD2, Plots, SpecialFunctions, Distributions, StatisticalRethinking

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# selected years
tau1 = 88
tau2 = 91
# selected subsample size
T = 20


####################################################################################################
#                             Part 2: DRAW FIGURES 
####################################################################################################

###
#* Figure 4: Posterior for Idiosyncratic Parameters, M2, T = 20



# load posterior draws in JLD2 file, tau 1
label_tau1 = "T$(T)_tau$(tau1)_"

temp = load(wd_hist_temp * "$(label_tau1)output.jld2")
post_mean_ss_hetsk_tau1 = temp["post_mean_ss_hetsk"]
post_draw_ss_hetsk_tau1 = temp["post_draw_ss_hetsk"]

N_tau1 = length(post_mean_ss_hetsk_tau1.delta_alpha_hat[:,1])

# load posterior draws in JLD2 file, tau 2
label_tau2 = "T$(T)_tau$(tau2)_"

temp = load(wd_hist_temp * "$(label_tau2)output.jld2")
post_mean_ss_hetsk_tau2 = temp["post_mean_ss_hetsk"]
post_draw_ss_hetsk_tau2 = temp["post_draw_ss_hetsk"]

N_tau2 = length(post_mean_ss_hetsk_tau2.delta_alpha_hat[:,1])


#########################
# Post mean and hpdi
#########################

#------------------------------------------
#------------------------------------------

#* rho_i (median)

#* Tau 1
rho_i_draw_tau1 = post_draw_ss_hetsk_tau1.delta_rho_draw .+ median(post_draw_ss_hetsk_tau1.rho_draw)

# post Median
rho_i_post_med_tau1 = vec(median(rho_i_draw_tau1, dims = 1))

# post mean
rho_i_post_mean_tau1 = post_mean_ss_hetsk_tau1.delta_rho_hat .+ post_mean_ss_hetsk_tau1.rho_hat

temp = collect(zip(rho_i_post_med_tau1, rho_i_post_mean_tau1))
sort_idx = sortperm(temp)

rho_i_post_med_tau1 = rho_i_post_med_tau1[sort_idx]
rho_i_post_mean_tau1 = rho_i_post_mean_tau1[sort_idx]

# sort post draw given indexes from the real
rho_i_draw_tau1 = rho_i_draw_tau1[:, sort_idx]

# calculate hpdi
rho_i_hpdi_tau1 =  mapslices(x -> hpdi(x, alpha = 0.1), rho_i_draw_tau1; dims = 1)


#* Tau 2
rho_i_draw_tau2 = post_draw_ss_hetsk_tau2.delta_rho_draw .+ median(post_draw_ss_hetsk_tau2.rho_draw)

# post Median
rho_i_post_med_tau2 = vec(median(rho_i_draw_tau2, dims = 1))

# post mean
rho_i_post_mean_tau2 = post_mean_ss_hetsk_tau2.delta_rho_hat .+ post_mean_ss_hetsk_tau2.rho_hat

temp = collect(zip(rho_i_post_med_tau2, rho_i_post_mean_tau2))
sort_idx = sortperm(temp)

rho_i_post_med_tau2 = rho_i_post_med_tau2[sort_idx]
rho_i_post_mean_tau2 = rho_i_post_mean_tau2[sort_idx]

# sort post draw given indexes from the real
rho_i_draw_tau2 = rho_i_draw_tau2[:, sort_idx]

# calculate hpdi
rho_i_hpdi_tau2 =  mapslices(x -> hpdi(x, alpha = 0.1), rho_i_draw_tau2; dims = 1)


# draw plot
ymax = maximum([rho_i_hpdi_tau1[2,:]; rho_i_hpdi_tau2[2,:]; rho_i_post_mean_tau1; rho_i_post_mean_tau2])
ymin = minimum([rho_i_hpdi_tau1[1,:]; rho_i_hpdi_tau2[1,:]; rho_i_post_mean_tau1; rho_i_post_mean_tau2])

if ymax > 0
   ymax = sign(ymax) * abs(ymax) * 1.1
else 
   ymax = sign(ymax) * abs(ymax) * 0.9
end

if ymin > 0
   ymin = sign(ymin) * abs(ymin) * 0.9
else 
   ymin = sign(ymin) * abs(ymin) * 1.1
end

plot(1:N_tau1, rho_i_post_mean_tau1, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N_tau1, rho_i_post_med_tau1, linewidth = 2,
   ribbon = (rho_i_post_med_tau1 - rho_i_hpdi_tau1[1,:], rho_i_hpdi_tau1[2,:] - rho_i_post_med_tau1), 
   fillalpha = 0.15, c = 1, ylim = (ymin, ymax),
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_rho_med_T$(T)_tau$(tau1).png")

# draw plot
plot(1:N_tau2, rho_i_post_mean_tau2, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N_tau2, rho_i_post_med_tau2, linewidth = 2,
   ribbon = (rho_i_post_med_tau2 - rho_i_hpdi_tau2[1,:], rho_i_hpdi_tau2[2,:] - rho_i_post_med_tau2), 
   fillalpha = 0.15, c = 1, ylim = (ymin, ymax),
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_rho_med_T$(T)_tau$(tau2).png")









#* alpha_i0 (median)
#* Tau 1
alpha_i_draw_tau1 = post_draw_ss_hetsk_tau1.delta_alpha_draw[:,1,:] .+ median(post_draw_ss_hetsk_tau1.alpha_draw[:,1])

# post Median
alpha_i_post_med_tau1 = vec(median(alpha_i_draw_tau1, dims = 1))

# post mean
alpha_i_post_mean_tau1 = post_mean_ss_hetsk_tau1.delta_alpha_hat[:,1] .+ post_mean_ss_hetsk_tau1.alpha_hat[1]

# sort_idx = sortperm(vec(alpha_i_post_med))

temp = collect(zip(alpha_i_post_med_tau1, alpha_i_post_mean_tau1))
sort_idx = sortperm(temp)

alpha_i_post_med_tau1 = alpha_i_post_med_tau1[sort_idx]
alpha_i_post_mean_tau1 = alpha_i_post_mean_tau1[sort_idx]

# sort post draw given indexes from the real
alpha_i_draw_tau1 = alpha_i_draw_tau1[:,sort_idx]

# calculate hpdi
alpha_i_hpdi_tau1 =  mapslices(x -> hpdi(x, alpha = 0.1), alpha_i_draw_tau1; dims = 1)

#* Tau 2
alpha_i_draw_tau2 = post_draw_ss_hetsk_tau2.delta_alpha_draw[:,1,:] .+ median(post_draw_ss_hetsk_tau2.alpha_draw[:,1])

# post Median
alpha_i_post_med_tau2 = vec(median(alpha_i_draw_tau2, dims = 1))

# post mean
alpha_i_post_mean_tau2 = post_mean_ss_hetsk_tau2.delta_alpha_hat[:,1] .+ post_mean_ss_hetsk_tau2.alpha_hat[1]

# sort_idx = sortperm(vec(alpha_i_post_med))

temp = collect(zip(alpha_i_post_med_tau2, alpha_i_post_mean_tau2))
sort_idx = sortperm(temp)

alpha_i_post_med_tau2 = alpha_i_post_med_tau2[sort_idx]
alpha_i_post_mean_tau2 = alpha_i_post_mean_tau2[sort_idx]

# sort post draw given indexes from the real
alpha_i_draw_tau2 = alpha_i_draw_tau2[:,sort_idx]

# calculate hpdi
alpha_i_hpdi_tau2 =  mapslices(x -> hpdi(x, alpha = 0.1), alpha_i_draw_tau2; dims = 1)


# draw plot
ymax = maximum([alpha_i_hpdi_tau1[2,:]; alpha_i_hpdi_tau2[2,:]; alpha_i_post_mean_tau1; alpha_i_post_mean_tau2])
ymin = minimum([alpha_i_hpdi_tau1[1,:]; alpha_i_hpdi_tau2[1,:]; alpha_i_post_mean_tau1; alpha_i_post_mean_tau2])

if ymax > 0
   ymax = sign(ymax) * abs(ymax) * 1.1
else 
   ymax = sign(ymax) * abs(ymax) * 0.9
end

if ymin > 0
   ymin = sign(ymin) * abs(ymin) * 0.9
else 
   ymin = sign(ymin) * abs(ymin) * 1.1
end


plot(1:N_tau1, alpha_i_post_mean_tau1, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N_tau1, alpha_i_post_med_tau1, linewidth = 2,
   ribbon = (alpha_i_post_med_tau1 - alpha_i_hpdi_tau1[1,:], alpha_i_hpdi_tau1[2,:] - alpha_i_post_med_tau1), 
   fillalpha = 0.15, c = 1, ylim = (ymin, ymax),
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_alpha0_med_T$(T)_tau$(tau1).png")


plot(1:N_tau2, alpha_i_post_mean_tau2, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N_tau2, alpha_i_post_med_tau2, linewidth = 2,
   ribbon = (alpha_i_post_med_tau2 - alpha_i_hpdi_tau2[1,:], alpha_i_hpdi_tau2[2,:] - alpha_i_post_med_tau2), 
   fillalpha = 0.15, c = 1, ylim = (ymin, ymax),
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_alpha0_med_T$(T)_tau$(tau2).png")




#* alpha_i1 (median)
#* Tau 1
alpha_i_draw_tau1 = post_draw_ss_hetsk_tau1.delta_alpha_draw[:,2,:] .+ median(post_draw_ss_hetsk_tau1.alpha_draw[:,2])

# post Median
alpha_i_post_med_tau1 = vec(median(alpha_i_draw_tau1, dims = 1))

# post mean
alpha_i_post_mean_tau1 = post_mean_ss_hetsk_tau1.delta_alpha_hat[:,2] .+ post_mean_ss_hetsk_tau1.alpha_hat[2]

# sort_idx = sortperm(vec(alpha_i_post_med))

temp = collect(zip(alpha_i_post_med_tau1, alpha_i_post_mean_tau1))
sort_idx = sortperm(temp)

alpha_i_post_med_tau1 = alpha_i_post_med_tau1[sort_idx]
alpha_i_post_mean_tau1 = alpha_i_post_mean_tau1[sort_idx]

# sort post draw given indexes from the real
alpha_i_draw_tau1 = alpha_i_draw_tau1[:,sort_idx]

# calculate hpdi
alpha_i_hpdi_tau1 =  mapslices(x -> hpdi(x, alpha = 0.1), alpha_i_draw_tau1; dims = 1)

#* Tau 2
alpha_i_draw_tau2 = post_draw_ss_hetsk_tau2.delta_alpha_draw[:,2,:] .+ median(post_draw_ss_hetsk_tau2.alpha_draw[:,2])

# post Median
alpha_i_post_med_tau2 = vec(median(alpha_i_draw_tau2, dims = 1))

# post mean
alpha_i_post_mean_tau2 = post_mean_ss_hetsk_tau2.delta_alpha_hat[:,2] .+ post_mean_ss_hetsk_tau2.alpha_hat[2]

# sort_idx = sortperm(vec(alpha_i_post_med))

temp = collect(zip(alpha_i_post_med_tau2, alpha_i_post_mean_tau2))
sort_idx = sortperm(temp)

alpha_i_post_med_tau2 = alpha_i_post_med_tau2[sort_idx]
alpha_i_post_mean_tau2 = alpha_i_post_mean_tau2[sort_idx]

# sort post draw given indexes from the real
alpha_i_draw_tau2 = alpha_i_draw_tau2[:,sort_idx]

# calculate hpdi
alpha_i_hpdi_tau2 =  mapslices(x -> hpdi(x, alpha = 0.1), alpha_i_draw_tau2; dims = 1)


# draw plot
ymax = maximum([alpha_i_hpdi_tau1[2,:]; alpha_i_hpdi_tau2[2,:]; alpha_i_post_mean_tau1; alpha_i_post_mean_tau2])
ymin = minimum([alpha_i_hpdi_tau1[1,:]; alpha_i_hpdi_tau2[1,:]; alpha_i_post_mean_tau1; alpha_i_post_mean_tau2])

if ymax > 0
   ymax = sign(ymax) * abs(ymax) * 1.1
else 
   ymax = sign(ymax) * abs(ymax) * 0.9
end

if ymin > 0
   ymin = sign(ymin) * abs(ymin) * 0.9
else 
   ymin = sign(ymin) * abs(ymin) * 1.1
end


plot(1:N_tau1, alpha_i_post_mean_tau1./10, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N_tau1, alpha_i_post_med_tau1./10, linewidth = 2,
   ribbon = (alpha_i_post_med_tau1./10 - alpha_i_hpdi_tau1[1,:]./10, alpha_i_hpdi_tau1[2,:]./10 - alpha_i_post_med_tau1./10), 
   fillalpha = 0.15, c = 1, ylim = (ymin/10, ymax/10),
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_alpha1_med_T$(T)_tau$(tau1).png")


plot(1:N_tau2, alpha_i_post_mean_tau2./10, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N_tau2, alpha_i_post_med_tau2./10, linewidth = 2,
   ribbon = (alpha_i_post_med_tau2./10 - alpha_i_hpdi_tau2[1,:]./10, alpha_i_hpdi_tau2[2,:]./10 - alpha_i_post_med_tau2./10), 
   fillalpha = 0.15, c = 1, ylim = (ymin/10, ymax/10),
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_alpha1_med_T$(T)_tau$(tau2).png")






#* delta_sigma_u (median)
#* Tau 1
delta_sigma_u_draw_tau1 = post_draw_ss_hetsk_tau1.delta_sigma_u_draw

delta_sigma_u_post_med_tau1 = vec(median(delta_sigma_u_draw_tau1, dims = 1))
sort_idx = sortperm(vec(delta_sigma_u_post_med_tau1))
delta_sigma_u_post_med_tau1 = delta_sigma_u_post_med_tau1[sort_idx]

# sort post draw given indexes from the real
delta_sigma_u_draw_tau1 = delta_sigma_u_draw_tau1[:,sort_idx]

# post mean
delta_sigma_u_post_mean_tau1 = post_mean_ss_hetsk_tau1.delta_sigma_u_hat
delta_sigma_u_post_mean_tau1 = delta_sigma_u_post_mean_tau1[sort_idx]

# calculate hpdi
delta_sigma_u_hpdi_tau1 =  mapslices(x -> hpdi(x, alpha = 0.1), delta_sigma_u_draw_tau1; dims=1)


#* Tau 2
delta_sigma_u_draw_tau2 = post_draw_ss_hetsk_tau2.delta_sigma_u_draw

delta_sigma_u_post_med_tau2 = vec(median(delta_sigma_u_draw_tau2, dims = 1))
sort_idx = sortperm(vec(delta_sigma_u_post_med_tau2))
delta_sigma_u_post_med_tau2 = delta_sigma_u_post_med_tau2[sort_idx]

# sort post draw given indexes from the real
delta_sigma_u_draw_tau2 = delta_sigma_u_draw_tau2[:,sort_idx]

# post mean
delta_sigma_u_post_mean_tau2 = post_mean_ss_hetsk_tau2.delta_sigma_u_hat
delta_sigma_u_post_mean_tau2 = delta_sigma_u_post_mean_tau2[sort_idx]

# calculate hpdi
delta_sigma_u_hpdi_tau2 =  mapslices(x -> hpdi(x, alpha = 0.1), delta_sigma_u_draw_tau2; dims=1)

# draw plot
ymax = maximum([delta_sigma_u_hpdi_tau1[2,:]; delta_sigma_u_hpdi_tau2[2,:]; delta_sigma_u_post_mean_tau1; delta_sigma_u_post_mean_tau2])
ymin = minimum([delta_sigma_u_hpdi_tau1[1,:]; delta_sigma_u_hpdi_tau2[1,:]; delta_sigma_u_post_mean_tau1; delta_sigma_u_post_mean_tau2])

if ymax > 0
   ymax = sign(ymax) * abs(ymax) * 1.1
else 
   ymax = sign(ymax) * abs(ymax) * 0.9
end

if ymin > 0
   ymin = sign(ymin) * abs(ymin) * 0.9
else 
   ymin = sign(ymin) * abs(ymin) * 1.1
end

plot(1:N_tau1, delta_sigma_u_post_mean_tau1, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N_tau1, delta_sigma_u_post_med_tau1, linewidth = 2,
   ribbon = (delta_sigma_u_post_med_tau1 - delta_sigma_u_hpdi_tau1[1,:], delta_sigma_u_hpdi_tau1[2,:] - delta_sigma_u_post_med_tau1), fillalpha = 0.15, c = 1, ylim = (ymin, ymax),
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_delta_sigma_u_med_T$(T)_tau$(tau1).png")


plot(1:N_tau2, delta_sigma_u_post_mean_tau2, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N_tau2, delta_sigma_u_post_med_tau2, linewidth = 2,
   ribbon = (delta_sigma_u_post_med_tau2 - delta_sigma_u_hpdi_tau2[1,:], delta_sigma_u_hpdi_tau2[2,:] - delta_sigma_u_post_med_tau2), fillalpha = 0.15, c = 1, ylim = (ymin, ymax),
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_delta_sigma_u_med_T$(T)_tau$(tau2).png")




#* delta_sigma_e (median)
#* Tau 1
delta_sigma_e_draw_tau1 = post_draw_ss_hetsk_tau1.delta_sigma_e_draw

delta_sigma_e_post_med_tau1 = vec(median(delta_sigma_e_draw_tau1, dims = 1))
sort_idx = sortperm(vec(delta_sigma_e_post_med_tau1))
delta_sigma_e_post_med_tau1 = delta_sigma_e_post_med_tau1[sort_idx]

# sort post draw given indexes from the real
delta_sigma_e_draw_tau1 = delta_sigma_e_draw_tau1[:,sort_idx]

# post mean
delta_sigma_e_post_mean_tau1 = post_mean_ss_hetsk_tau1.delta_sigma_e_hat
delta_sigma_e_post_mean_tau1 = delta_sigma_e_post_mean_tau1[sort_idx]

# calculate hpdi
delta_sigma_e_hpdi_tau1 =  mapslices(x -> hpdi(x, alpha = 0.1), delta_sigma_e_draw_tau1; dims=1)


#* Tau 2
delta_sigma_e_draw_tau2 = post_draw_ss_hetsk_tau2.delta_sigma_e_draw

delta_sigma_e_post_med_tau2 = vec(median(delta_sigma_e_draw_tau2, dims = 1))
sort_idx = sortperm(vec(delta_sigma_e_post_med_tau2))
delta_sigma_e_post_med_tau2 = delta_sigma_e_post_med_tau2[sort_idx]

# sort post draw given indexes from the real
delta_sigma_e_draw_tau2 = delta_sigma_e_draw_tau2[:,sort_idx]

# post mean
delta_sigma_e_post_mean_tau2 = post_mean_ss_hetsk_tau2.delta_sigma_e_hat
delta_sigma_e_post_mean_tau2 = delta_sigma_e_post_mean_tau2[sort_idx]

# calculate hpdi
delta_sigma_e_hpdi_tau2 =  mapslices(x -> hpdi(x, alpha = 0.1), delta_sigma_e_draw_tau2; dims=1)

# draw plot
ymax = maximum([delta_sigma_e_hpdi_tau1[2,:]; delta_sigma_e_hpdi_tau2[2,:]; delta_sigma_e_post_mean_tau1; delta_sigma_e_post_mean_tau2])
ymin = minimum([delta_sigma_e_hpdi_tau1[1,:]; delta_sigma_e_hpdi_tau2[1,:]; delta_sigma_e_post_mean_tau1; delta_sigma_e_post_mean_tau2])

if ymax > 0
   ymax = sign(ymax) * abs(ymax) * 1.1
else 
   ymax = sign(ymax) * abs(ymax) * 0.9
end

if ymin > 0
   ymin = sign(ymin) * abs(ymin) * 0.9
else 
   ymin = sign(ymin) * abs(ymin) * 1.1
end

plot(1:N_tau1, delta_sigma_e_post_mean_tau1, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N_tau1, delta_sigma_e_post_med_tau1, linewidth = 2,
   ribbon = (delta_sigma_e_post_med_tau1 - delta_sigma_e_hpdi_tau1[1,:], delta_sigma_e_hpdi_tau1[2,:] - delta_sigma_e_post_med_tau1), fillalpha = 0.15, c = 1, ylim = (ymin, ymax),
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_delta_sigma_e_med_T$(T)_tau$(tau1).png")


plot(1:N_tau2, delta_sigma_e_post_mean_tau2, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N_tau2, delta_sigma_e_post_med_tau2, linewidth = 2,
   ribbon = (delta_sigma_e_post_med_tau2 - delta_sigma_e_hpdi_tau2[1,:], delta_sigma_e_hpdi_tau2[2,:] - delta_sigma_e_post_med_tau2), fillalpha = 0.15, c = 1, ylim = (ymin, ymax),
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_delta_sigma_e_med_T$(T)_tau$(tau2).png")















#------------------------------------------
#------------------------------------------

###
#* Figure 7: Evolution of Average Idiosyncratic Volatility

year_inc = 4

T2 = T + 2

# create year list for y-axis (sigma and s)
list_years_tau1 = 1900 + tau1 - T2 + 1 .+ (1:T)
list_years_tau2 = 1900 + tau2 - T2 + 1 .+ (1:T)


#* sigma2_u
#* Tau 1
sigma2_u_post_mean_tau1 = post_mean_ss_hetsk_tau1.sigma2_u_hat[2:end]
sigma2_u_draw_tau1 = post_draw_ss_hetsk_tau1.sigma2_u_draw[:,2:end]
# calculate hpdi
sigma2_u_hpdi_tau1 = mapslices(x -> hpdi(x, alpha = 0.1), sigma2_u_draw_tau1; dims=1)


#* Tau 2
sigma2_u_post_mean_tau2 = post_mean_ss_hetsk_tau2.sigma2_u_hat[2:end]
sigma2_u_draw_tau2 = post_draw_ss_hetsk_tau2.sigma2_u_draw[:,2:end]
# calculate hpdi
sigma2_u_hpdi_tau2 = mapslices(x -> hpdi(x, alpha = 0.1), sigma2_u_draw_tau2; dims=1)


# draw plot
plot(list_years_tau1, sigma2_u_post_mean_tau1, linewidth = 2,
   ribbon = (sigma2_u_post_mean_tau1 - sigma2_u_hpdi_tau1[1,:], sigma2_u_hpdi_tau1[2,:] - sigma2_u_post_mean_tau1), 
   fillalpha = 0.15, c = 1, ylim = (0.004, 0.05),
   xticks = list_years_tau1[1]:year_inc:list_years_tau2[end],
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

plot!(list_years_tau2, sigma2_u_post_mean_tau2, linewidth = 2,
   ribbon = (sigma2_u_post_mean_tau2 - sigma2_u_hpdi_tau2[1,:], sigma2_u_hpdi_tau2[2,:] - sigma2_u_post_mean_tau2), 
   fillalpha = 0.15, c = 2, labels = "")

vspan!([1969.75, 1970.75 + 0.25], c = :gray, fillalpha = 0.15, labels = "")
vspan!([1973.75, 1975.00 + 0.25], c = :gray, fillalpha = 0.15, labels = "")
vspan!([1980.00, 1980.50 + 0.25], c = :gray, fillalpha = 0.15, labels = "")
vspan!([1981.50, 1982.75 + 0.25], c = :gray, fillalpha = 0.15, labels = "")

savefig(wd_post * "fig_emp_post_sigma2_u_T$(T)_tau$(tau1)_and_tau$(tau2).png")




#* sigma2_e
#* Tau 1
sigma2_e_post_mean_tau1 = post_mean_ss_hetsk_tau1.sigma2_e_hat[2:end]
sigma2_e_draw_tau1 = post_draw_ss_hetsk_tau1.sigma2_e_draw[:,2:end]
# calculate hpdi
sigma2_e_hpdi_tau1 = mapslices(x -> hpdi(x, alpha = 0.1), sigma2_e_draw_tau1; dims=1)


#* Tau 2
sigma2_e_post_mean_tau2 = post_mean_ss_hetsk_tau2.sigma2_e_hat[2:end]
sigma2_e_draw_tau2 = post_draw_ss_hetsk_tau2.sigma2_e_draw[:,2:end]
# calculate hpdi
sigma2_e_hpdi_tau2 = mapslices(x -> hpdi(x, alpha = 0.1), sigma2_e_draw_tau2; dims=1)


# draw plot
plot(list_years_tau1, sigma2_e_post_mean_tau1, linewidth = 2,
   ribbon = (sigma2_e_post_mean_tau1 - sigma2_e_hpdi_tau1[1,:], sigma2_e_hpdi_tau1[2,:] - sigma2_e_post_mean_tau1), 
   fillalpha = 0.15, c = 1, ylim = (0.004, 0.05),
   xticks = list_years_tau1[1]:year_inc:list_years_tau2[end],
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

plot!(list_years_tau2, sigma2_e_post_mean_tau2, linewidth = 2,
   ribbon = (sigma2_e_post_mean_tau2 - sigma2_e_hpdi_tau2[1,:], sigma2_e_hpdi_tau2[2,:] - sigma2_e_post_mean_tau2), 
   fillalpha = 0.15, c = 2, labels = "")

# 1969:Q4 (Peak) - 1970:Q4 (Trough); 1973:Q4 (P) - 1975:Q1; 1980:Q1 (P) to 1980:Q3 (T); 1981:Q3 (P) to 1982:Q4; 1990:Q3 (P) to 1991:Q1.
vspan!([1969.75, 1970.75 + 0.25], c = :gray, fillalpha = 0.15, labels = "")
vspan!([1973.75, 1975.00 + 0.25], c = :gray, fillalpha = 0.15, labels = "")
vspan!([1980.00, 1980.50 + 0.25], c = :gray, fillalpha = 0.15, labels = "")
vspan!([1981.50, 1982.75 + 0.25], c = :gray, fillalpha = 0.15, labels = "")

savefig(wd_post * "fig_emp_post_sigma2_e_T$(T)_tau$(tau1)_and_tau$(tau2).png")



println("Plots are ready.")


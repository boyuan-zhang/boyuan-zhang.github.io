####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Empirical Analysis, Balanced Panel
#####################################################################################################

#* This script calculates LPS for each estimator

####################################################################################################
#                             Part 0: INTRO
####################################################################################################

cd()
wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Balanced/"
cd(wd)

version = "_balanced"

# directory of LPS
wd_results = string(wd, "Results/")
# create lps folder under Results
wd_lps = string(wd_results, "LPS/")
if !isdir(wd_lps)
     mkdir(wd_lps)
end

# directory of data
wd_data = string(wd, "data", version, "/")

# load packages (install them with Pkg.add() if needed)
using DelimitedFiles, MAT, Distributions, JLD2

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# starting year
yr0 = 67
# end year (= 92(96) if last year = 1993(1997))
yr1 = 96
# number of observations in the sample
# bigT = [4, 6, 10, 15, 20, 25, 28]
bigT = 20

####################################################################################################
#                             Part 3: DRAW HISTOGRAMS
####################################################################################################

estimator_list = ["M2","M2_homosk","M2_HIP", "M2_RIP"]

for j in eachindex(estimator_list)

     estimator = estimator_list[j]

     # folder of jld2 outout
     wd_hist_temp = string(wd, "Estimates/", estimator, "/jld_temp/")

     output = zeros(200,3)
     counter = 0

     for T = bigT

          # T = 10
          T2 = T + 2

          for t_smpl = (yr0 + T2 - 1):yr1
               # t_smpl = (yr0 + T2 - 1)
               counter += 1

               label = "T$(T)_tau$(t_smpl)_"

               # load posterior draws in JLD2 file
               temp = load(wd_hist_temp * "$(label)output.jld2")
               post_mean_ss_hetsk = temp["post_mean_ss_hetsk"]
               post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

               nMCMC = size(post_draw_ss_hetsk.delta_alpha_draw, 1)

               # load the data
               raw = readdlm(string(wd_data, label, "data.txt"), ' ')

               id = unique(raw[:,1])
               N  = length(id)

               Y = zeros(T2, N)
               h = zeros(T2, N)
               for t = 1:T2
               for i = 1:N
                    selected = (abs.(raw[:,1] .- id[i]) .< 0.05) .& (abs.(raw[:,2] .- (t_smpl-T2+t)) .< 0.05)
                    Y[t,i] = raw[selected, 3][1]
                    h[t,i] = raw[selected, 5][1]
               end
               end

               if estimator == "SS_HIP_hetsk_w_alpha_quad"
                    H_last = [ones(N,1) h[end,:]/10 (h[end,:]/10).^2];
               else
                    H_last = [ones(N,1) h[end,:]/10]
               end
          
               # calculate LPS
               LPS = zeros(N,1)

               for m = 1:nMCMC
                    # m = 1

                    alpha = post_draw_ss_hetsk.alpha_draw[m,:]
                    delta_alpha = post_draw_ss_hetsk.delta_alpha_draw[m,:,:]

                    rho = post_draw_ss_hetsk.rho_draw[m]
                    delta_rho = post_draw_ss_hetsk.delta_rho_draw[m,:]

                    if estimator in ["M2", "M2_RIP", "M2_HIP"]

                         s_last = post_draw_ss_hetsk.s_draw[m,:,end]

                         delta_sigma = post_draw_ss_hetsk.delta_sigma_u_draw[m,:]
                         sigma2 = post_draw_ss_hetsk.sigma2_u_draw[m, end]

                         # Mean
                         den_mean = sum(H_last .* (alpha .+ delta_alpha)', dims = 2) + s_last .* (rho .+ delta_rho)
                         # variance
                         den_var  = delta_sigma .* sigma2

                    elseif estimator == "M2_homosk"

                         s_last = post_draw_ss_hetsk.s_draw[m,:,end]

                         delta_sigma = ones(N,1)
                         sigma2 = post_draw_ss_hetsk.sigma2_u_draw[m, end]

                         # Mean
                         den_mean = sum(H_last .* (alpha .+ delta_alpha)', dims = 2) + s_last .* (rho .+ delta_rho)
                         # variance
                         den_var  = delta_sigma .* sigma2
                    
                    elseif estimator == "M1"

                         delta_sigma = post_draw_ss_hetsk.delta_sigma_draw[m,:]
                         sigma2 = post_draw_ss_hetsk.sigma2_draw[m]

                         # Mean
                         den_mean = alpha .+ delta_alpha + Y[end-1,:] .* (rho .+ delta_rho)
                         # variance
                         den_var  = delta_sigma .* sigma2

                    end
                    # predictive density eval at the true value
                    den = [pdf(Normal(den_mean[ii], sqrt(den_var[ii])), Y[end,ii]) for ii in 1:N]

                    LPS = LPS - den/nMCMC
               end

               output[counter,:] = [T t_smpl mean(LPS)]

          end

     end

     output = output[1:counter, :]
     writedlm( wd_lps * "LPS_$estimator.csv",  output, ',')
end


####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Empirical Analysis, Balanced Panel
#####################################################################################################

#* This script simulates income process given the estimate of M2 
#* derive the cross-sectional variance after shutting down certain delta 
#* and calculate variance ratio relative to M2 model.

#* This script generate figure 6 in the paper


####################################################################################################
#                             Part 0: INTRO
####################################################################################################

cd()
wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Balanced/"
cd(wd)

estimator = "M2"

version = "_balanced"

wd_data = string(wd, "data", version, "/")

wd_plots = string(wd, "Plots/")

# create a folder under Plots
wd_decomp_plot = string(wd_plots, "Decomp_Income/")
if !isdir(wd_decomp_plot)
     mkdir(wd_decomp_plot)
end

# folder of jld2 outout
wd_hist_temp = string(wd, "Estimates/", estimator, "/jld_temp/")

### directory of decomp_income
wd_results = string(wd, "Results/")
# create subfolder under Results
wd_decomp = string(wd_results, "Decomp_Income/")
if !isdir(wd_decomp)
     mkdir(wd_decomp)
end

# load packages (install them with Pkg.add() if needed)
using StatsPlots, JLD2, Plots, Distributions, StatisticalRethinking, DelimitedFiles, Random, Colors

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# number of units
N = 10000
# horizons
horizion = 20
# starting year
yr0 = 88
# long panel (T = 25)
T = 20

### Parameters
# load posterior draws in JLD2 file
label_est = "T$(T)_tau$(yr0)_"
temp = load(wd_hist_temp * "$(label_est)output.jld2")
post_mean_ss_hetsk = temp["post_mean_ss_hetsk"]
post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

# parameters to fix
alpha    = vec(post_mean_ss_hetsk.alpha_hat)
rho      = post_mean_ss_hetsk.rho_hat
sigma2_u = post_mean_ss_hetsk.sigma2_u_hat[end]
sigma2_e = post_mean_ss_hetsk.sigma2_e_hat[end]

q_alpha   = post_mean_ss_hetsk.q_alpha_hat
q_rho     = post_mean_ss_hetsk.q_rho_hat
q_sigma_u = post_mean_ss_hetsk.q_sigma_u_hat
q_sigma_e = post_mean_ss_hetsk.q_sigma_e_hat

vdelta_alpha = post_mean_ss_hetsk.vdelta_alpha_hat
vdelta_rho   = post_mean_ss_hetsk.vdelta_rho_hat
vdelta_sigma_u = post_mean_ss_hetsk.vdelta_sigma_u_hat
vdelta_sigma_e = post_mean_ss_hetsk.vdelta_sigma_e_hat

s0_mean = post_mean_ss_hetsk.s0_mean_hat
s0_var  = post_mean_ss_hetsk.s0_var_hat


# fix random seed
Random.seed!(1)

# draw δ_alpha
z_alpha = rand(Bernoulli(q_alpha), N)

zero_alpha_pos = collect(1:N)[z_alpha .== 0]

delta_alpha = rand(MvNormal(zeros(length(alpha)), vdelta_alpha), N)'
if length(zero_alpha_pos) != 0
     delta_alpha[zero_alpha_pos,:] .= 0
end

# draw δ_rho 
z_rho = rand(Bernoulli(q_rho), N)

zero_rho_pos = collect(1:N)[z_rho .== 0]

delta_rho = rand(Normal(0, sqrt(vdelta_rho)), N)

if length(zero_rho_pos) != 0
     delta_rho[zero_rho_pos] .= 0
end

# helper functions
IG_nu(mean, sd) = 4+2*mean^2/sd^2
IG_tau(mean, sd) = 2*mean*(1+mean^2/sd^2)

# draw δ_sigma_u
z_sigma_u = rand(Bernoulli(q_sigma_u), N)
zero_sigma_u_pos = collect(1:N)[z_sigma_u .== 0]

nu_delta_sigma_u  = IG_nu(1, sqrt(vdelta_sigma_u))
tau_delta_sigma_u = IG_tau(1, sqrt(vdelta_sigma_u))

delta_sigma_u = rand(InverseGamma(nu_delta_sigma_u/2, tau_delta_sigma_u/2), N)

if length(zero_sigma_u_pos) != 0
     delta_sigma_u[zero_sigma_u_pos] .= 1
end

# draw δ_sigma_e
z_sigma_e = rand(Bernoulli(q_sigma_e), N)
zero_sigma_e_pos = collect(1:N)[z_sigma_e .== 0]

nu_delta_sigma_e  = IG_nu(1, sqrt(vdelta_sigma_e))
tau_delta_sigma_e = IG_tau(1, sqrt(vdelta_sigma_e))

delta_sigma_e = rand(InverseGamma(nu_delta_sigma_e/2, tau_delta_sigma_e/2), N)

if length(zero_sigma_e_pos) != 0
     delta_sigma_e[zero_sigma_e_pos] .= 1
end

# s_{i0}
s_0 = rand(Normal(s0_mean, sqrt(s0_var)), N)

# draw errors
err_u = randn(10000, 1)
err_e = randn(10000, 1)





### generate baseline forecast
y_simul = zeros(N, horizion)

# initialization
H_last = [1.0; 1.0]
s_last = s_0

for j in 1:horizion

     # forecast s
     s_fcst = (rho .+ delta_rho) .* s_last + sqrt.(sigma2_e .* delta_sigma_e) .* err_e

     # forecast y
     y_fcst = (alpha' .+ delta_alpha) * H_last + s_fcst + sqrt.(sigma2_u .* delta_sigma_u) .* err_u

     # update last observation
     H_last[2] = H_last[2] + 1/10
     s_last    = s_fcst

     # save predicted value
     y_simul[:,j] = y_fcst

end

income_var_h = var(y_simul, dims = 1)'






### generate forecast - shut down delta - alpha
y_simul2 = zeros(N, horizion)

# initialization
H_last = [1.0; 1.0]
s_last = s_0

for j in 1:horizion

     # forecast s
     s_fcst = (rho .+ delta_rho) .* s_last + sqrt.(sigma2_e .* delta_sigma_e) .* err_e

     # forecast y
     y_fcst = alpha' * H_last .+ s_fcst + sqrt.(sigma2_u .* delta_sigma_u) .* err_u

     # update last observation
     H_last[2] = H_last[2] + 1/10
     s_last    = s_fcst

     # save predicted value
     y_simul2[:,j] = y_fcst

end

income_var_h2 = var(y_simul2, dims = 1)'

var_ratio_alpha = income_var_h2 ./ income_var_h






### generate forecast - shut down u_{it}
y_simul2 = zeros(N, horizion)

# initialization
H_last = [1.0; 1.0]
s_last = s_0

for j in 1:horizion

     # forecast s
     s_fcst = (rho .+ delta_rho) .* s_last + sqrt.(sigma2_e .* delta_sigma_e) .* err_e

     # forecast y
     y_fcst = (alpha' .+ delta_alpha) * H_last + s_fcst

     # update last observation
     H_last[2] = H_last[2] + 1/10
     s_last    = s_fcst

     # save predicted value
     y_simul2[:,j] = y_fcst

end

income_var_h2 = var(y_simul2, dims = 1)'

var_ratio_u = income_var_h2 ./ income_var_h



### Generate figure
plot(1:horizion, 1 .- var_ratio_alpha, linewidth = 2, ylims = (-0.01,0.5), xlims = (1, horizion),
     xlabel = "Years of Experience", guidefontsize = 8, 
     labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)
plot!(1:horizion, 1 .- var_ratio_u, linewidth = 2, labels = "")

savefig(wd_decomp_plot * "fig_emp_decomp_income_alpha_and_u_horizon$(horizion)_T$(T)_tau$(yr0).png")

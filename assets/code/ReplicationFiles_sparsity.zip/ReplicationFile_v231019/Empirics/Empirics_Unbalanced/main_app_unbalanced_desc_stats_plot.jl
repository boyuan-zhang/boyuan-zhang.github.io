####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Empirical Analysis, unbalanced Panel
#####################################################################################################

#* This script generates figure for descriptive statistics of unbalanced sample (figure 3)

####################################################################################################
#                             Part 0: INTRO
####################################################################################################
cd()

wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Unbalanced/"

version = "_unbalanced"

wd_data = string(wd, "data", version, "/")

# create folder: Plots
wd_plots = string(wd, "Plots/")

# create descriptive folder
wd_descr = string(wd_plots, "Descr_Unbalanced/")
if !isdir(wd_descr)
   mkdir(wd_descr)
end

cd(wd)

# load packages (install them with Pkg.add() if needed)
using Pkg, Dates, Random, Distributions, IterTools, Expectations, Polynomials, SpecialFunctions
using LinearAlgebra, JLD2, FileIO, DataFrames, Plots, MutableNamedTuples, DelimitedFiles, MAT, StatsBase
using StatisticalRethinking # Bayesian 
using SkipNan

using DelimitedFiles, Plots

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# starting year
yr0 = 67
# end year (= 92(96) if last year = 1993(1997))
yr1 = 96

T = yr1 - yr0 + 1


# load the data
raw = readdlm(string(wd_data, "unbalanced_data_incl_NA.txt"), ' ')
# replace NA with NaN
raw = replace(raw, "NA" => NaN) 

id = unique(raw[:,1])
N  = length(id)

Y = zeros(T, N)
h = zeros(T, N)

for i = 1:N
   selected = (abs.(raw[:,1] .- id[i]) .< 0.05)
   Y[:,i] = raw[selected, 3]
   h[:,i] = raw[selected, 5]
end

# remove the last observation
y_all = Y[1:end-1,:]
h_all = h[1:end-1,:]


##########################
# Descriptive statistic plots
#########################

#(1) N(t)
Nt = N .- sum(isnan.(y_all), dims = 2)[:,1]
plot(1900 .+ (yr0:(yr1-1)), Nt, label = "", lw = 2,
   framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_descr * "fig_units_per_period.png")





#(2) the distribution of number of periods that each individual spends in the panel
T_stay = T - 1 .- sum(isnan.(y_all), dims = 1)[1,:]
histogram(T_stay, nbin = 15,
         xtickfontsize = 8, ytickfontsize = 8,
         label = "", framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_descr * "fig_dist_unit_span_period.png")





#(3) experience distribution in the first period
find_first_nonNA(x) = findfirst(.!isnan.(x))

first_h = mapslices(find_first_nonNA, y_all, dims = 1)[1,:];
first_exp = [h_all[first_h[i],i] for i in 1:N]

histogram(first_exp, nbin = 30,
         xtickfontsize = 8, ytickfontsize = 8,
         label = "", framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_descr * "fig_dist_unit_experience_first.png")

#(4) last period: distribution of experience and distribution of periods each individual has been in the panel.
find_last_nonNA(x) = findlast(.!isnan.(x))

last_h = mapslices(find_last_nonNA, y_all, dims = 1)[1,:]
last_exp = [h_all[last_h[i],i] for i in 1:N]
histogram(last_exp, nbin = 30,
         xtickfontsize = 8, ytickfontsize = 8,
         label = "", framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_descr * "fig_dist_unit_experience_last.png")

den_alpha = kde(post_draw_ss_hetsk.q_alpha_draw)
den_rho = kde(post_draw_ss_hetsk.q_rho_draw)
den_sigma_u = kde(post_draw_ss_hetsk.q_sigma_u_draw)
den_sigma_e = kde(post_draw_ss_hetsk.q_sigma_e_draw)

plot(den_alpha, label = "\$q^{\\alpha}\$", legend = true, xlims = (0,1),
      xtickfontsize = 10, ytickfontsize = 10, linewidth = 2,
      # yticks = (0:1.5:maximum(den_alpha.density)+0.5, string.(0:1.5:maximum(den_alpha.density)+0.5)),
      framestyle = :box, size = (300,200), dpi = 200)
plot!(den_rho, linewidth = 2, label = "\$q^{\\rho}\$")
plot!(den_sigma_u, linewidth = 2, label = "\$q^{\\sigma_u}\$")
plot!(den_sigma_e, linewidth = 2, label = "\$q^{\\sigma_e}\$")
plot!(Beta(1,1), color = :black, label="", linestyle =:dot)

savefig(wd_hist_q * "fig_emp_den_post_q.png")
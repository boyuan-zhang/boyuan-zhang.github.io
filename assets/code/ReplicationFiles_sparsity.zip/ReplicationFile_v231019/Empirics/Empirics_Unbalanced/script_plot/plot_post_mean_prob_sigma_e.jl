prob_sigma_e_post_mean = 1 .- post_mean_ss_hetsk.prob_sigma_e_hat
sort_idx = sortperm(vec(prob_sigma_e_post_mean))
prob_sigma_e_post_mean = prob_sigma_e_post_mean[sort_idx]

# draw plot
plot(1:N, prob_sigma_e_post_mean, linewidth = 2,
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_prob_sigma_e.png")

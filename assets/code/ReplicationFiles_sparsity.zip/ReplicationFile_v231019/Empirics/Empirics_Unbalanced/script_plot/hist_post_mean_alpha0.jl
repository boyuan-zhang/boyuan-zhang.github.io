histogram(post_mean_ss_hetsk.delta_alpha_hat[:,1] .+ post_mean_ss_hetsk.alpha_hat[1],
            nbin = 60, normalize = :probability,
            xtickfontsize = 8, ytickfontsize = 8,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_hist_alpha * "fig_emp_hist_post_alpha0.png")
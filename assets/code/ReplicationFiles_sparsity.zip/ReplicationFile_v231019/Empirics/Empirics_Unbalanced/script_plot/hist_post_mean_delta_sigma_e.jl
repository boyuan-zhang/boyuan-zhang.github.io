histogram(post_mean_ss_hetsk.delta_sigma_e_hat, nbin = 70, normalize = :probability,
            xtickfontsize = 8, ytickfontsize = 8,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_hist_sigma2 * "fig_emp_hist_post_sigma2_e.png")
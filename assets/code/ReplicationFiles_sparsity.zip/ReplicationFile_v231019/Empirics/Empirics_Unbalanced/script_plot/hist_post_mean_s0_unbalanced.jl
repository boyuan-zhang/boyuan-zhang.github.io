s0 = [post_mean_ss_hetsk.s_hat[loc_s0[ii],ii] for ii = 1:N] # last draw of s0
histogram(post_mean_ss_hetsk.s_hat[1,:], nbin = 15, normalize = :probability,
            xtickfontsize = 8, ytickfontsize = 8,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_hist_s * "fig_emp_hist_post_s0.png")
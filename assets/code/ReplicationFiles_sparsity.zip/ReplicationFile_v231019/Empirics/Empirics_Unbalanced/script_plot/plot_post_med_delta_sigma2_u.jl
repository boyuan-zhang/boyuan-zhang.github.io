delta_sigma_u_draw = post_draw_ss_hetsk.delta_sigma_u_draw

delta_sigma_u_post_med = vec(median(delta_sigma_u_draw, dims = 1))
sort_idx = sortperm(vec(delta_sigma_u_post_med))
delta_sigma_u_post_med = delta_sigma_u_post_med[sort_idx]

# sort post draw given indexes from the real
delta_sigma_u_draw = delta_sigma_u_draw[:,sort_idx]

# post mean
delta_sigma_u_post_mean = post_mean_ss_hetsk.delta_sigma_u_hat
delta_sigma_u_post_mean = delta_sigma_u_post_mean[sort_idx]

# calculate hpdi
delta_sigma_u_hpdi =  mapslices(x -> hpdi(x, alpha = 0.1), delta_sigma_u_draw; dims=1)

# draw plot
plot(1:N, delta_sigma_u_post_mean, linewidth = 1.5, c = 2, linestyle = :dash, labels = "")
plot!(1:N, delta_sigma_u_post_med, linewidth = 2,
   ribbon = (delta_sigma_u_post_med - delta_sigma_u_hpdi[1,:], delta_sigma_u_hpdi[2,:] - delta_sigma_u_post_med), fillalpha = 0.15, c = 1,
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_delta_sigma_u_med.png")
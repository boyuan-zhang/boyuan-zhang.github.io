delta_alpha_nzero = [sum(post_draw_ss_hetsk.delta_alpha_draw[:,1,i] .== 0) for i = 1:N]
delta_alpha_zero = delta_alpha_nzero .> floor( size(post_draw_ss_hetsk.delta_alpha_draw,1)*correction_thr )
delta_alpha_mean_ss_c = copy(post_mean_ss_hetsk.delta_alpha_hat[:,1])
delta_alpha_mean_ss_c[delta_alpha_zero,:] .= 0

if all(delta_alpha_mean_ss_c .== 0)
   delta_alpha_mean_ss_c[1] = 0.5
   delta_alpha_mean_ss_c[end] = - 0.5
end

histogram(delta_alpha_mean_ss_c, nbin = 50, normalize = :probability,
            xtickfontsize = 8, ytickfontsize = 8,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_hist_alpha * "fig_emp_hist_post_delta_alpha0_corrected.png")
sigma2_e_post_mean = post_mean_ss_hetsk.sigma2_e_hat[2:end]
sigma2_e_draw = post_draw_ss_hetsk.sigma2_e_draw[:,2:end]
# calculate hpdi
sigma2_e_hpdi = mapslices(x -> hpdi(x, alpha = 0.1), sigma2_e_draw; dims=1)
# draw plot
plot(list_years, sigma2_e_post_mean, linewidth = 2,
   ribbon = (sigma2_e_post_mean - sigma2_e_hpdi[1,:], sigma2_e_hpdi[2,:] - sigma2_e_post_mean), 
   fillalpha = 0.15, c = 1,
   xticks = list_years[1]:year_inc:list_years[end],
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

vspan!([1969.75, 1970.75 + 0.25], c = :gray, fillalpha = 0.15, labels = "")
vspan!([1973.75, 1975.00 + 0.25], c = :gray, fillalpha = 0.15, labels = "")
vspan!([1980.00, 1980.50 + 0.25], c = :gray, fillalpha = 0.15, labels = "")
vspan!([1981.50, 1982.75 + 0.25], c = :gray, fillalpha = 0.15, labels = "")
vspan!([1990.50, 1991.00 + 0.25], c = :gray, fillalpha = 0.15, labels = "")

savefig(wd_post * "fig_emp_post_sigma2_e.png")
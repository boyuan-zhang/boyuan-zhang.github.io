alpha_i_post_mean = post_mean_ss_hetsk.delta_alpha_hat[:,2] .+ post_mean_ss_hetsk.alpha_hat[2]

# sort post mean
sort_idx = sortperm(vec(alpha_i_post_mean))

alpha_i_post_mean = alpha_i_post_mean[sort_idx]

# sort post draw given indexes from the real
alpha_i_draw = post_draw_ss_hetsk.delta_alpha_draw[:,2,:] .+ post_draw_ss_hetsk.alpha_draw[:,2]
alpha_i_draw = alpha_i_draw[:,sort_idx]

# calculate hpdi
alpha_i_hpdi =  mapslices(x -> hpdi(x, alpha = 0.1), alpha_i_draw; dims = 1)

# draw plot
plot(1:N, alpha_i_post_mean, linewidth = 2,
   ribbon = (alpha_i_post_mean - alpha_i_hpdi[1,:], alpha_i_hpdi[2,:] - alpha_i_post_mean), fillalpha = 0.15, c = 1,
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_alpha1.png")
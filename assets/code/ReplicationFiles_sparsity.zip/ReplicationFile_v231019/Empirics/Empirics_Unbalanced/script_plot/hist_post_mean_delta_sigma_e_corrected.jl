delta_sigma_nzero = [sum(post_draw_ss_hetsk.delta_sigma_e_draw[:,i] .== 1) for i = 1:N]
delta_sigma_zero = delta_sigma_nzero .> floor( size(post_draw_ss_hetsk.delta_sigma_e_draw,1)*correction_thr)
delta_sigma_mean_ss_c = copy(post_mean_ss_hetsk.delta_sigma_e_hat)
delta_sigma_mean_ss_c[delta_sigma_zero,:] .= 1

if all(delta_sigma_mean_ss_c .== 0)
   delta_sigma_mean_ss_c[1] = 0.5
   delta_sigma_mean_ss_c[end] = 0
end

histogram(delta_sigma_mean_ss_c, nbin = 70, normalize = :probability,
            xtickfontsize = 8, ytickfontsize = 8,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_hist_sigma2 * "fig_emp_hist_post_sigma2_e_corrected.png")
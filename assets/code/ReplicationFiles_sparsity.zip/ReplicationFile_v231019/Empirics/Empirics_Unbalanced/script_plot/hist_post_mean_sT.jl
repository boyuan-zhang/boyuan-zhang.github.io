histogram(post_mean_ss_hetsk.s_hat[end,:], nbin = 15, normalize = :probability,
            xtickfontsize = 8, ytickfontsize = 8,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_hist_s * "fig_emp_hist_post_sT.png")
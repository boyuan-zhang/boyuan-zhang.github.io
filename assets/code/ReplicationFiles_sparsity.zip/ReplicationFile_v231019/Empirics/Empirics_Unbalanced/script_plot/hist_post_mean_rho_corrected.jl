delta_rho_nzero = [sum(post_draw_ss_hetsk.delta_rho_draw[:,i] .== 0) for i = 1:N]
delta_rho_zero = delta_rho_nzero .> floor( size(post_draw_ss_hetsk.delta_rho_draw,1)*correction_thr )
delta_rho_mean_ss_c = copy(post_mean_ss_hetsk.delta_rho_hat)
delta_rho_mean_ss_c[delta_rho_zero,:] .= 0

if all(delta_rho_mean_ss_c .== 0)
   delta_rho_mean_ss_c[1] = 0.5
   delta_rho_mean_ss_c[end] = - 0.5
end

histogram(post_mean_ss_hetsk.rho_hat .+ vec(delta_rho_mean_ss_c), nbin = 60, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_hist_rho * "fig_emp_hist_post_rho_corrected.png")
rho_i_post_mean = post_mean_ss_hetsk.rho_hat .+ post_mean_ss_hetsk.delta_rho_hat
# sort post mean
sort_idx = sortperm(vec(rho_i_post_mean))

rho_i_post_mean = rho_i_post_mean[sort_idx]

# sort post draw given indexes from the real
rho_i_draw = post_draw_ss_hetsk.rho_draw .+ post_draw_ss_hetsk.delta_rho_draw
rho_i_draw = rho_i_draw[:,sort_idx]

# calculate hpdi
rho_i_hpdi =  mapslices(x -> hpdi(x, alpha = 0.1), rho_i_draw; dims = 1)

# draw plot
plot(1:N, rho_i_post_mean, linewidth = 2,
   ribbon = (rho_i_post_mean - rho_i_hpdi[1,:], rho_i_hpdi[2,:] - rho_i_post_mean), fillalpha = 0.15, c = 1,
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_rho.png")
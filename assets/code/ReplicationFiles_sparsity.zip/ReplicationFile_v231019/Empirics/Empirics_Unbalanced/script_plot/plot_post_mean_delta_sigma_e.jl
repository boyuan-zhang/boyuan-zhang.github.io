delta_sigma_e_post_mean = post_mean_ss_hetsk.delta_sigma_e_hat

# sort post mean
sort_idx = sortperm(vec(delta_sigma_e_post_mean))

delta_sigma_e_post_mean = delta_sigma_e_post_mean[sort_idx]

# sort post draw given indexes from the real
delta_sigma_e_draw = post_draw_ss_hetsk.delta_sigma_e_draw
delta_sigma_e_draw = delta_sigma_e_draw[:,sort_idx]
# calculate hpdi
delta_sigma_e_hpdi =  mapslices(x -> hpdi(x, alpha = 0.1), delta_sigma_e_draw; dims=1)
# draw plot
plot(1:N, delta_sigma_e_post_mean, linewidth = 2,
   ribbon = (delta_sigma_e_post_mean - delta_sigma_e_hpdi[1,:], delta_sigma_e_hpdi[2,:] - delta_sigma_e_post_mean), fillalpha = 0.15, c = 1,
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_delta_sigma_e.png")
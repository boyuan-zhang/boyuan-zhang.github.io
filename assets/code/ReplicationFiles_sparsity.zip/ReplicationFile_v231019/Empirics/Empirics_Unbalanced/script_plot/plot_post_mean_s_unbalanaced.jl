ss_mean = post_mean_ss_hetsk.s_hat[loc_s0[ii]+2:end,ii]
ss_draw = post_draw_ss_hetsk.s_draw[:,ii,loc_s0[ii]+2:end]
# calculate hpdi
ss_draw_hpdi =  mapslices(x -> hpdi(x, alpha = 0.1), ss_draw; dims=1)
# draw plot
plot(list_years[loc_s0[ii]:end], ss_mean, linewidth = 2,
   ribbon = (ss_mean - ss_draw_hpdi[1,:], ss_draw_hpdi[2,:] - ss_mean), fillalpha = 0.15, c = 1,
   xticks = list_years[1]:year_inc:list_years[end],
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)
savefig(wd_post * "fig_emp_post_s$(ii).png")
prob_rho_post_mean = 1 .- post_mean_ss_hetsk.prob_rho_hat
sort_idx = sortperm(vec(prob_rho_post_mean))
prob_rho_post_mean = prob_rho_post_mean[sort_idx]

# draw plot
plot(1:N, prob_rho_post_mean, linewidth = 2,
   labels = "", legend = :bottomleft, framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_post * "fig_emp_post_prob_rho.png")
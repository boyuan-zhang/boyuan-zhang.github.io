####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  DGP 4: Heteroskedastic Dynamic Panel Data Model
#  Author: Boyuan Zhang
#  Creation: 11/29/2019
#  Last change: 01/19/2022
#  Modifications:
#####################################################################################################

####################################################################################################
#                             Part 0: INTRO
####################################################################################################
cd()
wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Unbalanced/"
cd(wd)

estimator = "M2"

wd_plots = string(wd, "Plots/")
wd_hist = string(wd_plots, "Hist", "/", estimator, "/")

# folder for jld2 outout for hist
wd_jld = string(wd, "Estimates/", estimator, "/jld_temp/")

# create temp folder for alpha
wd_hist_alpha = string(wd_hist, "alpha/")
if !isdir(wd_hist_alpha)
   mkdir(wd_hist_alpha)
end

# create temp folder for rho
wd_hist_rho = string(wd_hist, "rho/")
if !isdir(wd_hist_rho)
   mkdir(wd_hist_rho)
end

# create temp folder for sigma
wd_hist_sigma2 = string(wd_hist, "sigma/")
if !isdir(wd_hist_sigma2)
   mkdir(wd_hist_sigma2)
end

# create temp folder for q
wd_hist_q = string(wd_hist, "q/")
if !isdir(wd_hist_q)
   mkdir(wd_hist_q)
end

# create temp folder for q
wd_hist_s = string(wd_hist, "s/")
if !isdir(wd_hist_s)
   mkdir(wd_hist_s)
end

# create folder for posterior hpdi
wd_post = string(wd_plots, "Post", "/")
if !isdir(wd_post)
   mkdir(wd_post)
end

wd_post = string(wd_post, estimator, "/")
if !isdir(wd_post)
   mkdir(wd_post)
end


# load packages (install them with Pkg.add() if needed)
using StatsPlots, KernelDensity, JLD2, Plots, SpecialFunctions, Distributions, StatisticalRethinking

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# create year list for y-axis (sigma and s)
list_years = 1968:1:1995
year_inc = 4

correction_thr = 0.8


####################################################################################################
#                             Part 3: DRAW HISTOGRAMS
####################################################################################################

temp = load(wd_jld * "output.jld2")
post_mean_ss_hetsk = temp["post_mean_ss_hetsk"]
post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

N = length(post_mean_ss_hetsk.delta_alpha_hat[:,1])
T = length(post_mean_ss_hetsk.s_hat[:,1]) - 1 # ignore T = 0
T_stay = T .- sum(isnan.(post_mean_ss_hetsk.s_hat), dims = 1)[1,:]

# find location of s0 for each unit
loc_nan = (post_mean_ss_hetsk.s_hat .=== NaN)
loc_s0 = sum(loc_nan, dims = 1) .+ 1
loc_s0 = loc_s0[1,:]



## delta_alpha0
# histogram of posterior means
include("script_plot/hist_post_mean_delta_alpha0.jl")


# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
include("script_plot/hist_post_mean_delta_alpha0_corrected.jl")


## alpha0
# histogram of posterior means
include("script_plot/hist_post_mean_alpha0.jl")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
include("script_plot/hist_post_mean_alpha0_corrected.jl")



## delta_alpha1
# histogram of posterior means
include("script_plot/hist_post_mean_delta_alpha1.jl")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
include("script_plot/hist_post_mean_delta_alpha1_corrected.jl")



## alpha1
# histogram of posterior means
# histogram of posterior means
include("script_plot/hist_post_mean_alpha1.jl")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
include("script_plot/hist_post_mean_alpha1_corrected.jl")


### rho
# histogram of posterior means
include("script_plot/hist_post_mean_rho.jl")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
include("script_plot/hist_post_mean_rho_corrected.jl")



### delta_sigma_u
# histogram of posterior means
include("script_plot/hist_post_mean_delta_sigma_u.jl")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
include("script_plot/hist_post_mean_delta_sigma_u_corrected.jl")

### delta_sigma_e
# histogram of posterior means
include("script_plot/hist_post_mean_delta_sigma_e.jl")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
include("script_plot/hist_post_mean_delta_sigma_e_corrected.jl")

### q
include("script_plot/den_q_alpha_rho_sigma.jl")


### s_{i0}
include("script_plot/hist_post_mean_s0_unbalanced.jl")


### s_{iT}
include("script_plot/hist_post_mean_sT.jl")




#########################
# Post mean and hpdi
#########################


#* rho_i    
include("script_plot/plot_post_mean_rho.jl")


#* delta_alpha_i0
include("script_plot/plot_post_mean_delta_alpha0.jl")


#* alpha_i0
include("script_plot/plot_post_mean_alpha0.jl")


#* delta_alpha_i1
include("script_plot/plot_post_mean_delta_alpha1.jl")


#* alpha_i1
include("script_plot/plot_post_mean_alpha1.jl")



#* delta_sigma_u
include("script_plot/plot_post_mean_delta_sigma_u.jl")



#* delta_sigma_e
include("script_plot/plot_post_mean_delta_sigma_e.jl")


#------------------------------------------
#------------------------------------------

#* rho_i (median)
include("script_plot/plot_post_med_rho.jl")


#* alpha_i0 (median)
include("script_plot/plot_post_med_alpha0.jl")


#* alpha_i1 (median)
include("script_plot/plot_post_med_alpha1.jl")


#* delta_sigma_u (median)
include("script_plot/plot_post_med_delta_sigma2_u.jl")


#* delta_sigma_e (median)
include("script_plot/plot_post_med_delta_sigma2_e.jl")

#------------------------------------------
#------------------------------------------

#* sigma2_u
include("script_plot/plot_post_med_sigma2_u.jl")


#* sigma2_e
include("script_plot/plot_post_med_sigma2_e.jl")


#* Prob of q_alpha = 1
include("script_plot/plot_post_mean_prob_alpha.jl")


#* Prob of q_rho = 1
include("script_plot/plot_post_mean_prob_rho.jl")


#* Prob of q_sigma_u = 1
include("script_plot/plot_post_mean_prob_sigma_u.jl")


#* Prob of q_sigma_e = 1
include("script_plot/plot_post_mean_prob_sigma_e.jl")

#* S
# first person
ii = 5

include("script_plot/plot_post_mean_s_unbalanaced.jl")

# second person
ii = 10

include("script_plot/plot_post_mean_s_unbalanaced.jl")


println("Plots are ready.")
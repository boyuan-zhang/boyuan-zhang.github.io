####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  Empirical Analysis, unbalanced Panel
#####################################################################################################


#* Version: unbalanced panels, AR

####################################################################################################
#                             Part 0: INTRO
####################################################################################################
cd()

wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Unbalanced/"

version = "_unbalanced"

wd_data = string(wd, "data", version, "/")

# create folder: Results (csv etc.)
wd_results = string(wd, "Results/")
if !isdir(wd_results)
   mkdir(wd_results)
end

# create folder: estimation output
wd_estimate = string(wd, "Estimates/")
if !isdir(wd_estimate)
   mkdir(wd_estimate)
end

# create folder: estimation output
wd_output = string(wd_estimate, "AR/")
if !isdir(wd_output)
   mkdir(wd_output)
end

# create temp folder for jld2 outout for hist
wd_jld = string(wd_output, "jld_temp/")
if !isdir(wd_jld)
   mkdir(wd_jld)
end


# create folder: Plots
wd_plots = string(wd, "Plots/")
if !isdir(wd_plots)
   mkdir(wd_plots)
end

# create hist folder
wd_hist = string(wd_plots, "Hist/")
if !isdir(wd_hist)
   mkdir(wd_hist)
end

# create folder: Plots
wd_hist = string(wd_hist, "AR/")
if !isdir(wd_hist)
   mkdir(wd_hist)
end

cd(wd)

# load packages (install them with Pkg.add() if needed)
using JLD2, FileIO, MutableNamedTuples, Random, Distributions, LinearAlgebra, SharedArrays, SpecialFunctions, DelimitedFiles, MAT
using SkipNan # deal wirh NANs in dataset
using ProgressBars # for fun

# load subfunction files
include("functions_emp_unbalanced.jl")
include("functions_helpers.jl")

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

## Data settings
# starting year
yr0 = 67
# end year (= 92(96) if last year = 1993(1997))
yr1 = 96
# number of observations in the sample

## MCMC settings
# number of MCMC draws
nMCMC = 10000
burnin = Int(floor(0.5*nMCMC))+2

# target acceptance rate of RWMH
opt_ar = 0.44

####################################################################################################
#                             Part 2: ESTIMATION
####################################################################################################
# helper functions
IG_nu(mean, sd) = 4+2*mean^2/sd^2
IG_tau(mean, sd) = 2*mean*(1+mean^2/sd^2)

##########################
# GLP, spike-and-slab
#########################

# Hyperparameter in the prior of v_δ^α (Inverse Wishart)
nu_vdelta_alpha  = 5.05
Psi_vdelta_alpha = [0.5 0; 0 0.1]

vdelta_alpha = mean(InverseWishart(nu_vdelta_alpha, Psi_vdelta_alpha))

# Hyperparameter in the prior of v_δ^ρ (Inverse Gamma)
vdelta_rho = 0.5^2 # 0.01^2

# Hyperparameter in the prior of v_δ^u (Inverse Gamma)
prior_mean_sigma_u = 0.05
prior_sd_sigma_u   = 0.5
nu_vsigma_u  = IG_nu(prior_mean_sigma_u, prior_sd_sigma_u)
tau_vsigma_u = IG_tau(prior_mean_sigma_u, prior_sd_sigma_u)

# Hyperparameter in the prior of v_δ^e (Inverse Gamma)
prior_mean_sigma_e = 0.05
prior_sd_sigma_e   = 0.5
nu_vsigma_e  = IG_nu(prior_mean_sigma_e, prior_sd_sigma_e)
tau_vsigma_e = IG_tau(prior_mean_sigma_e, prior_sd_sigma_e)

# # hyperparameters
lambda = (mu_delta_alpha = [0,0], mu_delta_rho = 0.8,
         vdelta_alpha = vdelta_alpha, vdelta_rho = vdelta_rho, 
         nu_vsigma_u = nu_vsigma_u, tau_vsigma_u = tau_vsigma_u, 
         nu_vsigma_e = nu_vsigma_e, tau_vsigma_e = tau_vsigma_e,
         mu_s0 = 0, v_s0 = 0.05)

seed = 0606

T0 = 67
T = 96 - T0 + 1


# load the data
raw = readdlm(string(wd_data, "unbalanced_data_incl_NA.txt"), ' ')
# replace NA with NaN
raw = replace(raw, "NA" => NaN) 

id = unique(raw[:,1])
N  = length(id)

Y = zeros(T, N)
h = zeros(T, N)

for i = 1:N
   selected = (abs.(raw[:,1] .- id[i]) .< 0.05)
   Y[:,i] = raw[selected, 3]
   h[:,i] = raw[selected, 5]
end

# remove the last observation
loc_last_obs = mapslices(find_last_nonNA, Y, dims = 1)[1,:]

y_all = copy(Y)
h_all = copy(h)
for i in 1:N
   y_all[loc_last_obs[i],i] = NaN
   h_all[loc_last_obs[i],i] = NaN
end

y_all = y_all[1:end-1,:]
h_all = h_all[1:end-1,:]

# variables in age-earning portfolio (in-sample)
H = zeros(T-1, N, 2)
H[:,:,1] .= 1
H[:,:,2] = h_all/10
#    H[:,:,3] = h_all.^2/10^2

loc_nan = (y_all .=== NaN)
H[loc_nan,1] .= NaN

##########################
# GLP, spike-and-slab
#########################

post_mean_ss_hetsk, post_draw_ss_hetsk = est_AR_hetsk_unb(y_all, H, lambda, nMCMC, seed);

# OOS forecast
h_last = [h[loc_last_obs[i],i] for i in 1:N]
H_last = [ones(N,1) h_last/10];

delta_alpha = post_mean_ss_hetsk.delta_alpha_hat
delta_rho = post_mean_ss_hetsk.delta_rho_hat
s_last = [post_mean_ss_hetsk.s_hat[loc_last_obs[i],i] for i in 1:N]

fcst = sum(H_last .* delta_alpha, dims = 2) + s_last .* delta_rho

# save lambda_i and rho_i in the case folder
file = matopen(string(wd_output, "results.mat"), "w")
post_mean_ss_hetsk_mat =(; post_mean_ss_hetsk..., fcst = fcst) # add fcst into final output
write(file, "post_mean", post_mean_ss_hetsk_mat)
close(file)

# save everything for plotting histograms
jldsave(wd_jld * "output.jld2"; post_mean_ss_hetsk = post_mean_ss_hetsk, post_draw_ss_hetsk = post_draw_ss_hetsk)
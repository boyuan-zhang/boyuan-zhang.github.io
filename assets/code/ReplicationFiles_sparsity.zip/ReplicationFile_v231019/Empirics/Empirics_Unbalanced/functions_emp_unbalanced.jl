
# SS-HIP-Hetero (direct sample s and delta-alpha), with alpha0 and alpha1 --> M2
function est_M2_unb(y_all, H, lambda, opt_ar, len_MCMC, id_simul)

    #* This version directly draws s together with δ_α's.
    #* This verison is designed for unbalanced panel.

    # len_MCMC = Int(50)
    # id_simul = seed
    # y = y_all

    len_MCMC = Int(len_MCMC)
    burnin   = Int(floor(0.5*len_MCMC))+1
    # burnin = 1

    y = y_all[1:end,:]

    T, N, dimH = size(H)
    
    # characters of unbalanced panel
    loc_nan = (y .=== NaN)
    loc_first_obs = mapslices(find_first_nonNA, y, dims = 1)[1,:];
    loc_last_obs  = mapslices(find_last_nonNA, y, dims = 1)[1,:]

    T_stay = loc_last_obs .- loc_first_obs .+ 1
    Nt = N .- sum(isnan.(y), dims = 2)[:,1]

    # unload HP
    mu_alpha, valpha,
    mu_rho, vrho, 
    nu_vdelta_alpha, Psi_vdelta_alpha, 
    nu_vdelta_rho, tau_vdelta_rho,
    nu_vdelta_sigma_u, tau_vdelta_sigma_u,
    nu_vdelta_sigma_e, tau_vdelta_sigma_e,
    nu_sigma_u, tau_sigma_u, nu_sigma_e, tau_sigma_e, 
    a, b, mu_s0, v_s0, nu_sigma_s0, tau_sigma_s0 = lambda

    # useful subfunctions
    crossprod(x) = x' * x
    g(x) = min(abs(x), 10) * sign(x) # helper function in adapative RWMH
    sum_skipnan(x) = sum(skipnan(x))

    q_alpha_draw        = zeros(len_MCMC+1)
    q_rho_draw          = zeros(len_MCMC+1)
    q_sigma_u_draw      = zeros(len_MCMC+1)
    q_sigma_e_draw      = zeros(len_MCMC+1)
    alpha_draw          = zeros(len_MCMC+1, dimH)
    rho_draw            = zeros(len_MCMC+1)
    vdelta_alpha_draw   = zeros(len_MCMC+1, dimH, dimH)
    vdelta_rho_draw     = zeros(len_MCMC+1)
    vdelta_sigma_u_draw = zeros(len_MCMC+1)
    vdelta_sigma_e_draw = zeros(len_MCMC+1)
    delta_alpha_draw    = zeros(len_MCMC+1, dimH, N)
    delta_rho_draw      = zeros(len_MCMC+1, N)
    delta_sigma_u_draw  = zeros(len_MCMC+1, N)
    delta_sigma_e_draw  = zeros(len_MCMC+1, N) 
    z_alpha_draw        = zeros(len_MCMC+1, N)
    z_rho_draw          = zeros(len_MCMC+1, N)
    z_sigma_u_draw      = zeros(len_MCMC+1, N)
    z_sigma_e_draw      = zeros(len_MCMC+1, N)
    sigma2_u_draw       = zeros(len_MCMC+1, T)
    sigma2_e_draw       = zeros(len_MCMC+1, T)
    s_draw              = zeros(len_MCMC+1, N, T+1)
    s0_mean_draw        = zeros(len_MCMC+1)
    s0_var_draw         = zeros(len_MCMC+1)

    prob_alpha_draw     = zeros(len_MCMC+1, N)
    prob_rho_draw       = zeros(len_MCMC+1, N)
    prob_sigma_u_draw   = zeros(len_MCMC+1, N)
    prob_sigma_e_draw   = zeros(len_MCMC+1, N)

    # RWMH
    c_vdelta_sigma_u = zeros(len_MCMC+1) # random walk step size
    c_vdelta_sigma_e = zeros(len_MCMC+1)
    RWMH_u_accept_record = zeros(len_MCMC+1) # record acceptance status
    RWMH_e_accept_record = zeros(len_MCMC+1)

    ### initialize parameters
    # α
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    alpha_draw[1,:] = mu_alpha

    # ρ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    rho_draw[1] = mu_rho

    # q
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
    q_alpha_draw[1]   = mean(Beta(a,b))
    q_rho_draw[1]     = mean(Beta(a,b))
    q_sigma_u_draw[1] = mean(Beta(a,b))
    q_sigma_e_draw[1] = mean(Beta(a,b))

    # v_δ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )
    vdelta_alpha_draw[1,:,:] = mean(InverseWishart(nu_vdelta_alpha, Psi_vdelta_alpha))
    vdelta_rho_draw[1]       = mean(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))
    vdelta_sigma_u_draw[1]   = mean(InverseGamma(nu_vdelta_sigma_u/2, tau_vdelta_sigma_u/2))
    vdelta_sigma_e_draw[1]   = mean(InverseGamma(nu_vdelta_sigma_e/2, tau_vdelta_sigma_e/2))

    # (z,δ)
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

    z_alpha_draw[1,:]   = rand(Bernoulli(q_alpha_draw[1]), N)
    z_rho_draw[1,:]     = rand(Bernoulli(q_rho_draw[1]), N)
    z_sigma_u_draw[1,:] = rand(Bernoulli(q_sigma_u_draw[1]), N)
    z_sigma_e_draw[1,:] = rand(Bernoulli(q_sigma_e_draw[1]), N)

    zero_pos_alpha    = collect(1:N)[z_alpha_draw[1,:] .== 0]
    zero_pos_rho      = collect(1:N)[z_rho_draw[1,:] .== 0]
    zero_pos_sigma_u  = collect(1:N)[z_sigma_u_draw[1,:] .== 0]
    zero_pos_sigma_e  = collect(1:N)[z_sigma_e_draw[1,:] .== 0]

    delta_rho_draw[1,:] = rand(Normal(0, sqrt(vdelta_rho_draw[1])), N)
    delta_rho_draw[1,:] = delta_rho_draw[1,:] .* abs.(delta_rho_draw[1,:] .< 0.2)
    delta_rho_draw[1,zero_pos_rho] .= 0

    delta_sigma_u_draw[1,:] = rand(InverseGamma(1/vdelta_sigma_u_draw[1]+2, 1/vdelta_sigma_u_draw[1]+1), N)
    delta_sigma_u_draw[1,zero_pos_sigma_u] .= 1

    delta_sigma_e_draw[1,:] = rand(InverseGamma(1/vdelta_sigma_e_draw[1]+2, 1/vdelta_sigma_e_draw[1]+1), N)
    delta_sigma_e_draw[1,zero_pos_sigma_e] .= 1

    # σ^2
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    sigma2_u_draw[1,:] = rand(InverseGamma(nu_sigma_u/2, tau_sigma_u/2), T)
    sigma2_e_draw[1,:] = rand(InverseGamma(nu_sigma_e/2, tau_sigma_e/2), T)

    sigma2_u_it = kron(sigma2_u_draw[1,:], delta_sigma_u_draw[1,:]') # T x N
    sigma2_e_it = kron(sigma2_e_draw[1,:], delta_sigma_e_draw[1,:]') # T x N

    sigma2_u_it[loc_nan] .= NaN
    sigma2_e_it[loc_nan] .= NaN

    # s0
    s0_mean_draw[1] = mean(Normal(mu_s0, sqrt(v_s0)))
    s0_var_draw[1]  = mean(InverseGamma(nu_sigma_s0/2, tau_sigma_s0/2))
    s0_temp = [rand(Normal(s0_mean_draw[1], sqrt(s0_var_draw[1]))) for ii in 1:N]

    # AR coef
    rho_i = rho_draw[1] .+ delta_rho_draw[1,:]

    # covariance matrix 
    var_s = zeros(T, N)
    for t = 1:T
        tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
        if t == 1
            for ii in 1:N
                var_s[tt[ii],ii] = rho_i[ii]^2 * s0_var_draw[1] + sigma2_e_it[tt[ii],ii]
            end
            
        else
            i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
            for ii in i_update
                var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
            end
        end
    end

    cov_s = zeros(T, T, N)
    for ii = 1:N
        for t1 = loc_first_obs[ii]:loc_last_obs[ii]
            for t2 = t1:loc_last_obs[ii]
                cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
            end
        end
    end

    s_temp = zeros(N, T+1) # +1 for initial value

    for ii = 1:N
        nobs_ii = T_stay[ii]

        s_temp[ii, loc_first_obs[ii]] = s0_temp[ii]
        s_temp[ii, loc_first_obs[ii]+1:loc_last_obs[ii]+1] = rand(MvNormal(vec(zeros(nobs_ii,1)), 
                   make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii])))
    end
    s_temp[s_temp .== 0] .= NaN

    s_draw[1,:,:] = s_temp

    # c
    c_vdelta_sigma_u[1] = 0.5
    c_vdelta_sigma_e[1] = 0.5

    for i = ProgressBar(2:len_MCMC+1)

        # i = 2
        # println("iter = $i")

        # current values for state variables
        s_lag_temp = s_draw[i-1,:,1:end-1]' # T x N
        s_temp     = s_draw[i-1,:,2:end]'

        # variance of errors
        sigma2_u_it = kron(sigma2_u_draw[i-1,:], delta_sigma_u_draw[i-1,:]') # T x N
        sigma2_e_it = kron(sigma2_e_draw[i-1,:], delta_sigma_e_draw[i-1,:]') # T x N

        sigma2_u_it[loc_nan] .= NaN
        sigma2_e_it[loc_nan] .= NaN

        ###################################################
        ### BLOCK 1: draw α
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 0) )

        sum_in_valpha = zeros(dimH, dimH)
        for ii in 1:N
            for tt in 1:T
                if !any(isnan.(H[tt,ii,:]))
                    sum_in_valpha = sum_in_valpha + sigma2_u_it[tt,ii]^-1 * H[tt,ii,:] * H[tt,ii,:]'
                end
            end
        end
        
        sum_in_mu_alpha = zeros(dimH, 1)
        for ii in 1:N
            for tt in 1:T
                if !any(isnan.(H[tt,ii,:]))
                    sum_in_mu_alpha = sum_in_mu_alpha + sigma2_u_it[tt,ii]^-1 * H[tt,ii,:] * 
                                        (y[tt,ii] - H[tt,ii,:]' * delta_alpha_draw[i-1,:,ii] - s_temp[tt,ii])
                end
            end
        end

        valpha_post = make_symmetric(( inv(valpha) + sum_in_valpha )^-1)
        mean_alpha_post = valpha_post * ( inv(valpha) * mu_alpha + sum_in_mu_alpha)

        alpha_draw[i,:] = rand(MvNormal(mean_alpha_post[:,1], valpha_post))

        



        ###################################################
        ### BLOCK 2: draw ρ
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

        vrho_post = ( inv(vrho) + sum_skipnan(sigma2_e_it.^-1 .* s_lag_temp.^2) )^-1
        mean_rho_post = vrho_post * ( inv(vrho) * mu_rho + sum_skipnan(sigma2_e_it.^-1 .* s_lag_temp .* (s_temp - repeat(delta_rho_draw[i-1,:]', T) .* s_lag_temp)) )

        rho_draw[i] = rand(Normal(mean_rho_post, sqrt(vrho_post)))





        ###################################################
        ### BLOCK 3: draw q
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

        psi_alpha         = sum( z_alpha_draw[i-1,:] )
        psi_rho           = sum( z_rho_draw[i-1,:] )
        psi_sigma_u       = sum( z_sigma_u_draw[i-1,:] )
        psi_sigma_e       = sum( z_sigma_e_draw[i-1,:] )

        q_alpha_draw[i]   = rand( Beta(a + psi_alpha,   b + N - psi_alpha  ) )
        q_rho_draw[i]     = rand( Beta(a + psi_rho,     b + N - psi_rho    ) )
        q_sigma_u_draw[i] = rand( Beta(a + psi_sigma_u, b + N - psi_sigma_u) )
        q_sigma_e_draw[i] = rand( Beta(a + psi_sigma_e, b + N - psi_sigma_e) )





        ###################################################
        ### BLOCK 4: draw variance for δ^α, δ^ρ, δ^σ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

        ### V_δ^α 
        nu_vdelta_alpha_post  = nu_vdelta_alpha + psi_alpha
        Psi_vdelta_alpha_post = Psi_vdelta_alpha + make_symmetric(crossprod(delta_alpha_draw[i-1,:,z_alpha_draw[i-1,:] .== 1]'))

        vdelta_alpha_draw[i,:,:] = rand(InverseWishart(nu_vdelta_alpha_post, Psi_vdelta_alpha_post))


        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

        ### V_δ^ρ 
        nu_vdelta_rho_post  = nu_vdelta_rho + psi_rho
        tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_rho_draw[i-1,:] .== 1].^2)

        vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

        ### V_δ^σ_u (adaptive RWMH)
        # log posterior of ω (will be used in RWMH)
        delta_sigma_u_slab = delta_sigma_u_draw[i-1, z_sigma_u_draw[i-1,:] .== 1]

        log_post_omega_u(x) = psi_sigma_u*(1/x+2)*log(1/x+1) - psi_sigma_u*loggamma(1/x+2) - 
                (nu_vdelta_sigma_u/2+1)*log(x) - 1/x*(sum(log.(delta_sigma_u_slab)) + sum(delta_sigma_u_slab.^-1) + tau_vdelta_sigma_u/2 )

        # RWMH
        c_u_i = c_vdelta_sigma_u[i-1]

        RWMH_draw_u = rand(truncated(Normal(vdelta_sigma_u_draw[i-1], sqrt(c_u_i)), lower = 0))

        # calculate acceptance rate
        diff_log_post = log_post_omega_u(RWMH_draw_u) - log_post_omega_u(vdelta_sigma_u_draw[i-1])
        diff_log_CDF  = log(cdf(Normal(0,sqrt(c_u_i)), RWMH_draw_u)) - log(cdf(Normal(0,sqrt(c_u_i)), vdelta_sigma_u_draw[i-1]))

        prob_RWMH_u = min(1, exp(diff_log_post - diff_log_CDF))

        # accept or not?
        RWMH_accept_u = rand(Bernoulli(prob_RWMH_u))

        if RWMH_accept_u
            vdelta_sigma_u_draw[i] = RWMH_draw_u
            RWMH_u_accept_record[i] = 1
        else
            vdelta_sigma_u_draw[i] = vdelta_sigma_u_draw[i-1]
            RWMH_u_accept_record[i] = 0
        end

        # update random walk step size
        log_c_u = g( log(c_vdelta_sigma_u[i-1]) + i^(-0.55) * (prob_RWMH_u - opt_ar) )
        c_vdelta_sigma_u[i] = exp(log_c_u)




        ### V_δ^σ_e (adaptive RWMH)
        # log posterior of ω (will be used in RWMH)
        delta_sigma_e_slab = delta_sigma_e_draw[i-1, z_sigma_e_draw[i-1,:] .== 1]

        log_post_omega_e(x) = psi_sigma_e*(1/x+2)*log(1/x+1) - psi_sigma_e*loggamma(1/x+2) - 
                (nu_vdelta_sigma_e/2+1)*log(x) - 1/x*(sum(log.(delta_sigma_e_slab)) + sum(delta_sigma_e_slab.^-1) + tau_vdelta_sigma_e/2 )

        # RWMH
        c_e_i = c_vdelta_sigma_e[i-1]

        RWMH_draw_e = rand(truncated(Normal(vdelta_sigma_e_draw[i-1], sqrt(c_e_i)), lower = 0))

        # calculate acceptance rate
        diff_log_post = log_post_omega_e(RWMH_draw_e) - log_post_omega_e(vdelta_sigma_e_draw[i-1])
        diff_log_CDF  = log(cdf(Normal(0, sqrt(c_e_i)), RWMH_draw_e)) - log(cdf(Normal(0, sqrt(c_e_i)), vdelta_sigma_e_draw[i-1]))

        prob_RWMH_e = min(1, exp(diff_log_post - diff_log_CDF))

        # accept?
        RWMH_accept_e = rand(Bernoulli(prob_RWMH_e))

        if RWMH_accept_e
            vdelta_sigma_e_draw[i] = RWMH_draw_e
            RWMH_e_accept_record[i] = 1
        else
            vdelta_sigma_e_draw[i] = vdelta_sigma_e_draw[i-1]
            RWMH_e_accept_record[i] = 0
        end

        # update random walk step size
        log_c_e = g( log(c_vdelta_sigma_e[i-1]) + i^(-0.55) * (prob_RWMH_e - opt_ar) )
        c_vdelta_sigma_e[i] = exp(log_c_e)





        ###################################################
        ### BLOCK 5: draw (z,δ) for α and ρ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

        ### draw z_rho, delta_rho
        ### draw z_rho 			
        # posterior mean and variance of delta_rho_i
        post_var_delta_rho  = [ (vdelta_rho_draw[i]^-1 + sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii].^2) )^-1 for ii in 1:N ]

        post_mean_delta_rho = [ post_var_delta_rho[ii] * sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii] .* 
                            (s_temp[:,ii] - rho_draw[i] * s_lag_temp[:,ii])) for ii in 1:N ]

        K_rho = q_rho_draw[i] / (1-q_rho_draw[i]) * (vdelta_rho_draw[i] ./ post_var_delta_rho).^(-0.5) .*
                exp.( 0.5*post_mean_delta_rho.^2 ./ post_var_delta_rho )

        if sum(K_rho .== Inf) != 0
            Inf_pos = collect(1:N)[K_rho .== Inf]
            K_rho[Inf_pos] .= 10^8
        end

        prob_rho = K_rho ./ (1 .+ K_rho) # probability of model 1
        prob_rho_draw[i,:] = prob_rho

        z_rho_draw[i,:] = [rand(Bernoulli(x)) for x in prob_rho]

        ### draw δ_rho 
        zero_rho_pos = collect(1:N)[z_rho_draw[i,:] .== 0]

        delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

        if length(zero_rho_pos) != 0
            delta_rho_draw[i,zero_rho_pos] .= 0
        end
 


        ### draw z_alpha, delta_alpha
        # posterior mean and variance of beta (delta_alpha_i and s)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 6) )

        # draw mean of s0
        v_s0_post = ( inv(v_s0) + N*s0_var_draw[i-1]^-1 )^-1

        s0_prev = [s_draw[i-1, ii,loc_first_obs[ii]] for ii = 1:N] # last draw of s0

        mean_s0_post = v_s0_post * (s0_var_draw[i-1]^-1 * sum(s0_prev) + inv(v_s0) * mu_s0)
        s0_mean_draw[i] = rand(Normal(mean_s0_post, sqrt(v_s0_post)))

        # draw variance of s0, will be used in the calculation of variance of s
        nu_sigma_s0_post = nu_sigma_s0 + N
        tau_sigma_s0_post = tau_sigma_s0 + sum((s0_prev .- s0_mean_draw[i]).^2)
        s0_var_draw[i] = rand(InverseGamma(nu_sigma_s0_post/2, tau_sigma_s0_post/2))

        # AR coef
        rho_i = rho_draw[i] .+ delta_rho_draw[i,:]

        # covariance matrix of s
        var_s = zeros(T, N)
        for t = 1:T
            tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
            if t == 1
                for ii in 1:N
                    var_s[tt[ii],ii] = rho_i[ii]^2 * s0_var_draw[i] + sigma2_e_it[tt[ii],ii]
                end
                
            else
                i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
                for ii in i_update
                    var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
                end
            end
        end

        cov_s = zeros(T, T, N)
        for ii = 1:N
            for t1 = loc_first_obs[ii]:loc_last_obs[ii]
                for t2 = t1:loc_last_obs[ii]
                    cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                    cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
                end
            end
        end


        # prior covarance matrix for beta (delta-alpha + s)

        # fill in values in the last loc_first_obs[ii] + dimH element
        Sigma_beta_prior = zeros(dimH + T, dimH + T, N)
        # Sigma_beta_prior[:] .= NaN
        for ii = 1:N
            pos  = dimH + loc_first_obs[ii]
            pos2 = dimH + loc_last_obs[ii]
            Sigma_beta_prior[(pos-dimH):(pos-1), (pos-dimH):(pos-1), ii] = make_symmetric(vdelta_alpha_draw[i,:,:]) # delta-alpha
            Sigma_beta_prior[pos:pos2, pos:pos2, ii] = 
                make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) # s_i1:T
        end

        # design matrix (delta-alpha + s_i1 + ... + s_iT)
        X_i = zeros(T, dimH + T, N)
        X_i[:] .= NaN

        for ii = 1:N
            X_i[:,loc_first_obs[ii]:(loc_first_obs[ii]+dimH-1), ii] = H[:,ii,:]
            X_i[loc_first_obs[ii]:loc_last_obs[ii], (loc_first_obs[ii]+dimH):(loc_last_obs[ii]+dimH), ii] = I(T_stay[ii])
        end

        # X_i[17:end,17:end,ii]

        # posterior for beta (delta-alpha + s)
        post_var_beta  = [make_symmetric( inv( 
                            inv(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH, loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) .+ 
                            X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
                            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
                            X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii] ) ) for ii in 1:N]
        post_mean_beta = [post_var_beta[ii] * X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
                            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii], ii].^-1) * 
                            (y[loc_first_obs[ii]:loc_last_obs[ii], ii] - H[loc_first_obs[ii]:loc_last_obs[ii], ii,:] * alpha_draw[i,:]) for ii in 1:N]

        # posterior for s (X_i = I(T))
        post_var_s  = [make_symmetric( inv( inv(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) .+ 
                        Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii], ii].^-1) ) ) for ii in 1:N]
        post_mean_s = [post_var_s[ii] * Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
                        (y[loc_first_obs[ii]:loc_last_obs[ii], ii] - H[loc_first_obs[ii]:loc_last_obs[ii],ii,:] * alpha_draw[i,:]) for ii in 1:N]


        # Z-delta-alpha
        K_alpha = q_alpha_draw[i] / (1-q_alpha_draw[i]) * 
                            exp.([0.5*logdet(post_var_beta[ii]) - 
                            0.5*logdet(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH,loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) - 
                            0.5*logdet(post_var_s[ii]) + 0.5*logdet(cov_s[loc_first_obs[ii]:loc_last_obs[ii],loc_first_obs[ii]:loc_last_obs[ii],ii]) + 
                                0.5*post_mean_beta[ii]' * inv(post_var_beta[ii]) * post_mean_beta[ii] -
                                0.5*post_mean_s[ii]' * inv(post_var_s[ii]) * post_mean_s[ii] for ii in 1:N])

        if sum(K_alpha .== Inf) != 0
            Inf_pos = collect(1:N)[K_alpha .== Inf]
            K_alpha[Inf_pos] .= 10^8
        end

        prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1
        prob_alpha_draw[i,:] = prob_alpha

        z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

        zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

        ### draw delta_alpha and s when z_alpha_i = 1
        delta_alpha_temp = zeros(dimH, N)
        s_temp = zeros(T, N)
        for ii in 1:N
            beta_temp = rand(MvNormal(post_mean_beta[ii], post_var_beta[ii]))

            delta_alpha_temp[:,ii] = beta_temp[1:dimH]
            s_temp[:,ii] = [NaN*ones(loc_first_obs[ii]-1); beta_temp[(dimH+1):end]; NaN*ones(T - loc_last_obs[ii])]
        end

        delta_alpha_draw[i,:,:] = delta_alpha_temp

        ### draw s when z_alpha_i = 0
        if length(zero_alpha_pos) != 0

            # delta-alpha are zero
            delta_alpha_draw[i, :, zero_alpha_pos] .= 0

            # posterior of beta (X_i = I(T))
            for ii in zero_alpha_pos
                s_draw_1T = rand(MvNormal(post_mean_s[ii], make_symmetric(post_var_s[ii])))
                s_temp[:, ii] = [NaN*ones(loc_first_obs[ii]-1); s_draw_1T; NaN*ones(T - loc_last_obs[ii])]
            end

        end

        # s0 (simultation smoother)
        s00 = s0_mean_draw[i]
        P00 = s0_var_draw[i]
        P10 = rho_i .* P00 .* rho_i + [sigma2_e_it[loc_first_obs[ii], ii] for ii in 1:N]
        
        s1_temp = [s_temp[loc_first_obs[ii],ii] for ii in 1:N]
        post_mean_s0 = s00 .+ P00 .* rho_i .* P10.^-1 .* (s1_temp - rho_i .* s0_mean_draw[i])
        post_var_s0 = P00 .- P00 .* rho_i .* P10.^-1 .* rho_i .* P00
        s0_temp = [rand(Normal(post_mean_s0[ii], sqrt(post_var_s0[ii]))) for ii in 1:N]
        
        # insert S_0 into S_1:T
        s_temp2 = [NaN*ones(1,N); s_temp]
        for ii in 1:N
            s_temp2[loc_first_obs[ii], ii] = s0_temp[ii]
        end
        s_draw[i,:,:] = s_temp2'

        # current values for state variables
        s_lag_temp = s_draw[i,:,1:end-1]' # T x N
        s_temp     = s_draw[i,:,2:end]' # T x N





        ###################################################
        ### BLOCK 5: draw (z,δ) for σ^2_e and σ^2_u
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

        
        ### draw z_sigma_u
        # parameters in posterior of δ^σ
        nu_delta_sigma_u_post  = 2*vdelta_sigma_u_draw[i]^(-1) + 4 .+ T_stay

        sum_y_sigma_u_sq = [sum_skipnan(sigma2_u_draw[i-1,:].^-1 .* (y[:,ii] - H[:,ii,:] * (alpha_draw[i,:] .+ delta_alpha_draw[i,:,ii]) - s_temp[:,ii]).^2) for ii in 1:N]
        tau_delta_sigma_u_post = 2*vdelta_sigma_u_draw[i]^(-1) + 2 .+ sum_y_sigma_u_sq

        # posterior odd
        exp_part = 0.5*sum_y_sigma_u_sq          
        Const    = loggamma.(nu_delta_sigma_u_post/2) .- loggamma(vdelta_sigma_u_draw[i]^(-1)+2) .+ 
                    (vdelta_sigma_u_draw[i]^(-1)+2) * log(vdelta_sigma_u_draw[i]^(-1)+1) .- 
                    (nu_delta_sigma_u_post/2) .* log.(tau_delta_sigma_u_post/2)

        K_sigma_u = q_sigma_u_draw[i] / (1-q_sigma_u_draw[i]) * exp.(Const .+ exp_part)

        if sum(K_sigma_u .== Inf) != 0
            Inf_pos = collect(1:N)[K_sigma_u .== Inf]
            K_sigma_u[Inf_pos] .= 10^8
        end

        prob_sigma_u = K_sigma_u ./ (1 .+ K_sigma_u) # probability of model 1
        prob_sigma_u_draw[i,:] = prob_sigma_u

        z_sigma_u_draw[i,:] = [rand(Bernoulli(x)) for x in prob_sigma_u]

        ### draw δ_sigma_u
        zero_sigma_u_pos = collect(1:N)[z_sigma_u_draw[i,:] .== 0]

        delta_sigma_u_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_u_post[ii]/2, tau_delta_sigma_u_post[ii]/2)) for ii in 1:N]

        if length(zero_sigma_u_pos) != 0
            delta_sigma_u_draw[i,zero_sigma_u_pos] .= 1
        end



        ### draw z_sigma_e
        # parameters in posterior of δ^σ_e
        nu_delta_sigma_e_post  = 2*vdelta_sigma_e_draw[i]^(-1) + 4 .+ T_stay

        sum_y_sigma_e_sq = [sum_skipnan(sigma2_e_draw[i-1,:].^-1 .* (s_temp[:,ii] - (rho_draw[i] + delta_rho_draw[i,ii]).* s_lag_temp[:,ii]).^2) for ii in 1:N]
        tau_delta_sigma_e_post = 2*vdelta_sigma_e_draw[i]^(-1) + 2 .+ sum_y_sigma_e_sq

        # posterior odd
        exp_part = 0.5*sum_y_sigma_e_sq
        Const    = loggamma.(nu_delta_sigma_e_post/2) .- loggamma(vdelta_sigma_e_draw[i]^(-1)+2) .+ 
                    (vdelta_sigma_e_draw[i]^(-1)+2) * log(vdelta_sigma_e_draw[i]^(-1)+1) .- 
                    (nu_delta_sigma_e_post/2) .* log.(tau_delta_sigma_e_post/2)

        K_sigma_e = q_sigma_e_draw[i] / (1-q_sigma_e_draw[i]) * exp.(Const .+ exp_part)

        if sum(K_sigma_e .== Inf) != 0
            Inf_pos = collect(1:N)[K_sigma_e .== Inf]
            K_sigma_e[Inf_pos] .= 10^8
        end

        prob_sigma_e = K_sigma_e ./ (1 .+ K_sigma_e)
        prob_sigma_e_draw[i,:] = prob_sigma_e

        z_sigma_e_draw[i,:] = [rand(Bernoulli(x)) for x in prob_sigma_e]

        ### draw δ_sigma_e
        zero_sigma_e_pos = collect(1:N)[z_sigma_e_draw[i,:] .== 0]

        delta_sigma_e_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_e_post[ii]/2, tau_delta_sigma_e_post[ii]/2)) for ii in 1:N]

        if length(zero_sigma_e_pos) != 0
            delta_sigma_e_draw[i,zero_sigma_e_pos] .= 1
        end





        ###################################################
        ### BLOCK 6: draw σ^2
        ###################################################

        ### draw σ_u^2(t) 
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 7) )
     
        nu_sigma_u_post  = nu_sigma_u .+ Nt
        tau_sigma_u_post = tau_sigma_u .+ [sum_skipnan(delta_sigma_u_draw[i,:].^-1 .* (y[tt,:] - s_temp[tt,:] - sum(H[tt,:,:] .*      
                            (delta_alpha_draw[i,:,:] + repeat(alpha_draw[i,:], outer = [1,N]))', dims = 2) ).^2 ) for tt in 1:T]

        sigma2_u_draw[i,:] = [rand(InverseGamma(nu_sigma_u_post[tt]/2, tau_sigma_u_post[tt]/2)) for tt in 1:T]



        ### draw σ_e^2(t) 
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 8) )
        nu_sigma_e_post  = nu_sigma_e .+ Nt
        tau_sigma_e_post = tau_sigma_e .+ [sum_skipnan(delta_sigma_e_draw[i,:].^-1 .* (s_temp[tt,:] - rho_i .* s_lag_temp[tt,:]).^2) for tt in 1:T]

        sigma2_e_draw[i,:] = [rand(InverseGamma(nu_sigma_e_post[tt]/2, tau_sigma_e_post[tt]/2)) for tt in 1:T]
    end

    # posterior draws
    alpha_draw_post           = alpha_draw[burnin:end,:]
    rho_draw_post             = rho_draw[burnin:end]
    delta_alpha_draw_post     = delta_alpha_draw[burnin:end,:,:]
    delta_rho_draw_post       = delta_rho_draw[burnin:end,:]
    delta_sigma_u_draw_post   = delta_sigma_u_draw[burnin:end,:]
    delta_sigma_e_draw_post   = delta_sigma_e_draw[burnin:end,:]
    vdelta_alpha_draw_post    = vdelta_alpha_draw[burnin:end,:,:]
    vdelta_rho_draw_post      = vdelta_rho_draw[burnin:end]
    vdelta_sigma_u_draw_post  = vdelta_sigma_u_draw[burnin:end,:]
    vdelta_sigma_e_draw_post  = vdelta_sigma_e_draw[burnin:end,:]
    sigma2_u_draw_post        = sigma2_u_draw[burnin:end,:]
    sigma2_e_draw_post        = sigma2_e_draw[burnin:end,:]
    z_alpha_draw_post         = z_alpha_draw[burnin:end,:]
    z_rho_draw_post           = z_rho_draw[burnin:end,:]
    z_sigma_u_draw_post       = z_sigma_u_draw[burnin:end,:]
    z_sigma_e_draw_post       = z_sigma_e_draw[burnin:end,:]
    prob_alpha_draw_post      = prob_alpha_draw[burnin:end,:]
    prob_rho_draw_post        = prob_rho_draw[burnin:end,:]
    prob_sigma_u_draw_post    = prob_sigma_u_draw[burnin:end,:]
    prob_sigma_e_draw_post    = prob_sigma_e_draw[burnin:end,:]
    q_alpha_draw_post         = q_alpha_draw[burnin:end]
    q_rho_draw_post           = q_rho_draw[burnin:end]
    q_sigma_u_draw_post       = q_sigma_u_draw[burnin:end]
    q_sigma_e_draw_post       = q_sigma_e_draw[burnin:end]
    s_draw_post               = s_draw[burnin:end,:,:]
    s0_mean_draw_post         = s0_mean_draw[burnin:end]
    s0_var_draw_post          = s0_var_draw[burnin:end]
   

    # posterior mean
    alpha_hat          = mean( alpha_draw_post, dims = 1)'
    rho_hat            = mean( rho_draw_post )
    delta_alpha_hat    = mean( delta_alpha_draw_post, dims = 1)[1,:,:]'
    delta_rho_hat      = mean( delta_rho_draw_post, dims = 1)'
    delta_sigma_u_hat  = mean( delta_sigma_u_draw_post, dims = 1)'
    delta_sigma_e_hat  = mean( delta_sigma_e_draw_post, dims = 1)'
    vdelta_alpha_hat   = mean( vdelta_alpha_draw_post, dims = 1)[1,:,:]'
    vdelta_rho_hat     = mean( vdelta_rho_draw_post )
    vdelta_sigma_u_hat = mean( vdelta_sigma_u_draw_post )
    vdelta_sigma_e_hat = mean( vdelta_sigma_e_draw_post )
    sigma2_u_hat       = mean( sigma2_u_draw_post, dims = 1)'
    sigma2_e_hat       = mean( sigma2_e_draw_post, dims = 1)'
    z_alpha_hat        = mean( z_alpha_draw_post, dims = 1)'
    z_rho_hat          = mean( z_rho_draw_post, dims = 1)'
    z_sigma_u_hat      = mean( z_sigma_u_draw_post, dims = 1)'
    z_sigma_e_hat      = mean( z_sigma_e_draw_post, dims = 1)'
    prob_alpha_hat     = mean( prob_alpha_draw_post, dims = 1)'
    prob_rho_hat       = mean( prob_rho_draw_post, dims = 1)'
    prob_sigma_u_hat   = mean( prob_sigma_u_draw_post, dims = 1)'
    prob_sigma_e_hat   = mean( prob_sigma_e_draw_post, dims = 1)'
    q_alpha_hat        = mean( q_alpha_draw_post )
    q_rho_hat          = mean( q_rho_draw_post )
    q_sigma_u_hat      = mean( q_sigma_u_draw_post )
    q_sigma_e_hat      = mean( q_sigma_e_draw_post )
    s0_mean_hat        = mean( s0_mean_draw_post )
    s0_var_hat         = mean( s0_var_draw_post )

    s_hat = zeros(T+1, N)
    for ii in 1:N
        for tt in 1:T+1
            s_hat[tt, ii] = mean(skipnan(s_draw_post[:,ii,tt]))
        end
    end

    RWMH_u_accept_hat = mean(RWMH_u_accept_record[burnin:end])
    RWMH_e_accept_hat = mean(RWMH_e_accept_record[burnin:end])

    post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_u_hat = sigma2_u_hat, sigma2_e_hat = sigma2_e_hat,
                 delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat, delta_sigma_u_hat = delta_sigma_u_hat, delta_sigma_e_hat = delta_sigma_e_hat,
                 vdelta_alpha_hat = vdelta_alpha_hat, vdelta_rho_hat = vdelta_rho_hat, vdelta_sigma_u_hat = vdelta_sigma_u_hat, vdelta_sigma_e_hat = vdelta_sigma_e_hat,
                 z_alpha_hat = z_alpha_hat, z_rho_hat = z_rho_hat, z_sigma_u_hat = z_sigma_u_hat, z_sigma_e_hat = z_sigma_e_hat,
                 prob_alpha_hat = prob_alpha_hat, prob_rho_hat = prob_rho_hat, prob_sigma_u_hat = prob_sigma_u_hat, prob_sigma_e_hat = prob_sigma_e_hat,
                 q_alpha_hat = q_alpha_hat, q_rho_hat = q_rho_hat, q_sigma_u_hat = q_sigma_u_hat, q_sigma_e_hat = q_sigma_e_hat,
                 s_hat = s_hat, s0_var_hat = s0_var_hat, s0_mean_hat = s0_mean_hat,
                 RWMH_u_accept_hat = RWMH_u_accept_hat, RWMH_e_accept_hat = RWMH_e_accept_hat)
    
    post_draw = (alpha_draw          = alpha_draw_post,
                rho_draw             = rho_draw_post,
                delta_alpha_draw     = delta_alpha_draw_post,
                delta_rho_draw       = delta_rho_draw_post,
                delta_sigma_u_draw   = delta_sigma_u_draw_post,
                delta_sigma_e_draw   = delta_sigma_e_draw_post,
                vdelta_alpha_draw    = vdelta_alpha_draw_post,
                vdelta_rho_draw      = vdelta_rho_draw_post,
                vdelta_sigma_u_draw  = vdelta_sigma_u_draw_post,
                vdelta_sigma_e_draw  = vdelta_sigma_e_draw_post,
                sigma2_u_draw        = sigma2_u_draw_post,
                sigma2_e_draw        = sigma2_e_draw_post,
                z_alpha_draw         = z_alpha_draw_post,
                z_rho_draw           = z_rho_draw_post,
                z_sigma_u_draw       = z_sigma_u_draw_post,
                z_sigma_e_draw       = z_sigma_e_draw_post,
                prob_alpha_draw      = prob_alpha_draw_post,
                prob_rho_draw        = prob_rho_draw_post,
                prob_sigma_u_draw    = prob_sigma_u_draw_post,
                prob_sigma_e_draw    = prob_sigma_e_draw_post,
                q_alpha_draw         = q_alpha_draw_post,
                q_rho_draw           = q_rho_draw_post,
                q_sigma_u_draw       = q_sigma_u_draw_post,
                q_sigma_e_draw       = q_sigma_e_draw_post,
                s_draw               = s_draw_post,
                s0_mean_draw         = s0_mean_draw_post,
                s0_var_draw          = s0_var_draw_post)

    return post_mean, post_draw

end


# SS-HIP-Hetero (direct sample s and delta-alpha), with alpha0 and alpha1 --> M2, with diff s0 spec
function est_SS_HIP_hetsk_w_alpha_w_NA_diff_s0(y_all, H, lambda, opt_ar, len_MCMC, id_simul)

    #* This version directly draws s together with δ_α's.
    #* This verison is designed for unbalanced panel.
    #* This is the second verison for the unbalanced case,
    #* where we allow for ind that have enough obs in the middle of the sample

    #* This version accounts for different enterance year in s0
    # len_MCMC = Int(50)
    # id_simul = seed
    # y = y_all

    len_MCMC = Int(len_MCMC)
    burnin   = Int(floor(0.5*len_MCMC))+1
    # burnin = 1

    y = y_all[1:end,:]

    T, N, dimH = size(H)
    
    # characters of unbalanced panel
    loc_nan = (y .=== NaN)
    # loc_first_obs = [find_first_nonNA(y[:,i]) for i in 1:N]
    # loc_last_obs  = [find_last_nonNA(y[:,i]) for i in 1:N]
    loc_first_obs = mapslices(find_first_nonNA, y, dims = 1)[1,:];
    loc_last_obs  = mapslices(find_last_nonNA, y, dims = 1)[1,:]

    # T_stay = T .- sum(isnan.(y), dims = 1)[1,:]
    T_stay = loc_last_obs .- loc_first_obs .+ 1
    Nt = N .- sum(isnan.(y), dims = 2)[:,1]

    # unload HP
    mu_alpha, valpha,
    mu_rho, vrho, 
    nu_vdelta_alpha, Psi_vdelta_alpha, 
    nu_vdelta_rho, tau_vdelta_rho,
    nu_vdelta_sigma_u, tau_vdelta_sigma_u,
    nu_vdelta_sigma_e, tau_vdelta_sigma_e,
    nu_sigma_u, tau_sigma_u, nu_sigma_e, tau_sigma_e, 
    a, b, mu_s0, v_s0, nu_sigma_s0, tau_sigma_s0 = lambda

    # useful subfunctions
    crossprod(x) = x' * x
    g(x) = min(abs(x), 10) * sign(x) # helper function in adapative RWMH
    sum_skipnan(x) = sum(skipnan(x))

    q_alpha_draw        = zeros(len_MCMC+1)
    q_rho_draw          = zeros(len_MCMC+1)
    q_sigma_u_draw      = zeros(len_MCMC+1)
    q_sigma_e_draw      = zeros(len_MCMC+1)
    alpha_draw          = zeros(len_MCMC+1, dimH)
    rho_draw            = zeros(len_MCMC+1)
    vdelta_alpha_draw   = zeros(len_MCMC+1, dimH, dimH)
    vdelta_rho_draw     = zeros(len_MCMC+1)
    vdelta_sigma_u_draw = zeros(len_MCMC+1)
    vdelta_sigma_e_draw = zeros(len_MCMC+1)
    delta_alpha_draw    = zeros(len_MCMC+1, dimH, N)
    delta_rho_draw      = zeros(len_MCMC+1, N)
    delta_sigma_u_draw  = zeros(len_MCMC+1, N)
    delta_sigma_e_draw  = zeros(len_MCMC+1, N) 
    z_alpha_draw        = zeros(len_MCMC+1, N)
    z_rho_draw          = zeros(len_MCMC+1, N)
    z_sigma_u_draw      = zeros(len_MCMC+1, N)
    z_sigma_e_draw      = zeros(len_MCMC+1, N)
    sigma2_u_draw       = zeros(len_MCMC+1, T)
    sigma2_e_draw       = zeros(len_MCMC+1, T)
    s_draw              = zeros(len_MCMC+1, N, T+1)
    s0_mean_draw        = zeros(len_MCMC+1)
    s0_var_draw         = zeros(len_MCMC+1)

    prob_alpha_draw     = zeros(len_MCMC+1, N)
    prob_rho_draw       = zeros(len_MCMC+1, N)
    prob_sigma_u_draw   = zeros(len_MCMC+1, N)
    prob_sigma_e_draw   = zeros(len_MCMC+1, N)

    # RWMH
    c_vdelta_sigma_u = zeros(len_MCMC+1) # random walk step size
    c_vdelta_sigma_e = zeros(len_MCMC+1)
    RWMH_u_accept_record = zeros(len_MCMC+1) # record acceptance status
    RWMH_e_accept_record = zeros(len_MCMC+1)

    ### initialize parameters
    # α
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    alpha_draw[1,:] = mu_alpha

    # ρ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    rho_draw[1] = mu_rho

    # q
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
    q_alpha_draw[1]   = mean(Beta(a,b))
    q_rho_draw[1]     = mean(Beta(a,b))
    q_sigma_u_draw[1] = mean(Beta(a,b))
    q_sigma_e_draw[1] = mean(Beta(a,b))

    # v_δ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )
    vdelta_alpha_draw[1,:,:] = mean(InverseWishart(nu_vdelta_alpha, Psi_vdelta_alpha))
    vdelta_rho_draw[1]       = mean(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))
    vdelta_sigma_u_draw[1]   = mean(InverseGamma(nu_vdelta_sigma_u/2, tau_vdelta_sigma_u/2))
    vdelta_sigma_e_draw[1]   = mean(InverseGamma(nu_vdelta_sigma_e/2, tau_vdelta_sigma_e/2))

    # (z,δ)
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

    z_alpha_draw[1,:]   = rand(Bernoulli(q_alpha_draw[1]), N)
    z_rho_draw[1,:]     = rand(Bernoulli(q_rho_draw[1]), N)
    z_sigma_u_draw[1,:] = rand(Bernoulli(q_sigma_u_draw[1]), N)
    z_sigma_e_draw[1,:] = rand(Bernoulli(q_sigma_e_draw[1]), N)

    zero_pos_alpha    = collect(1:N)[z_alpha_draw[1,:] .== 0]
    zero_pos_rho      = collect(1:N)[z_rho_draw[1,:] .== 0]
    zero_pos_sigma_u  = collect(1:N)[z_sigma_u_draw[1,:] .== 0]
    zero_pos_sigma_e  = collect(1:N)[z_sigma_e_draw[1,:] .== 0]

    delta_rho_draw[1,:] = rand(Normal(0, sqrt(vdelta_rho_draw[1])), N)
    delta_rho_draw[1,:] = delta_rho_draw[1,:] .* abs.(delta_rho_draw[1,:] .< 0.2)
    delta_rho_draw[1,zero_pos_rho] .= 0

    delta_sigma_u_draw[1,:] = rand(InverseGamma(1/vdelta_sigma_u_draw[1]+2, 1/vdelta_sigma_u_draw[1]+1), N)
    delta_sigma_u_draw[1,zero_pos_sigma_u] .= 1

    delta_sigma_e_draw[1,:] = rand(InverseGamma(1/vdelta_sigma_e_draw[1]+2, 1/vdelta_sigma_e_draw[1]+1), N)
    delta_sigma_e_draw[1,zero_pos_sigma_e] .= 1

    # σ^2
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    sigma2_u_draw[1,:] = rand(InverseGamma(nu_sigma_u/2, tau_sigma_u/2), T)
    sigma2_e_draw[1,:] = rand(InverseGamma(nu_sigma_e/2, tau_sigma_e/2), T)

    sigma2_u_it = kron(sigma2_u_draw[1,:], delta_sigma_u_draw[1,:]') # T x N
    sigma2_e_it = kron(sigma2_e_draw[1,:], delta_sigma_e_draw[1,:]') # T x N

    sigma2_u_it[loc_nan] .= NaN
    sigma2_e_it[loc_nan] .= NaN


    #! s (version 3), direct sampling
    # s0
    s0_mean_draw[1] = mean(Normal(mu_s0, sqrt(v_s0)))
    s0_var_draw[1]  = mean(InverseGamma(nu_sigma_s0/2, tau_sigma_s0/2))
    s0_temp = [rand(Normal(s0_mean_draw[1], sqrt(s0_var_draw[1]))) for ii in 1:N]

    # AR coef
    rho_i = rho_draw[1] .+ delta_rho_draw[1,:]

    # covariance matrix 
    var_s = zeros(T, N)
    for t = 1:T
        tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
        if t == 1
            for ii in 1:N
                var_s[tt[ii],ii] = rho_i[ii]^2 * s0_var_draw[1] + sigma2_e_it[tt[ii],ii]
            end
            
        else
            i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
            for ii in i_update
                var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
            end
        end
    end

    cov_s = zeros(T, T, N)
    for ii = 1:N
        for t1 = loc_first_obs[ii]:loc_last_obs[ii]
            for t2 = t1:loc_last_obs[ii]
                cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
            end
        end
    end

    s_temp = zeros(N, T+1) # +1 for initial value

    for ii = 1:N
        nobs_ii = T_stay[ii]

        s_temp[ii, loc_first_obs[ii]] = s0_temp[ii]
        s_temp[ii, loc_first_obs[ii]+1:loc_last_obs[ii]+1] = rand(MvNormal(vec(zeros(nobs_ii,1)), 
                   make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii])))
    end
    s_temp[s_temp .== 0] .= NaN

    s_draw[1,:,:] = s_temp

    # c
    c_vdelta_sigma_u[1] = 0.5
    c_vdelta_sigma_e[1] = 0.5

    for i = ProgressBar(2:len_MCMC+1)

        # i = 2
        # println("iter = $i")

        # current values for state variables
        s_lag_temp = s_draw[i-1,:,1:end-1]' # T x N
        s_temp     = s_draw[i-1,:,2:end]'

        # variance of errors
        sigma2_u_it = kron(sigma2_u_draw[i-1,:], delta_sigma_u_draw[i-1,:]') # T x N
        sigma2_e_it = kron(sigma2_e_draw[i-1,:], delta_sigma_e_draw[i-1,:]') # T x N

        sigma2_u_it[loc_nan] .= NaN
        sigma2_e_it[loc_nan] .= NaN

        ###################################################
        ### BLOCK 1: draw α
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 0) )

        if control.true_alpha 
            #! impose true alpha
            alpha_draw[i,:] = theta.alpha

        else 

            sum_in_valpha = zeros(dimH, dimH)
            for ii in 1:N
                for tt in 1:T
                    if !any(isnan.(H[tt,ii,:]))
                        sum_in_valpha = sum_in_valpha + sigma2_u_it[tt,ii]^-1 * H[tt,ii,:] * H[tt,ii,:]'
                    end
                end
            end
            
            sum_in_mu_alpha = zeros(dimH, 1)
            for ii in 1:N
                for tt in 1:T
                    if !any(isnan.(H[tt,ii,:]))
                        sum_in_mu_alpha = sum_in_mu_alpha + sigma2_u_it[tt,ii]^-1 * H[tt,ii,:] * 
                                            (y[tt,ii] - H[tt,ii,:]' * delta_alpha_draw[i-1,:,ii] - s_temp[tt,ii])
                    end
                end
            end

            valpha_post = make_symmetric(( inv(valpha) + sum_in_valpha )^-1)
            mean_alpha_post = valpha_post * ( inv(valpha) * mu_alpha + sum_in_mu_alpha)

            alpha_draw[i,:] = rand(MvNormal(mean_alpha_post[:,1], valpha_post))
        end

        



        ###################################################
        ### BLOCK 2: draw ρ
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

        if control.true_rho 
            #! impose true rho
            rho_draw[i] = theta.rho

        else 
        
            vrho_post = ( inv(vrho) + sum_skipnan(sigma2_e_it.^-1 .* s_lag_temp.^2) )^-1
            mean_rho_post = vrho_post * ( inv(vrho) * mu_rho + sum_skipnan(sigma2_e_it.^-1 .* s_lag_temp .* (s_temp - repeat(delta_rho_draw[i-1,:]', T) .* s_lag_temp)) )

            rho_draw[i] = rand(Normal(mean_rho_post, sqrt(vrho_post)))
        end





        ###################################################
        ### BLOCK 3: draw q
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

        psi_alpha         = sum( z_alpha_draw[i-1,:] )
        psi_rho           = sum( z_rho_draw[i-1,:] )
        psi_sigma_u       = sum( z_sigma_u_draw[i-1,:] )
        psi_sigma_e       = sum( z_sigma_e_draw[i-1,:] )

        q_alpha_draw[i]   = rand( Beta(a + psi_alpha,   b + N - psi_alpha  ) )
        q_rho_draw[i]     = rand( Beta(a + psi_rho,     b + N - psi_rho    ) )
        q_sigma_u_draw[i] = rand( Beta(a + psi_sigma_u, b + N - psi_sigma_u) )
        q_sigma_e_draw[i] = rand( Beta(a + psi_sigma_e, b + N - psi_sigma_e) )





        ###################################################
        ### BLOCK 4: draw variance for δ^α, δ^ρ, δ^σ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

        ### V_δ^α 
        if control.true_vdelta_alpha
            #! impose true vdelta_alpha
            vdelta_alpha_draw[i,:,:] = theta.vdelta_alpha

        else
            nu_vdelta_alpha_post  = nu_vdelta_alpha + psi_alpha
            Psi_vdelta_alpha_post = Psi_vdelta_alpha + make_symmetric(crossprod(delta_alpha_draw[i-1,:,z_alpha_draw[i-1,:] .== 1]'))

            vdelta_alpha_draw[i,:,:] = rand(InverseWishart(nu_vdelta_alpha_post, Psi_vdelta_alpha_post))
        end


        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

        ### V_δ^ρ 
        if control.true_vdelta_rho
            #! impose true variance of delta-rho
            vdelta_rho_draw[i] = theta.vdelta_rho; 
        else
            nu_vdelta_rho_post  = nu_vdelta_rho + psi_rho
            tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_rho_draw[i-1,:] .== 1].^2)

            vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))
        end

        ### V_δ^σ_u (adaptive RWMH)
        if control.true_vdelta_sigma_u
            #! impose true variance of delta-sigma-u
            vdelta_sigma_u_draw[i]  = mean(InverseGamma(theta.nu_delta_sigma_u/2, theta.tau_delta_sigma_u/2))
            RWMH_u_accept_record[i] = 1
            c_vdelta_sigma_u[i]     = 1

        else
            # log posterior of ω (will be used in RWMH)
            delta_sigma_u_slab = delta_sigma_u_draw[i-1, z_sigma_u_draw[i-1,:] .== 1]

            log_post_omega_u(x) = psi_sigma_u*(1/x+2)*log(1/x+1) - psi_sigma_u*loggamma(1/x+2) - 
                    (nu_vdelta_sigma_u/2+1)*log(x) - 1/x*(sum(log.(delta_sigma_u_slab)) + sum(delta_sigma_u_slab.^-1) + tau_vdelta_sigma_u/2 )

            # RWMH
            c_u_i = c_vdelta_sigma_u[i-1]

            RWMH_draw_u = rand(truncated(Normal(vdelta_sigma_u_draw[i-1], sqrt(c_u_i)), lower = 0))

            # calculate acceptance rate
            diff_log_post = log_post_omega_u(RWMH_draw_u) - log_post_omega_u(vdelta_sigma_u_draw[i-1])
            diff_log_CDF  = log(cdf(Normal(0,sqrt(c_u_i)), RWMH_draw_u)) - log(cdf(Normal(0,sqrt(c_u_i)), vdelta_sigma_u_draw[i-1]))

            prob_RWMH_u = min(1, exp(diff_log_post - diff_log_CDF))

            # accept or not?
            RWMH_accept_u = rand(Bernoulli(prob_RWMH_u))

            if RWMH_accept_u
                vdelta_sigma_u_draw[i] = RWMH_draw_u
                RWMH_u_accept_record[i] = 1
            else
                vdelta_sigma_u_draw[i] = vdelta_sigma_u_draw[i-1]
                RWMH_u_accept_record[i] = 0
            end

            # update random walk step size
            log_c_u = g( log(c_vdelta_sigma_u[i-1]) + i^(-0.55) * (prob_RWMH_u - opt_ar) )
            c_vdelta_sigma_u[i] = exp(log_c_u)
        end

        ### V_δ^σ_e (adaptive RWMH)
        if control.true_vdelta_sigma_e
            #! impose true variance of delta-sigma-e
            vdelta_sigma_e_draw[i]  = mean(InverseGamma(theta.nu_delta_sigma_e/2, theta.tau_delta_sigma_e/2))
            RWMH_e_accept_record[i] = 1
            c_vdelta_sigma_e[i]     = 1

        else
            # log posterior of ω (will be used in RWMH)
            delta_sigma_e_slab = delta_sigma_e_draw[i-1, z_sigma_e_draw[i-1,:] .== 1]

            log_post_omega_e(x) = psi_sigma_e*(1/x+2)*log(1/x+1) - psi_sigma_e*loggamma(1/x+2) - 
                    (nu_vdelta_sigma_e/2+1)*log(x) - 1/x*(sum(log.(delta_sigma_e_slab)) + sum(delta_sigma_e_slab.^-1) + tau_vdelta_sigma_e/2 )

            # RWMH
            c_e_i = c_vdelta_sigma_e[i-1]

            RWMH_draw_e = rand(truncated(Normal(vdelta_sigma_e_draw[i-1], sqrt(c_e_i)), lower = 0))

            # calculate acceptance rate
            diff_log_post = log_post_omega_e(RWMH_draw_e) - log_post_omega_e(vdelta_sigma_e_draw[i-1])
            diff_log_CDF  = log(cdf(Normal(0, sqrt(c_e_i)), RWMH_draw_e)) - log(cdf(Normal(0, sqrt(c_e_i)), vdelta_sigma_e_draw[i-1]))

            prob_RWMH_e = min(1, exp(diff_log_post - diff_log_CDF))

            # accept?
            RWMH_accept_e = rand(Bernoulli(prob_RWMH_e))

            if RWMH_accept_e
                vdelta_sigma_e_draw[i] = RWMH_draw_e
                RWMH_e_accept_record[i] = 1
            else
                vdelta_sigma_e_draw[i] = vdelta_sigma_e_draw[i-1]
                RWMH_e_accept_record[i] = 0
            end

            # update random walk step size
            log_c_e = g( log(c_vdelta_sigma_e[i-1]) + i^(-0.55) * (prob_RWMH_e - opt_ar) )
            c_vdelta_sigma_e[i] = exp(log_c_e)
        end





        ###################################################
        ### BLOCK 5: draw (z,δ) for α and ρ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

        ### draw z_rho, delta_rho
        if control.true_delta_rho
            #! impose true delta-rho
            delta_rho_draw[i,:,:] = delta_rho
            z_rho_draw[i,:] .= 1
            z_rho_draw[i,collect(1:N)[delta_rho .== 0]] .= 0

        else
            ### draw z_rho 			
            # posterior mean and variance of delta_rho_i
            post_var_delta_rho  = [ (vdelta_rho_draw[i]^-1 + sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii].^2) )^-1 for ii in 1:N ]

            post_mean_delta_rho = [ post_var_delta_rho[ii] * sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii] .* 
                                (s_temp[:,ii] - rho_draw[i] * s_lag_temp[:,ii])) for ii in 1:N ]

            K_rho = q_rho_draw[i] / (1-q_rho_draw[i]) * (vdelta_rho_draw[i] ./ post_var_delta_rho).^(-0.5) .*
                    exp.( 0.5*post_mean_delta_rho.^2 ./ post_var_delta_rho )

            if sum(K_rho .== Inf) != 0
                Inf_pos = collect(1:N)[K_rho .== Inf]
                K_rho[Inf_pos] .= 10^8
            end

            prob_rho = K_rho ./ (1 .+ K_rho) # probability of model 1
            prob_rho_draw[i,:] = prob_rho

            z_rho_draw[i,:] = [rand(Bernoulli(x)) for x in prob_rho]

            ### draw δ_rho 
            zero_rho_pos = collect(1:N)[z_rho_draw[i,:] .== 0]

            delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

            #! this is questionable
            # delta_rho_draw[i,:] = delta_rho_draw[i,:] .* (abs.(delta_rho_draw[i,:]) .< 1)

            #! comment out if ignore sparsity
            if length(zero_rho_pos) != 0
                delta_rho_draw[i,zero_rho_pos] .= 0
            end

        end
 


        ### draw z_alpha, delta_alpha
        # posterior mean and variance of beta (delta_alpha_i and s)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 6) )

        if control.true_s & ~control.true_delta_alpha

            #! impose true s
            s_draw[i,:,:] = [s0 s']

            ### draw z_alpha
            # posterior mean and variance of delta_alpha_i
            inv_vdelta_alpha = inv(vdelta_alpha_draw[i,:,:])

            post_var_delta_alpha  = [make_symmetric(inv( inv_vdelta_alpha .+ H[:,ii,:]' * Diagonal(sigma2_u_it[:,ii].^-1) * H[:,ii,:] )) for ii in 1:N]
            post_mean_delta_alpha = [post_var_delta_alpha[ii] * H[:,ii,:]' * Diagonal(sigma2_u_it[:,ii].^-1) * (y[:,ii] - s_draw[i,ii,2:end]) for ii in 1:N]

            # K_alpha = q_alpha_draw[i] / (1-q_alpha_draw[i]) * [(det(vdelta_alpha_draw[i,:,:]) / det(post_var_delta_alpha[ii]))^(-0.5) * 
            #             exp(0.5*post_mean_delta_alpha[ii]' * inv(post_var_delta_alpha[ii]) * post_mean_delta_alpha[ii]) for ii in 1:N]

            K_alpha = q_alpha_draw[i] / (1-q_alpha_draw[i]) * exp.([-0.5*log(det(vdelta_alpha_draw[i,:,:])) + 0.5*log(det(post_var_delta_alpha[ii])) + 
                       0.5*post_mean_delta_alpha[ii]' * inv(post_var_delta_alpha[ii]) * post_mean_delta_alpha[ii] for ii in 1:N])

            if sum(K_alpha .== Inf) != 0
                Inf_pos = collect(1:N)[K_alpha .== Inf]
                K_alpha[Inf_pos] .= 10^8
            end

            prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1

            z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

            ### draw δ_alpha
            zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

            temp_draw = [rand(MvNormal(post_mean_delta_alpha[ii], post_var_delta_alpha[ii])) for ii in 1:N]
            delta_alpha_draw[i,:,:] = reduce(vcat,transpose(temp_draw))' # convert vector of vectors to matrix

            if length(zero_alpha_pos) != 0
                delta_alpha_draw[i, :, zero_alpha_pos] .= 0
            end

        elseif ~control.true_s & control.true_delta_alpha

            #! impose true delta-alpha
            delta_alpha_draw[i,:,:] = delta_alpha
            z_alpha_draw[i,:] .= 1
            z_alpha_draw[i,collect(1:N)[delta_alpha[1,:] .== 0]] .= 0
               
            # prior covarance matrix for beta

            # s0 (simultation smoother)
            # draw mean of s0
            v_s0_post = ( inv(v_s0) + N*s0_var_draw[i-1]^-1 )^-1
            mean_s0_post = v_s0_post * (s0_var_draw[i-1]^-1 * sum(s_draw[i-1,:,1]) + inv(v_s0) * mu_s0)
            s0_mean_draw[i] = rand(Normal(mean_s0_post, sqrt(v_s0_post)))

            # draw variance of s0
            nu_sigma_s0_post = nu_sigma_s0 + N
            tau_sigma_s0_post = tau_sigma_s0 + sum((s_draw[i-1,:,1] .- s0_mean_draw[i]).^2)
            s0_var_draw[i] = rand(InverseGamma(nu_sigma_s0_post/2, tau_sigma_s0_post/2))

            # AR coef
            rho_i = rho_draw[i] .+ delta_rho_draw[i,:]

            # contant term in meas equation
            Psi_i0 = zeros(T, N)
            for ii in 1:N
                Psi_i0[:,ii] = H[:,ii,:] * delta_alpha_draw[i,:,ii]
            end

            post_mean_s, post_cov_s = direct_draw_S(y, Psi_i0, rho_i, sigma2_u_it, sigma2_e_it, s0_var_draw[i])

            s_draw_1T = [rand(MvNormal(post_mean_s[:,ii], post_cov_s[ii])) for ii in 1:N]
            s_draw_1T = reduce(vcat,transpose(s_draw_1T))'

            P10 = rho_i .* s0_var_draw[i] .* rho_i + sigma2_e_it[1,:]
            post_mean_s0 = s0_mean_draw[i] .+ s0_var_draw[i] .* rho_i .* P10.^-1 .* (s_draw_1T[1,:] - rho_i .* s0_mean_draw[i])
            post_var_s0 = s0_var_draw[i] .- s0_var_draw[i] .* rho_i .* P10.^-1 .* rho_i .* s0_var_draw[i]
            s0_temp = [rand(Normal(post_mean_s0[ii], sqrt(post_var_s0[ii]))) for ii in 1:N]

            s_draw[i,:,:] = [s0_temp s_draw_1T']

        elseif ~control.true_s & ~control.true_delta_alpha

            #! impose nothing
            # AR coef
            rho_i = rho_draw[i] .+ delta_rho_draw[i,:]

            # draw mean of s0
            v_s0_post = ( inv(v_s0) + N*s0_var_draw[i-1]^-1 )^-1

            s0_prev = [s_draw[i-1, ii, loc_first_obs[ii]] for ii = 1:N] # last draw of s0

            mean_s0_post = v_s0_post * (s0_var_draw[i-1]^-1 * sum(s0_prev) + inv(v_s0) * mu_s0)
            s0_mean_draw[i] = [rand(Normal(mean_s0_post * rho_i[ii]^(loc_first_obs[ii]-1), sqrt(v_s0_post))) for ii in 1:N]

            # draw variance of s0, will be used in the calculation of variance of s
            nu_sigma_s0_post = nu_sigma_s0 + N
            tau_sigma_s0_post = tau_sigma_s0 + sum((s0_prev .- s0_mean_draw[i]).^2)
            s0_var_draw[i] = rand(InverseGamma(nu_sigma_s0_post/2, tau_sigma_s0_post/2))

            # covariance matrix of s
            var_s = zeros(T, N)
            for t = 1:T
                tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
                if t == 1
                    for ii in 1:N
                        var_s[tt[ii],ii] = rho_i[ii]^2 * s0_var_draw[i] + sigma2_e_it[tt[ii],ii]
                    end
                    
                else
                    i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
                    for ii in i_update
                        var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
                    end
                end
            end

            cov_s = zeros(T, T, N)
            for ii = 1:N
                for t1 = loc_first_obs[ii]:loc_last_obs[ii]
                    for t2 = t1:loc_last_obs[ii]
                        cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                        cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
                    end
                end
            end


            # prior covarance matrix for beta (delta-alpha + s)

            # fill in values in the last loc_first_obs[ii] + dimH element
            Sigma_beta_prior = zeros(dimH + T, dimH + T, N)
            # Sigma_beta_prior[:] .= NaN
            for ii = 1:N
                pos  = dimH + loc_first_obs[ii]
                pos2 = dimH + loc_last_obs[ii]
                Sigma_beta_prior[(pos-dimH):(pos-1), (pos-dimH):(pos-1), ii] = make_symmetric(vdelta_alpha_draw[i,:,:]) # delta-alpha
                Sigma_beta_prior[pos:pos2, pos:pos2, ii] = 
                    make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) # s_i1:T
            end

            # design matrix (delta-alpha + s_i1 + ... + s_iT)
            X_i = zeros(T, dimH + T, N)
            X_i[:] .= NaN

            for ii = 1:N
                X_i[:,loc_first_obs[ii]:(loc_first_obs[ii]+dimH-1), ii] = H[:,ii,:]
                X_i[loc_first_obs[ii]:loc_last_obs[ii], (loc_first_obs[ii]+dimH):(loc_last_obs[ii]+dimH), ii] = I(T_stay[ii])
            end

            # X_i[17:end,17:end,ii]

            # posterior for beta (delta-alpha + s)
            post_var_beta  = [make_symmetric( inv( 
                                inv(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH, loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) .+ 
                                X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
                                Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
                                X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii] ) ) for ii in 1:N]
            post_mean_beta = [post_var_beta[ii] * X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
                                Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii], ii].^-1) * 
                                (y[loc_first_obs[ii]:loc_last_obs[ii], ii] - H[loc_first_obs[ii]:loc_last_obs[ii], ii,:] * alpha_draw[i,:]) for ii in 1:N]

            # posterior for s (X_i = I(T))
            post_var_s  = [make_symmetric( inv( inv(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) .+ 
                            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii], ii].^-1) ) ) for ii in 1:N]
            post_mean_s = [post_var_s[ii] * Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
                            (y[loc_first_obs[ii]:loc_last_obs[ii], ii] - H[loc_first_obs[ii]:loc_last_obs[ii],ii,:] * alpha_draw[i,:]) for ii in 1:N]


            # Z-delta-alpha
            K_alpha = q_alpha_draw[i] / (1-q_alpha_draw[i]) * 
                                exp.([0.5*logdet(post_var_beta[ii]) - 
                                0.5*logdet(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH,loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) - 
                                0.5*logdet(post_var_s[ii]) + 0.5*logdet(cov_s[loc_first_obs[ii]:loc_last_obs[ii],loc_first_obs[ii]:loc_last_obs[ii],ii]) + 
                                    0.5*post_mean_beta[ii]' * inv(post_var_beta[ii]) * post_mean_beta[ii] -
                                    0.5*post_mean_s[ii]' * inv(post_var_s[ii]) * post_mean_s[ii] for ii in 1:N])

            if sum(K_alpha .== Inf) != 0
                Inf_pos = collect(1:N)[K_alpha .== Inf]
                K_alpha[Inf_pos] .= 10^8
            end

            prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1
            prob_alpha_draw[i,:] = prob_alpha

            z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

            zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

            ### draw delta_alpha and s when z_alpha_i = 1
            delta_alpha_temp = zeros(dimH, N)
            s_temp = zeros(T, N)
            for ii in 1:N
                beta_temp = rand(MvNormal(post_mean_beta[ii], post_var_beta[ii]))

                delta_alpha_temp[:,ii] = beta_temp[1:dimH]
                s_temp[:,ii] = [NaN*ones(loc_first_obs[ii]-1); beta_temp[(dimH+1):end]; NaN*ones(T - loc_last_obs[ii])]
            end

            delta_alpha_draw[i,:,:] = delta_alpha_temp

            ### draw s when z_alpha_i = 0
            if length(zero_alpha_pos) != 0

                # delta-alpha are zero
                delta_alpha_draw[i, :, zero_alpha_pos] .= 0

                # posterior of beta (X_i = I(T))
                for ii in zero_alpha_pos
                    s_draw_1T = rand(MvNormal(post_mean_s[ii], make_symmetric(post_var_s[ii])))
                    s_temp[:, ii] = [NaN*ones(loc_first_obs[ii]-1); s_draw_1T; NaN*ones(T - loc_last_obs[ii])]
                end

            end

            # s0 (simultation smoother)
            s00 = s0_mean_draw[i]
            P00 = s0_var_draw[i]
            P10 = rho_i .* P00 .* rho_i + [sigma2_e_it[loc_first_obs[ii], ii] for ii in 1:N]
            
            s1_temp = [s_temp[loc_first_obs[ii],ii] for ii in 1:N]
            post_mean_s0 = s00 .+ P00 .* rho_i .* P10.^-1 .* (s1_temp - rho_i .* s00)
            post_var_s0 = P00 .- P00 .* rho_i .* P10.^-1 .* rho_i .* P00
            s0_temp = [rand(Normal(post_mean_s0[ii], sqrt(post_var_s0[ii]))) for ii in 1:N]
            
            # insert S_0 into S_1:T
            s_temp2 = [NaN*ones(1,N); s_temp]
            for ii in 1:N
                s_temp2[loc_first_obs[ii], ii] = s0_temp[ii]
            end
            s_draw[i,:,:] = s_temp2'

        else
            #! impose true s
            s_draw[i,:,:] = [s0 s']

            #! impose true delta-alpha
            delta_alpha_draw[i,:,:] = delta_alpha
            z_alpha_draw[i,:] .= 1
            z_alpha_draw[i,collect(1:N)[delta_alpha[1,:] .== 0]] .= 0
        end

        #! ignore delta-alpha
        # delta_alpha_draw[i,:,:] .= 0

        # current values for state variables
        s_lag_temp = s_draw[i,:,1:end-1]' # T x N
        s_temp     = s_draw[i,:,2:end]' # T x N





        ###################################################
        ### BLOCK 5: draw (z,δ) for σ^2_e and σ^2_u
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

        
        ### draw z_sigma_u
        if control.true_delta_sigma_u
            #! impose true delta_sigma2_u
            delta_sigma_u_draw[i,:] = delta_sigma_u
            z_sigma_u_draw[i,:] .= 1
            z_sigma_u_draw[i,collect(1:N)[delta_sigma_u .== 0]] .= 0

        else
            # parameters in posterior of δ^σ
            nu_delta_sigma_u_post  = 2*vdelta_sigma_u_draw[i]^(-1) + 4 .+ T_stay

            sum_y_sigma_u_sq = [sum_skipnan(sigma2_u_draw[i-1,:].^-1 .* (y[:,ii] - H[:,ii,:] * (alpha_draw[i,:] .+ delta_alpha_draw[i,:,ii]) - s_temp[:,ii]).^2) for ii in 1:N]
            tau_delta_sigma_u_post = 2*vdelta_sigma_u_draw[i]^(-1) + 2 .+ sum_y_sigma_u_sq

            # posterior odd
            exp_part = 0.5*sum_y_sigma_u_sq          
            Const    = loggamma.(nu_delta_sigma_u_post/2) .- loggamma(vdelta_sigma_u_draw[i]^(-1)+2) .+ 
                        (vdelta_sigma_u_draw[i]^(-1)+2) * log(vdelta_sigma_u_draw[i]^(-1)+1) .- 
                        (nu_delta_sigma_u_post/2) .* log.(tau_delta_sigma_u_post/2)

            K_sigma_u = q_sigma_u_draw[i] / (1-q_sigma_u_draw[i]) * exp.(Const .+ exp_part)

            if sum(K_sigma_u .== Inf) != 0
                Inf_pos = collect(1:N)[K_sigma_u .== Inf]
                K_sigma_u[Inf_pos] .= 10^8
            end

            prob_sigma_u = K_sigma_u ./ (1 .+ K_sigma_u) # probability of model 1
            prob_sigma_u_draw[i,:] = prob_sigma_u

            z_sigma_u_draw[i,:] = [rand(Bernoulli(x)) for x in prob_sigma_u]

            ### draw δ_sigma_u
            zero_sigma_u_pos = collect(1:N)[z_sigma_u_draw[i,:] .== 0]

            delta_sigma_u_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_u_post[ii]/2, tau_delta_sigma_u_post[ii]/2)) for ii in 1:N]

            if length(zero_sigma_u_pos) != 0
                delta_sigma_u_draw[i,zero_sigma_u_pos] .= 1
            end

        end

        ### draw z_sigma_e
        if control.true_delta_sigma_e
            #! impose true delta_sigma_e
            delta_sigma_e_draw[i,:] = delta_sigma_e
            z_sigma_e_draw[i,:] .= 1
            z_sigma_e_draw[i,collect(1:N)[delta_sigma_e .== 0]] .= 0

        else
            # parameters in posterior of δ^σ_e
            nu_delta_sigma_e_post  = 2*vdelta_sigma_e_draw[i]^(-1) + 4 .+ T_stay

            sum_y_sigma_e_sq = [sum_skipnan(sigma2_e_draw[i-1,:].^-1 .* (s_temp[:,ii] - (rho_draw[i] + delta_rho_draw[i,ii]).* s_lag_temp[:,ii]).^2) for ii in 1:N]
            tau_delta_sigma_e_post = 2*vdelta_sigma_e_draw[i]^(-1) + 2 .+ sum_y_sigma_e_sq

            # posterior odd
            exp_part = 0.5*sum_y_sigma_e_sq
            Const    = loggamma.(nu_delta_sigma_e_post/2) .- loggamma(vdelta_sigma_e_draw[i]^(-1)+2) .+ 
                        (vdelta_sigma_e_draw[i]^(-1)+2) * log(vdelta_sigma_e_draw[i]^(-1)+1) .- 
                        (nu_delta_sigma_e_post/2) .* log.(tau_delta_sigma_e_post/2)

            K_sigma_e = q_sigma_e_draw[i] / (1-q_sigma_e_draw[i]) * exp.(Const .+ exp_part)

            if sum(K_sigma_e .== Inf) != 0
                Inf_pos = collect(1:N)[K_sigma_e .== Inf]
                K_sigma_e[Inf_pos] .= 10^8
            end

            prob_sigma_e = K_sigma_e ./ (1 .+ K_sigma_e)
            prob_sigma_e_draw[i,:] = prob_sigma_e

            z_sigma_e_draw[i,:] = [rand(Bernoulli(x)) for x in prob_sigma_e]

            ### draw δ_sigma_e
            zero_sigma_e_pos = collect(1:N)[z_sigma_e_draw[i,:] .== 0]

            delta_sigma_e_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_e_post[ii]/2, tau_delta_sigma_e_post[ii]/2)) for ii in 1:N]

            if length(zero_sigma_e_pos) != 0
                delta_sigma_e_draw[i,zero_sigma_e_pos] .= 1
            end
        end





        ###################################################
        ### BLOCK 6: draw σ^2
        ###################################################

        ### draw σ_u^2(t) 
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 7) )
     
        if control.true_sigma2_u
            #! impose true sigma2_u
            sigma2_u_draw[i,:] = sigma2_u 

        else
            nu_sigma_u_post  = nu_sigma_u .+ Nt
            tau_sigma_u_post = tau_sigma_u .+ [sum_skipnan(delta_sigma_u_draw[i,:].^-1 .* (y[tt,:] - s_temp[tt,:] - sum(H[tt,:,:] .*      
                                (delta_alpha_draw[i,:,:] + repeat(alpha_draw[i,:], outer = [1,N]))', dims = 2) ).^2 ) for tt in 1:T]

            sigma2_u_draw[i,:] = [rand(InverseGamma(nu_sigma_u_post[tt]/2, tau_sigma_u_post[tt]/2)) for tt in 1:T]

        end

        ### draw σ_e^2(t) 
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 8) )
        if control.true_sigma2_e
            #! impose true sigma2_e
            sigma2_e_draw[i,:] = sigma2_e 

        else
            nu_sigma_e_post  = nu_sigma_e .+ Nt
            tau_sigma_e_post = tau_sigma_e .+ [sum_skipnan(delta_sigma_e_draw[i,:].^-1 .* (s_temp[tt,:] - rho_i .* s_lag_temp[tt,:]).^2) for tt in 1:T]

            sigma2_e_draw[i,:] = [rand(InverseGamma(nu_sigma_e_post[tt]/2, tau_sigma_e_post[tt]/2)) for tt in 1:T]

        end
    end

    # posterior draws
    alpha_draw_post           = alpha_draw[burnin:end,:]
    rho_draw_post             = rho_draw[burnin:end]
    delta_alpha_draw_post     = delta_alpha_draw[burnin:end,:,:]
    delta_rho_draw_post       = delta_rho_draw[burnin:end,:]
    delta_sigma_u_draw_post   = delta_sigma_u_draw[burnin:end,:]
    delta_sigma_e_draw_post   = delta_sigma_e_draw[burnin:end,:]
    vdelta_alpha_draw_post    = vdelta_alpha_draw[burnin:end,:,:]
    vdelta_rho_draw_post      = vdelta_rho_draw[burnin:end]
    vdelta_sigma_u_draw_post  = vdelta_sigma_u_draw[burnin:end,:]
    vdelta_sigma_e_draw_post  = vdelta_sigma_e_draw[burnin:end,:]
    sigma2_u_draw_post        = sigma2_u_draw[burnin:end,:]
    sigma2_e_draw_post        = sigma2_e_draw[burnin:end,:]
    z_alpha_draw_post         = z_alpha_draw[burnin:end,:]
    z_rho_draw_post           = z_rho_draw[burnin:end,:]
    z_sigma_u_draw_post       = z_sigma_u_draw[burnin:end,:]
    z_sigma_e_draw_post       = z_sigma_e_draw[burnin:end,:]
    prob_alpha_draw_post      = prob_alpha_draw[burnin:end,:]
    prob_rho_draw_post        = prob_rho_draw[burnin:end,:]
    prob_sigma_u_draw_post    = prob_sigma_u_draw[burnin:end,:]
    prob_sigma_e_draw_post    = prob_sigma_e_draw[burnin:end,:]
    q_alpha_draw_post         = q_alpha_draw[burnin:end]
    q_rho_draw_post           = q_rho_draw[burnin:end]
    q_sigma_u_draw_post       = q_sigma_u_draw[burnin:end]
    q_sigma_e_draw_post       = q_sigma_e_draw[burnin:end]
    s_draw_post               = s_draw[burnin:end,:,:]
    s0_mean_draw_post         = s0_mean_draw[burnin:end]
    s0_var_draw_post          = s0_var_draw[burnin:end]
   

    # posterior mean
    alpha_hat          = mean( alpha_draw_post, dims = 1)'
    rho_hat            = mean( rho_draw_post )
    delta_alpha_hat    = mean( delta_alpha_draw_post, dims = 1)[1,:,:]'
    delta_rho_hat      = mean( delta_rho_draw_post, dims = 1)'
    delta_sigma_u_hat  = mean( delta_sigma_u_draw_post, dims = 1)'
    delta_sigma_e_hat  = mean( delta_sigma_e_draw_post, dims = 1)'
    vdelta_alpha_hat   = mean( vdelta_alpha_draw_post, dims = 1)[1,:,:]'
    vdelta_rho_hat     = mean( vdelta_rho_draw_post )
    vdelta_sigma_u_hat = mean( vdelta_sigma_u_draw_post )
    vdelta_sigma_e_hat = mean( vdelta_sigma_e_draw_post )
    sigma2_u_hat       = mean( sigma2_u_draw_post, dims = 1)'
    sigma2_e_hat       = mean( sigma2_e_draw_post, dims = 1)'
    z_alpha_hat        = mean( z_alpha_draw_post, dims = 1)'
    z_rho_hat          = mean( z_rho_draw_post, dims = 1)'
    z_sigma_u_hat      = mean( z_sigma_u_draw_post, dims = 1)'
    z_sigma_e_hat      = mean( z_sigma_e_draw_post, dims = 1)'
    prob_alpha_hat     = mean( prob_alpha_draw_post, dims = 1)'
    prob_rho_hat       = mean( prob_rho_draw_post, dims = 1)'
    prob_sigma_u_hat   = mean( prob_sigma_u_draw_post, dims = 1)'
    prob_sigma_e_hat   = mean( prob_sigma_e_draw_post, dims = 1)'
    q_alpha_hat        = mean( q_alpha_draw_post )
    q_rho_hat          = mean( q_rho_draw_post )
    q_sigma_u_hat      = mean( q_sigma_u_draw_post )
    q_sigma_e_hat      = mean( q_sigma_e_draw_post )
    s0_mean_hat        = mean( s0_mean_draw_post )
    s0_var_hat         = mean( s0_var_draw_post )

    s_hat = zeros(T+1, N)
    for ii in 1:N
        for tt in 1:T+1
            s_hat[tt, ii] = mean(skipnan(s_draw_post[:,ii,tt]))
        end
    end

    RWMH_u_accept_hat = mean(RWMH_u_accept_record[burnin:end])
    RWMH_e_accept_hat = mean(RWMH_e_accept_record[burnin:end])

    post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_u_hat = sigma2_u_hat, sigma2_e_hat = sigma2_e_hat,
                 delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat, delta_sigma_u_hat = delta_sigma_u_hat, delta_sigma_e_hat = delta_sigma_e_hat,
                 vdelta_alpha_hat = vdelta_alpha_hat, vdelta_rho_hat = vdelta_rho_hat, vdelta_sigma_u_hat = vdelta_sigma_u_hat, vdelta_sigma_e_hat = vdelta_sigma_e_hat,
                 z_alpha_hat = z_alpha_hat, z_rho_hat = z_rho_hat, z_sigma_u_hat = z_sigma_u_hat, z_sigma_e_hat = z_sigma_e_hat,
                 prob_alpha_hat = prob_alpha_hat, prob_rho_hat = prob_rho_hat, prob_sigma_u_hat = prob_sigma_u_hat, prob_sigma_e_hat = prob_sigma_e_hat,
                 q_alpha_hat = q_alpha_hat, q_rho_hat = q_rho_hat, q_sigma_u_hat = q_sigma_u_hat, q_sigma_e_hat = q_sigma_e_hat,
                 s_hat = s_hat, s0_var_hat = s0_var_hat, s0_mean_hat = s0_mean_hat,
                 RWMH_u_accept_hat = RWMH_u_accept_hat, RWMH_e_accept_hat = RWMH_e_accept_hat)
    
    post_draw = (alpha_draw          = alpha_draw_post,
                rho_draw             = rho_draw_post,
                delta_alpha_draw     = delta_alpha_draw_post,
                delta_rho_draw       = delta_rho_draw_post,
                delta_sigma_u_draw   = delta_sigma_u_draw_post,
                delta_sigma_e_draw   = delta_sigma_e_draw_post,
                vdelta_alpha_draw    = vdelta_alpha_draw_post,
                vdelta_rho_draw      = vdelta_rho_draw_post,
                vdelta_sigma_u_draw  = vdelta_sigma_u_draw_post,
                vdelta_sigma_e_draw  = vdelta_sigma_e_draw_post,
                sigma2_u_draw        = sigma2_u_draw_post,
                sigma2_e_draw        = sigma2_e_draw_post,
                z_alpha_draw         = z_alpha_draw_post,
                z_rho_draw           = z_rho_draw_post,
                z_sigma_u_draw       = z_sigma_u_draw_post,
                z_sigma_e_draw       = z_sigma_e_draw_post,
                prob_alpha_draw      = prob_alpha_draw_post,
                prob_rho_draw        = prob_rho_draw_post,
                prob_sigma_u_draw    = prob_sigma_u_draw_post,
                prob_sigma_e_draw    = prob_sigma_e_draw_post,
                q_alpha_draw         = q_alpha_draw_post,
                q_rho_draw           = q_rho_draw_post,
                q_sigma_u_draw       = q_sigma_u_draw_post,
                q_sigma_e_draw       = q_sigma_e_draw_post,
                s_draw               = s_draw_post,
                s0_mean_draw         = s0_mean_draw_post,
                s0_var_draw          = s0_var_draw_post)

    return post_mean, post_draw

end


# SS-HIP (direct sample s and delta-alpha), with alpha0 and alpha1 --> M2(homosk)
function est_M2_homosk_unb(y_all, H, lambda, opt_ar, len_MCMC, id_simul)

    #* This version directly draws s together with δ_α's.
    #* This verison is designed for unbalanced panel.

    #* this is M2(homosk), delta^sigma2_{iu} = delta^sigma2_{ie} = 1. 

    
    # len_MCMC = Int(50)
    # id_simul = seed
    # y = y_all

    len_MCMC = Int(len_MCMC)
    burnin   = Int(floor(0.5*len_MCMC))+1
    # burnin = 1

    y = y_all[1:end,:]

    T, N, dimH = size(H)
    
    # characters of unbalanced panel
    loc_nan = (y .=== NaN)
    loc_first_obs = mapslices(find_first_nonNA, y, dims = 1)[1,:];
    loc_last_obs  = mapslices(find_last_nonNA, y, dims = 1)[1,:]

    # T_stay = T .- sum(isnan.(y), dims = 1)[1,:]
    T_stay = loc_last_obs .- loc_first_obs .+ 1
    Nt = N .- sum(isnan.(y), dims = 2)[:,1]

    # unload HP
    mu_alpha, valpha,
    mu_rho, vrho, 
    nu_vdelta_alpha, Psi_vdelta_alpha, 
    nu_vdelta_rho, tau_vdelta_rho,
    nu_vdelta_sigma_u, tau_vdelta_sigma_u,
    nu_vdelta_sigma_e, tau_vdelta_sigma_e,
    nu_sigma_u, tau_sigma_u, nu_sigma_e, tau_sigma_e, 
    a, b, mu_s0, v_s0, nu_sigma_s0, tau_sigma_s0 = lambda

    # useful subfunctions
    crossprod(x) = x' * x
    g(x) = min(abs(x), 10) * sign(x) # helper function in adapative RWMH
    sum_skipnan(x) = sum(skipnan(x))

    q_alpha_draw        = zeros(len_MCMC+1)
    q_rho_draw          = zeros(len_MCMC+1)
    q_sigma_u_draw      = zeros(len_MCMC+1)
    q_sigma_e_draw      = zeros(len_MCMC+1)
    alpha_draw          = zeros(len_MCMC+1, dimH)
    rho_draw            = zeros(len_MCMC+1)
    vdelta_alpha_draw   = zeros(len_MCMC+1, dimH, dimH)
    vdelta_rho_draw     = zeros(len_MCMC+1)
    delta_alpha_draw    = zeros(len_MCMC+1, dimH, N)
    delta_rho_draw      = zeros(len_MCMC+1, N)
    delta_sigma_u_draw  = ones(len_MCMC+1, N)
    delta_sigma_e_draw  = ones(len_MCMC+1, N) 
    z_alpha_draw        = zeros(len_MCMC+1, N)
    z_rho_draw          = zeros(len_MCMC+1, N)
    sigma2_u_draw       = zeros(len_MCMC+1, T)
    sigma2_e_draw       = zeros(len_MCMC+1, T)
    s_draw              = zeros(len_MCMC+1, N, T+1)
    s0_mean_draw        = zeros(len_MCMC+1)
    s0_var_draw         = zeros(len_MCMC+1)

    prob_alpha_draw     = zeros(len_MCMC+1, N)
    prob_rho_draw       = zeros(len_MCMC+1, N)

    ### initialize parameters
    # α
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    alpha_draw[1,:] = mu_alpha

    # ρ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    rho_draw[1] = mu_rho

    # q
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
    q_alpha_draw[1]   = mean(Beta(a,b))
    q_rho_draw[1]     = mean(Beta(a,b))

    # v_δ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )
    vdelta_alpha_draw[1,:,:] = mean(InverseWishart(nu_vdelta_alpha, Psi_vdelta_alpha))
    vdelta_rho_draw[1]       = mean(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))

    # (z,δ)
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

    z_alpha_draw[1,:]   = rand(Bernoulli(q_alpha_draw[1]), N)
    z_rho_draw[1,:]     = rand(Bernoulli(q_rho_draw[1]), N)

    zero_pos_alpha    = collect(1:N)[z_alpha_draw[1,:] .== 0]
    zero_pos_rho      = collect(1:N)[z_rho_draw[1,:] .== 0]

    delta_rho_draw[1,:] = rand(Normal(0, sqrt(vdelta_rho_draw[1])), N)
    delta_rho_draw[1,:] = delta_rho_draw[1,:] .* abs.(delta_rho_draw[1,:] .< 0.2)
    delta_rho_draw[1,zero_pos_rho] .= 0

    # σ^2
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    sigma2_u_draw[1,:] = rand(InverseGamma(nu_sigma_u/2, tau_sigma_u/2), T)
    sigma2_e_draw[1,:] = rand(InverseGamma(nu_sigma_e/2, tau_sigma_e/2), T)

    sigma2_u_it = kron(sigma2_u_draw[1,:], delta_sigma_u_draw[1,:]') # T x N
    sigma2_e_it = kron(sigma2_e_draw[1,:], delta_sigma_e_draw[1,:]') # T x N

    sigma2_u_it[loc_nan] .= NaN
    sigma2_e_it[loc_nan] .= NaN

    # s0
    s0_mean_draw[1] = mean(Normal(mu_s0, sqrt(v_s0)))
    s0_var_draw[1]  = mean(InverseGamma(nu_sigma_s0/2, tau_sigma_s0/2))
    s0_temp = [rand(Normal(s0_mean_draw[1], sqrt(s0_var_draw[1]))) for ii in 1:N]

    # AR coef
    rho_i = rho_draw[1] .+ delta_rho_draw[1,:]

    # covariance matrix 
    var_s = zeros(T, N)
    for t = 1:T
        tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
        if t == 1
            for ii in 1:N
                var_s[tt[ii],ii] = rho_i[ii]^2 * s0_var_draw[1] + sigma2_e_it[tt[ii],ii]
            end
            
        else
            i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
            for ii in i_update
                var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
            end
        end
    end

    cov_s = zeros(T, T, N)
    for ii = 1:N
        for t1 = loc_first_obs[ii]:loc_last_obs[ii]
            for t2 = t1:loc_last_obs[ii]
                cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
            end
        end
    end

    s_temp = zeros(N, T+1) # +1 for initial value

    for ii = 1:N
        nobs_ii = T_stay[ii]

        s_temp[ii, loc_first_obs[ii]] = s0_temp[ii]
        s_temp[ii, loc_first_obs[ii]+1:loc_last_obs[ii]+1] = rand(MvNormal(vec(zeros(nobs_ii,1)), 
                   make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii])))
    end
    s_temp[s_temp .== 0] .= NaN

    s_draw[1,:,:] = s_temp

    for i = ProgressBar(2:len_MCMC+1)

        # i = 2
        # println("iter = $i")

        # current values for state variables
        s_lag_temp = s_draw[i-1,:,1:end-1]' # T x N
        s_temp     = s_draw[i-1,:,2:end]'

        # variance of errors
        sigma2_u_it = kron(sigma2_u_draw[i-1,:], delta_sigma_u_draw[i-1,:]') # T x N
        sigma2_e_it = kron(sigma2_e_draw[i-1,:], delta_sigma_e_draw[i-1,:]') # T x N

        sigma2_u_it[loc_nan] .= NaN
        sigma2_e_it[loc_nan] .= NaN

        ###################################################
        ### BLOCK 1: draw α
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 0) )

        sum_in_valpha = zeros(dimH, dimH)
        for ii in 1:N
            for tt in 1:T
                if !any(isnan.(H[tt,ii,:]))
                    sum_in_valpha = sum_in_valpha + sigma2_u_it[tt,ii]^-1 * H[tt,ii,:] * H[tt,ii,:]'
                end
            end
        end
        
        sum_in_mu_alpha = zeros(dimH, 1)
        for ii in 1:N
            for tt in 1:T
                if !any(isnan.(H[tt,ii,:]))
                    sum_in_mu_alpha = sum_in_mu_alpha + sigma2_u_it[tt,ii]^-1 * H[tt,ii,:] * 
                                        (y[tt,ii] - H[tt,ii,:]' * delta_alpha_draw[i-1,:,ii] - s_temp[tt,ii])
                end
            end
        end

        valpha_post = make_symmetric(( inv(valpha) + sum_in_valpha )^-1)
        mean_alpha_post = valpha_post * ( inv(valpha) * mu_alpha + sum_in_mu_alpha)

        alpha_draw[i,:] = rand(MvNormal(mean_alpha_post[:,1], valpha_post))

        



        ###################################################
        ### BLOCK 2: draw ρ
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

        vrho_post = ( inv(vrho) + sum_skipnan(sigma2_e_it.^-1 .* s_lag_temp.^2) )^-1
        mean_rho_post = vrho_post * ( inv(vrho) * mu_rho + sum_skipnan(sigma2_e_it.^-1 .* s_lag_temp .* (s_temp - repeat(delta_rho_draw[i-1,:]', T) .* s_lag_temp)) )

        rho_draw[i] = rand(Normal(mean_rho_post, sqrt(vrho_post)))





        ###################################################
        ### BLOCK 3: draw q
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

        psi_alpha         = sum( z_alpha_draw[i-1,:] )
        psi_rho           = sum( z_rho_draw[i-1,:] )

        q_alpha_draw[i]   = rand( Beta(a + psi_alpha,   b + N - psi_alpha  ) )
        q_rho_draw[i]     = rand( Beta(a + psi_rho,     b + N - psi_rho    ) )





        ###################################################
        ### BLOCK 4: draw variance for δ^α, δ^ρ, δ^σ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

        ### V_δ^α 
        nu_vdelta_alpha_post  = nu_vdelta_alpha + psi_alpha
        Psi_vdelta_alpha_post = Psi_vdelta_alpha + make_symmetric(crossprod(delta_alpha_draw[i-1,:,z_alpha_draw[i-1,:] .== 1]'))

        vdelta_alpha_draw[i,:,:] = rand(InverseWishart(nu_vdelta_alpha_post, Psi_vdelta_alpha_post))


        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

        ### V_δ^ρ 
        nu_vdelta_rho_post  = nu_vdelta_rho + psi_rho
        tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_rho_draw[i-1,:] .== 1].^2)

        vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

       

        ###################################################
        ### BLOCK 5: draw (z,δ) for α and ρ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

        ### draw z_rho, delta_rho
        ### draw z_rho 			
        # posterior mean and variance of delta_rho_i
        post_var_delta_rho  = [ (vdelta_rho_draw[i]^-1 + sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii].^2) )^-1 for ii in 1:N ]

        post_mean_delta_rho = [ post_var_delta_rho[ii] * sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii] .* 
                            (s_temp[:,ii] - rho_draw[i] * s_lag_temp[:,ii])) for ii in 1:N ]

        K_rho = q_rho_draw[i] / (1-q_rho_draw[i]) * (vdelta_rho_draw[i] ./ post_var_delta_rho).^(-0.5) .*
                exp.( 0.5*post_mean_delta_rho.^2 ./ post_var_delta_rho )

        if sum(K_rho .== Inf) != 0
            Inf_pos = collect(1:N)[K_rho .== Inf]
            K_rho[Inf_pos] .= 10^8
        end

        prob_rho = K_rho ./ (1 .+ K_rho) # probability of model 1
        prob_rho_draw[i,:] = prob_rho

        z_rho_draw[i,:] = [rand(Bernoulli(x)) for x in prob_rho]

        ### draw δ_rho 
        zero_rho_pos = collect(1:N)[z_rho_draw[i,:] .== 0]

        delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

        if length(zero_rho_pos) != 0
            delta_rho_draw[i,zero_rho_pos] .= 0
        end
 


        ### draw z_alpha, delta_alpha
        # posterior mean and variance of beta (delta_alpha_i and s)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 6) )

        # draw mean of s0
        v_s0_post = ( inv(v_s0) + N*s0_var_draw[i-1]^-1 )^-1

        s0_prev = [s_draw[i-1, ii,loc_first_obs[ii]] for ii = 1:N] # last draw of s0

        mean_s0_post = v_s0_post * (s0_var_draw[i-1]^-1 * sum(s0_prev) + inv(v_s0) * mu_s0)
        s0_mean_draw[i] = rand(Normal(mean_s0_post, sqrt(v_s0_post)))

        # draw variance of s0, will be used in the calculation of variance of s
        nu_sigma_s0_post = nu_sigma_s0 + N
        tau_sigma_s0_post = tau_sigma_s0 + sum((s0_prev .- s0_mean_draw[i]).^2)
        s0_var_draw[i] = rand(InverseGamma(nu_sigma_s0_post/2, tau_sigma_s0_post/2))

        # AR coef
        rho_i = rho_draw[i] .+ delta_rho_draw[i,:]

        # covariance matrix of s
        var_s = zeros(T, N)
        for t = 1:T
            tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
            if t == 1
                for ii in 1:N
                    var_s[tt[ii],ii] = rho_i[ii]^2 * s0_var_draw[i] + sigma2_e_it[tt[ii],ii]
                end
                
            else
                i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
                for ii in i_update
                    var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
                end
            end
        end

        cov_s = zeros(T, T, N)
        for ii = 1:N
            for t1 = loc_first_obs[ii]:loc_last_obs[ii]
                for t2 = t1:loc_last_obs[ii]
                    cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                    cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
                end
            end
        end


        # prior covarance matrix for beta (delta-alpha + s)

        # fill in values in the last loc_first_obs[ii] + dimH element
        Sigma_beta_prior = zeros(dimH + T, dimH + T, N)
        # Sigma_beta_prior[:] .= NaN
        for ii = 1:N
            pos  = dimH + loc_first_obs[ii]
            pos2 = dimH + loc_last_obs[ii]
            Sigma_beta_prior[(pos-dimH):(pos-1), (pos-dimH):(pos-1), ii] = make_symmetric(vdelta_alpha_draw[i,:,:]) # delta-alpha
            Sigma_beta_prior[pos:pos2, pos:pos2, ii] = 
                make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) # s_i1:T
        end

        # design matrix (delta-alpha + s_i1 + ... + s_iT)
        X_i = zeros(T, dimH + T, N)
        X_i[:] .= NaN

        for ii = 1:N
            X_i[:,loc_first_obs[ii]:(loc_first_obs[ii]+dimH-1), ii] = H[:,ii,:]
            X_i[loc_first_obs[ii]:loc_last_obs[ii], (loc_first_obs[ii]+dimH):(loc_last_obs[ii]+dimH), ii] = I(T_stay[ii])
        end

        # X_i[17:end,17:end,ii]

        # posterior for beta (delta-alpha + s)
        post_var_beta  = [make_symmetric( inv( 
                            inv(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH, loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) .+ 
                            X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
                            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
                            X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii] ) ) for ii in 1:N]
        post_mean_beta = [post_var_beta[ii] * X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
                            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii], ii].^-1) * 
                            (y[loc_first_obs[ii]:loc_last_obs[ii], ii] - H[loc_first_obs[ii]:loc_last_obs[ii], ii,:] * alpha_draw[i,:]) for ii in 1:N]

        # posterior for s (X_i = I(T))
        post_var_s  = [make_symmetric( inv( inv(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) .+ 
                        Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii], ii].^-1) ) ) for ii in 1:N]
        post_mean_s = [post_var_s[ii] * Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
                        (y[loc_first_obs[ii]:loc_last_obs[ii], ii] - H[loc_first_obs[ii]:loc_last_obs[ii],ii,:] * alpha_draw[i,:]) for ii in 1:N]


        # Z-delta-alpha
        K_alpha = q_alpha_draw[i] / (1-q_alpha_draw[i]) * 
                            exp.([0.5*logdet(post_var_beta[ii]) - 
                            0.5*logdet(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH,loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) - 
                            0.5*logdet(post_var_s[ii]) + 0.5*logdet(cov_s[loc_first_obs[ii]:loc_last_obs[ii],loc_first_obs[ii]:loc_last_obs[ii],ii]) + 
                                0.5*post_mean_beta[ii]' * inv(post_var_beta[ii]) * post_mean_beta[ii] -
                                0.5*post_mean_s[ii]' * inv(post_var_s[ii]) * post_mean_s[ii] for ii in 1:N])

        if sum(K_alpha .== Inf) != 0
            Inf_pos = collect(1:N)[K_alpha .== Inf]
            K_alpha[Inf_pos] .= 10^8
        end

        prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1
        prob_alpha_draw[i,:] = prob_alpha

        z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

        zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

        ### draw delta_alpha and s when z_alpha_i = 1
        delta_alpha_temp = zeros(dimH, N)
        s_temp = zeros(T, N)
        for ii in 1:N
            beta_temp = rand(MvNormal(post_mean_beta[ii], post_var_beta[ii]))

            delta_alpha_temp[:,ii] = beta_temp[1:dimH]
            s_temp[:,ii] = [NaN*ones(loc_first_obs[ii]-1); beta_temp[(dimH+1):end]; NaN*ones(T - loc_last_obs[ii])]
        end

        delta_alpha_draw[i,:,:] = delta_alpha_temp

        ### draw s when z_alpha_i = 0
        if length(zero_alpha_pos) != 0

            # delta-alpha are zero
            delta_alpha_draw[i, :, zero_alpha_pos] .= 0

            # posterior of beta (X_i = I(T))
            for ii in zero_alpha_pos
                s_draw_1T = rand(MvNormal(post_mean_s[ii], make_symmetric(post_var_s[ii])))
                s_temp[:, ii] = [NaN*ones(loc_first_obs[ii]-1); s_draw_1T; NaN*ones(T - loc_last_obs[ii])]
            end

        end

        # s0 (simultation smoother)
        s00 = s0_mean_draw[i]
        P00 = s0_var_draw[i]
        P10 = rho_i .* P00 .* rho_i + [sigma2_e_it[loc_first_obs[ii], ii] for ii in 1:N]
        
        s1_temp = [s_temp[loc_first_obs[ii],ii] for ii in 1:N]
        post_mean_s0 = s00 .+ P00 .* rho_i .* P10.^-1 .* (s1_temp - rho_i .* s0_mean_draw[i])
        post_var_s0 = P00 .- P00 .* rho_i .* P10.^-1 .* rho_i .* P00
        s0_temp = [rand(Normal(post_mean_s0[ii], sqrt(post_var_s0[ii]))) for ii in 1:N]
        
        # insert S_0 into S_1:T
        s_temp2 = [NaN*ones(1,N); s_temp]
        for ii in 1:N
            s_temp2[loc_first_obs[ii], ii] = s0_temp[ii]
        end
        s_draw[i,:,:] = s_temp2'

        # current values for state variables
        s_lag_temp = s_draw[i,:,1:end-1]' # T x N
        s_temp     = s_draw[i,:,2:end]' # T x N


        ###################################################
        ### BLOCK 6: draw σ^2
        ###################################################

        ### draw σ_u^2(t) 
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 7) )
     
        nu_sigma_u_post  = nu_sigma_u .+ Nt
        tau_sigma_u_post = tau_sigma_u .+ [sum_skipnan(delta_sigma_u_draw[i,:].^-1 .* (y[tt,:] - s_temp[tt,:] - sum(H[tt,:,:] .*      
                            (delta_alpha_draw[i,:,:] + repeat(alpha_draw[i,:], outer = [1,N]))', dims = 2) ).^2 ) for tt in 1:T]

        sigma2_u_draw[i,:] = [rand(InverseGamma(nu_sigma_u_post[tt]/2, tau_sigma_u_post[tt]/2)) for tt in 1:T]

        ### draw σ_e^2(t) 
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 8) )
        nu_sigma_e_post  = nu_sigma_e .+ Nt
        tau_sigma_e_post = tau_sigma_e .+ [sum_skipnan(delta_sigma_e_draw[i,:].^-1 .* (s_temp[tt,:] - rho_i .* s_lag_temp[tt,:]).^2) for tt in 1:T]

        sigma2_e_draw[i,:] = [rand(InverseGamma(nu_sigma_e_post[tt]/2, tau_sigma_e_post[tt]/2)) for tt in 1:T]
    end

    # posterior draws
    alpha_draw_post           = alpha_draw[burnin:end,:]
    rho_draw_post             = rho_draw[burnin:end]
    delta_alpha_draw_post     = delta_alpha_draw[burnin:end,:,:]
    delta_rho_draw_post       = delta_rho_draw[burnin:end,:]
    vdelta_alpha_draw_post    = vdelta_alpha_draw[burnin:end,:,:]
    vdelta_rho_draw_post      = vdelta_rho_draw[burnin:end]
    sigma2_u_draw_post        = sigma2_u_draw[burnin:end,:]
    sigma2_e_draw_post        = sigma2_e_draw[burnin:end,:]
    z_alpha_draw_post         = z_alpha_draw[burnin:end,:]
    z_rho_draw_post           = z_rho_draw[burnin:end,:]
    prob_alpha_draw_post      = prob_alpha_draw[burnin:end,:]
    prob_rho_draw_post        = prob_rho_draw[burnin:end,:]
    q_alpha_draw_post         = q_alpha_draw[burnin:end]
    q_rho_draw_post           = q_rho_draw[burnin:end]
    s_draw_post               = s_draw[burnin:end,:,:]
    s0_mean_draw_post         = s0_mean_draw[burnin:end]
    s0_var_draw_post          = s0_var_draw[burnin:end]
   

    # posterior mean
    alpha_hat          = mean( alpha_draw_post, dims = 1)'
    rho_hat            = mean( rho_draw_post )
    delta_alpha_hat    = mean( delta_alpha_draw_post, dims = 1)[1,:,:]'
    delta_rho_hat      = mean( delta_rho_draw_post, dims = 1)'
    vdelta_alpha_hat   = mean( vdelta_alpha_draw_post, dims = 1)[1,:,:]'
    vdelta_rho_hat     = mean( vdelta_rho_draw_post )
    sigma2_u_hat       = mean( sigma2_u_draw_post, dims = 1)'
    sigma2_e_hat       = mean( sigma2_e_draw_post, dims = 1)'
    z_alpha_hat        = mean( z_alpha_draw_post, dims = 1)'
    z_rho_hat          = mean( z_rho_draw_post, dims = 1)'
    prob_alpha_hat     = mean( prob_alpha_draw_post, dims = 1)'
    prob_rho_hat       = mean( prob_rho_draw_post, dims = 1)'
    q_alpha_hat        = mean( q_alpha_draw_post )
    q_rho_hat          = mean( q_rho_draw_post )
    s0_mean_hat        = mean( s0_mean_draw_post )
    s0_var_hat         = mean( s0_var_draw_post )

    s_hat = zeros(T+1, N)
    for ii in 1:N
        for tt in 1:T+1
            s_hat[tt, ii] = mean(skipnan(s_draw_post[:,ii,tt]))
        end
    end
    post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_u_hat = sigma2_u_hat, sigma2_e_hat = sigma2_e_hat,
                 delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat, 
                 vdelta_alpha_hat = vdelta_alpha_hat, vdelta_rho_hat = vdelta_rho_hat, 
                 z_alpha_hat = z_alpha_hat, z_rho_hat = z_rho_hat, 
                 prob_alpha_hat = prob_alpha_hat, prob_rho_hat = prob_rho_hat, 
                 q_alpha_hat = q_alpha_hat, q_rho_hat = q_rho_hat,
                 s_hat = s_hat, s0_var_hat = s0_var_hat, s0_mean_hat = s0_mean_hat)
    
    post_draw = (alpha_draw          = alpha_draw_post,
                rho_draw             = rho_draw_post,
                delta_alpha_draw     = delta_alpha_draw_post,
                delta_rho_draw       = delta_rho_draw_post,
                vdelta_alpha_draw    = vdelta_alpha_draw_post,
                vdelta_rho_draw      = vdelta_rho_draw_post,
                sigma2_u_draw        = sigma2_u_draw_post,
                sigma2_e_draw        = sigma2_e_draw_post,
                z_alpha_draw         = z_alpha_draw_post,
                z_rho_draw           = z_rho_draw_post,
                prob_alpha_draw      = prob_alpha_draw_post,
                prob_rho_draw        = prob_rho_draw_post,
                q_alpha_draw         = q_alpha_draw_post,
                q_rho_draw           = q_rho_draw_post,
                s_draw               = s_draw_post,
                s0_mean_draw         = s0_mean_draw_post,
                s0_var_draw          = s0_var_draw_post)

    return post_mean, post_draw

end


# SS-HIP-Hetero (direct sample s and delta-alpha), with alpha0 and alpha1, fix q-alpha and q-rho to 0 --> M2(RIP)
function est_M2_RIP_unb(y_all, H, lambda, opt_ar, len_MCMC, id_simul)

    #* This version directly draws s together with δ_α's.
    #* This verison is designed for unbalanced panel.

    #* this version force q-alpha and q-rho equal to 0

    # len_MCMC = Int(50)
    # id_simul = seed
    # y = y_all

    len_MCMC = Int(len_MCMC)
    burnin   = Int(floor(0.5*len_MCMC))+1
    # burnin = 1

    y = y_all[1:end,:]

    T, N, dimH = size(H)
    
    # characters of unbalanced panel
    loc_nan = (y .=== NaN)
    loc_first_obs = mapslices(find_first_nonNA, y, dims = 1)[1,:];
    loc_last_obs  = mapslices(find_last_nonNA, y, dims = 1)[1,:]

    # T_stay = T .- sum(isnan.(y), dims = 1)[1,:]
    T_stay = loc_last_obs .- loc_first_obs .+ 1
    Nt = N .- sum(isnan.(y), dims = 2)[:,1]

    # unload HP
    mu_alpha, valpha,
    mu_rho, vrho, 
    nu_vdelta_alpha, Psi_vdelta_alpha, 
    nu_vdelta_rho, tau_vdelta_rho,
    nu_vdelta_sigma_u, tau_vdelta_sigma_u,
    nu_vdelta_sigma_e, tau_vdelta_sigma_e,
    nu_sigma_u, tau_sigma_u, nu_sigma_e, tau_sigma_e, 
    a, b, mu_s0, v_s0, nu_sigma_s0, tau_sigma_s0 = lambda

    # useful subfunctions
    crossprod(x) = x' * x
    g(x) = min(abs(x), 10) * sign(x) # helper function in adapative RWMH
    sum_skipnan(x) = sum(skipnan(x))

    q_alpha_draw        = zeros(len_MCMC+1)
    q_rho_draw          = zeros(len_MCMC+1)
    q_sigma_u_draw      = zeros(len_MCMC+1)
    q_sigma_e_draw      = zeros(len_MCMC+1)
    alpha_draw          = zeros(len_MCMC+1, dimH)
    rho_draw            = zeros(len_MCMC+1)
    vdelta_alpha_draw   = zeros(len_MCMC+1, dimH, dimH)
    vdelta_rho_draw     = zeros(len_MCMC+1)
    vdelta_sigma_u_draw = zeros(len_MCMC+1)
    vdelta_sigma_e_draw = zeros(len_MCMC+1)
    delta_alpha_draw    = zeros(len_MCMC+1, dimH, N)
    delta_rho_draw      = zeros(len_MCMC+1, N)
    delta_sigma_u_draw  = zeros(len_MCMC+1, N)
    delta_sigma_e_draw  = zeros(len_MCMC+1, N) 
    z_alpha_draw        = zeros(len_MCMC+1, N)
    z_rho_draw          = zeros(len_MCMC+1, N)
    z_sigma_u_draw      = zeros(len_MCMC+1, N)
    z_sigma_e_draw      = zeros(len_MCMC+1, N)
    sigma2_u_draw       = zeros(len_MCMC+1, T)
    sigma2_e_draw       = zeros(len_MCMC+1, T)
    s_draw              = zeros(len_MCMC+1, N, T+1)
    s0_mean_draw        = zeros(len_MCMC+1)
    s0_var_draw         = zeros(len_MCMC+1)

    prob_alpha_draw     = zeros(len_MCMC+1, N)
    prob_rho_draw       = zeros(len_MCMC+1, N)
    prob_sigma_u_draw   = zeros(len_MCMC+1, N)
    prob_sigma_e_draw   = zeros(len_MCMC+1, N)

    # RWMH
    c_vdelta_sigma_u = zeros(len_MCMC+1) # random walk step size
    c_vdelta_sigma_e = zeros(len_MCMC+1)
    RWMH_u_accept_record = zeros(len_MCMC+1) # record acceptance status
    RWMH_e_accept_record = zeros(len_MCMC+1)

    ### initialize parameters
    # α
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    alpha_draw[1,:] = mu_alpha

    # ρ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    rho_draw[1] = mu_rho

    # q
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
    q_alpha_draw[1]   = mean(Beta(a,b))
    q_rho_draw[1]     = mean(Beta(a,b))
    q_sigma_u_draw[1] = mean(Beta(a,b))
    q_sigma_e_draw[1] = mean(Beta(a,b))

    # v_δ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )
    vdelta_alpha_draw[1,:,:] = mean(InverseWishart(nu_vdelta_alpha, Psi_vdelta_alpha))
    vdelta_rho_draw[1]       = mean(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))
    vdelta_sigma_u_draw[1]   = mean(InverseGamma(nu_vdelta_sigma_u/2, tau_vdelta_sigma_u/2))
    vdelta_sigma_e_draw[1]   = mean(InverseGamma(nu_vdelta_sigma_e/2, tau_vdelta_sigma_e/2))

    # (z,δ)
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

    z_alpha_draw[1,:]   = rand(Bernoulli(q_alpha_draw[1]), N)
    z_rho_draw[1,:]     = rand(Bernoulli(q_rho_draw[1]), N)
    z_sigma_u_draw[1,:] = rand(Bernoulli(q_sigma_u_draw[1]), N)
    z_sigma_e_draw[1,:] = rand(Bernoulli(q_sigma_e_draw[1]), N)

    zero_pos_alpha    = collect(1:N)[z_alpha_draw[1,:] .== 0]
    zero_pos_rho      = collect(1:N)[z_rho_draw[1,:] .== 0]
    zero_pos_sigma_u  = collect(1:N)[z_sigma_u_draw[1,:] .== 0]
    zero_pos_sigma_e  = collect(1:N)[z_sigma_e_draw[1,:] .== 0]

    delta_rho_draw[1,:] = rand(Normal(0, sqrt(vdelta_rho_draw[1])), N)
    delta_rho_draw[1,:] = delta_rho_draw[1,:] .* abs.(delta_rho_draw[1,:] .< 0.2)
    delta_rho_draw[1,zero_pos_rho] .= 0

    delta_sigma_u_draw[1,:] = rand(InverseGamma(1/vdelta_sigma_u_draw[1]+2, 1/vdelta_sigma_u_draw[1]+1), N)
    delta_sigma_u_draw[1,zero_pos_sigma_u] .= 1

    delta_sigma_e_draw[1,:] = rand(InverseGamma(1/vdelta_sigma_e_draw[1]+2, 1/vdelta_sigma_e_draw[1]+1), N)
    delta_sigma_e_draw[1,zero_pos_sigma_e] .= 1

    # σ^2
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    sigma2_u_draw[1,:] = rand(InverseGamma(nu_sigma_u/2, tau_sigma_u/2), T)
    sigma2_e_draw[1,:] = rand(InverseGamma(nu_sigma_e/2, tau_sigma_e/2), T)

    sigma2_u_it = kron(sigma2_u_draw[1,:], delta_sigma_u_draw[1,:]') # T x N
    sigma2_e_it = kron(sigma2_e_draw[1,:], delta_sigma_e_draw[1,:]') # T x N

    sigma2_u_it[loc_nan] .= NaN
    sigma2_e_it[loc_nan] .= NaN

    # s0
    s0_mean_draw[1] = mean(Normal(mu_s0, sqrt(v_s0)))
    s0_var_draw[1]  = mean(InverseGamma(nu_sigma_s0/2, tau_sigma_s0/2))
    s0_temp = [rand(Normal(s0_mean_draw[1], sqrt(s0_var_draw[1]))) for ii in 1:N]

    # AR coef
    rho_i = rho_draw[1] .+ delta_rho_draw[1,:]

    # covariance matrix 
    var_s = zeros(T, N)
    for t = 1:T
        tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
        if t == 1
            for ii in 1:N
                var_s[tt[ii],ii] = rho_i[ii]^2 * s0_var_draw[1] + sigma2_e_it[tt[ii],ii]
            end
            
        else
            i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
            for ii in i_update
                var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
            end
        end
    end

    cov_s = zeros(T, T, N)
    for ii = 1:N
        for t1 = loc_first_obs[ii]:loc_last_obs[ii]
            for t2 = t1:loc_last_obs[ii]
                cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
            end
        end
    end

    s_temp = zeros(N, T+1) # +1 for initial value

    for ii = 1:N
        nobs_ii = T_stay[ii]

        s_temp[ii, loc_first_obs[ii]] = s0_temp[ii]
        s_temp[ii, loc_first_obs[ii]+1:loc_last_obs[ii]+1] = rand(MvNormal(vec(zeros(nobs_ii,1)), 
                   make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii])))
    end
    s_temp[s_temp .== 0] .= NaN

    s_draw[1,:,:] = s_temp

    # c
    c_vdelta_sigma_u[1] = 0.5
    c_vdelta_sigma_e[1] = 0.5

    for i = ProgressBar(2:len_MCMC+1)

        # i = 2
        # println("iter = $i")

        # current values for state variables
        s_lag_temp = s_draw[i-1,:,1:end-1]' # T x N
        s_temp     = s_draw[i-1,:,2:end]'

        # variance of errors
        sigma2_u_it = kron(sigma2_u_draw[i-1,:], delta_sigma_u_draw[i-1,:]') # T x N
        sigma2_e_it = kron(sigma2_e_draw[i-1,:], delta_sigma_e_draw[i-1,:]') # T x N

        sigma2_u_it[loc_nan] .= NaN
        sigma2_e_it[loc_nan] .= NaN

        ###################################################
        ### BLOCK 1: draw α
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 0) )

        sum_in_valpha = zeros(dimH, dimH)
        for ii in 1:N
            for tt in 1:T
                if !any(isnan.(H[tt,ii,:]))
                    sum_in_valpha = sum_in_valpha + sigma2_u_it[tt,ii]^-1 * H[tt,ii,:] * H[tt,ii,:]'
                end
            end
        end
        
        sum_in_mu_alpha = zeros(dimH, 1)
        for ii in 1:N
            for tt in 1:T
                if !any(isnan.(H[tt,ii,:]))
                    sum_in_mu_alpha = sum_in_mu_alpha + sigma2_u_it[tt,ii]^-1 * H[tt,ii,:] * 
                                        (y[tt,ii] - H[tt,ii,:]' * delta_alpha_draw[i-1,:,ii] - s_temp[tt,ii])
                end
            end
        end

        valpha_post = make_symmetric(( inv(valpha) + sum_in_valpha )^-1)
        mean_alpha_post = valpha_post * ( inv(valpha) * mu_alpha + sum_in_mu_alpha)

        alpha_draw[i,:] = rand(MvNormal(mean_alpha_post[:,1], valpha_post))

        



        ###################################################
        ### BLOCK 2: draw ρ
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

        vrho_post = ( inv(vrho) + sum_skipnan(sigma2_e_it.^-1 .* s_lag_temp.^2) )^-1
        mean_rho_post = vrho_post * ( inv(vrho) * mu_rho + sum_skipnan(sigma2_e_it.^-1 .* s_lag_temp .* (s_temp - repeat(delta_rho_draw[i-1,:]', T) .* s_lag_temp)) )

        rho_draw[i] = rand(Normal(mean_rho_post, sqrt(vrho_post)))





        ###################################################
        ### BLOCK 3: draw q
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

        psi_alpha         = sum( z_alpha_draw[i-1,:] )
        psi_rho           = sum( z_rho_draw[i-1,:] )
        psi_sigma_u       = sum( z_sigma_u_draw[i-1,:] )
        psi_sigma_e       = sum( z_sigma_e_draw[i-1,:] )

        q_alpha_draw[i]   = rand( Beta(a + psi_alpha,   b + N - psi_alpha  ) )
        q_rho_draw[i]     = rand( Beta(a + psi_rho,     b + N - psi_rho    ) )
        q_sigma_u_draw[i] = rand( Beta(a + psi_sigma_u, b + N - psi_sigma_u) )
        q_sigma_e_draw[i] = rand( Beta(a + psi_sigma_e, b + N - psi_sigma_e) )





        ###################################################
        ### BLOCK 4: draw variance for δ^α, δ^ρ, δ^σ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

        ### V_δ^α 
        nu_vdelta_alpha_post  = nu_vdelta_alpha + psi_alpha
        Psi_vdelta_alpha_post = Psi_vdelta_alpha + make_symmetric(crossprod(delta_alpha_draw[i-1,:,z_alpha_draw[i-1,:] .== 1]'))

        vdelta_alpha_draw[i,:,:] = rand(InverseWishart(nu_vdelta_alpha_post, Psi_vdelta_alpha_post))


        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

        ### V_δ^ρ 
        nu_vdelta_rho_post  = nu_vdelta_rho + psi_rho
        tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_rho_draw[i-1,:] .== 1].^2)

        vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

        ### V_δ^σ_u (adaptive RWMH)
        # log posterior of ω (will be used in RWMH)
        delta_sigma_u_slab = delta_sigma_u_draw[i-1, z_sigma_u_draw[i-1,:] .== 1]

        log_post_omega_u(x) = psi_sigma_u*(1/x+2)*log(1/x+1) - psi_sigma_u*loggamma(1/x+2) - 
                (nu_vdelta_sigma_u/2+1)*log(x) - 1/x*(sum(log.(delta_sigma_u_slab)) + sum(delta_sigma_u_slab.^-1) + tau_vdelta_sigma_u/2 )

        # RWMH
        c_u_i = c_vdelta_sigma_u[i-1]

        RWMH_draw_u = rand(truncated(Normal(vdelta_sigma_u_draw[i-1], sqrt(c_u_i)), lower = 0))

        # calculate acceptance rate
        diff_log_post = log_post_omega_u(RWMH_draw_u) - log_post_omega_u(vdelta_sigma_u_draw[i-1])
        diff_log_CDF  = log(cdf(Normal(0,sqrt(c_u_i)), RWMH_draw_u)) - log(cdf(Normal(0,sqrt(c_u_i)), vdelta_sigma_u_draw[i-1]))

        prob_RWMH_u = min(1, exp(diff_log_post - diff_log_CDF))

        # accept or not?
        RWMH_accept_u = rand(Bernoulli(prob_RWMH_u))

        if RWMH_accept_u
            vdelta_sigma_u_draw[i] = RWMH_draw_u
            RWMH_u_accept_record[i] = 1
        else
            vdelta_sigma_u_draw[i] = vdelta_sigma_u_draw[i-1]
            RWMH_u_accept_record[i] = 0
        end

        # update random walk step size
        log_c_u = g( log(c_vdelta_sigma_u[i-1]) + i^(-0.55) * (prob_RWMH_u - opt_ar) )
        c_vdelta_sigma_u[i] = exp(log_c_u)




        ### V_δ^σ_e (adaptive RWMH)
        # log posterior of ω (will be used in RWMH)
        delta_sigma_e_slab = delta_sigma_e_draw[i-1, z_sigma_e_draw[i-1,:] .== 1]

        log_post_omega_e(x) = psi_sigma_e*(1/x+2)*log(1/x+1) - psi_sigma_e*loggamma(1/x+2) - 
                (nu_vdelta_sigma_e/2+1)*log(x) - 1/x*(sum(log.(delta_sigma_e_slab)) + sum(delta_sigma_e_slab.^-1) + tau_vdelta_sigma_e/2 )

        # RWMH
        c_e_i = c_vdelta_sigma_e[i-1]

        RWMH_draw_e = rand(truncated(Normal(vdelta_sigma_e_draw[i-1], sqrt(c_e_i)), lower = 0))

        # calculate acceptance rate
        diff_log_post = log_post_omega_e(RWMH_draw_e) - log_post_omega_e(vdelta_sigma_e_draw[i-1])
        diff_log_CDF  = log(cdf(Normal(0, sqrt(c_e_i)), RWMH_draw_e)) - log(cdf(Normal(0, sqrt(c_e_i)), vdelta_sigma_e_draw[i-1]))

        prob_RWMH_e = min(1, exp(diff_log_post - diff_log_CDF))

        # accept?
        RWMH_accept_e = rand(Bernoulli(prob_RWMH_e))

        if RWMH_accept_e
            vdelta_sigma_e_draw[i] = RWMH_draw_e
            RWMH_e_accept_record[i] = 1
        else
            vdelta_sigma_e_draw[i] = vdelta_sigma_e_draw[i-1]
            RWMH_e_accept_record[i] = 0
        end

        # update random walk step size
        log_c_e = g( log(c_vdelta_sigma_e[i-1]) + i^(-0.55) * (prob_RWMH_e - opt_ar) )
        c_vdelta_sigma_e[i] = exp(log_c_e)





        ###################################################
        ### BLOCK 5: draw (z,δ) for α and ρ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

        ### draw z_rho, delta_rho
        ### draw z_rho 			
        # posterior mean and variance of delta_rho_i
        post_var_delta_rho  = [ (vdelta_rho_draw[i]^-1 + sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii].^2) )^-1 for ii in 1:N ]

        post_mean_delta_rho = [ post_var_delta_rho[ii] * sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii] .* 
                            (s_temp[:,ii] - rho_draw[i] * s_lag_temp[:,ii])) for ii in 1:N ]

        K_rho = q_rho_draw[i] / (1-q_rho_draw[i]) * (vdelta_rho_draw[i] ./ post_var_delta_rho).^(-0.5) .*
                exp.( 0.5*post_mean_delta_rho.^2 ./ post_var_delta_rho )

        if sum(K_rho .== Inf) != 0
            Inf_pos = collect(1:N)[K_rho .== Inf]
            K_rho[Inf_pos] .= 10^8
        end

        # prob_rho = K_rho ./ (1 .+ K_rho) # probability of model 1

        #* KEY
        prob_rho = zeros(N,1)

        prob_rho_draw[i,:] = prob_rho

        z_rho_draw[i,:] = [rand(Bernoulli(x)) for x in prob_rho]

        ### draw δ_rho 
        zero_rho_pos = collect(1:N)[z_rho_draw[i,:] .== 0]

        delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

        if length(zero_rho_pos) != 0
            delta_rho_draw[i,zero_rho_pos] .= 0
        end
 


        ### draw z_alpha, delta_alpha
        # posterior mean and variance of beta (delta_alpha_i and s)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 6) )

        # draw mean of s0
        v_s0_post = ( inv(v_s0) + N*s0_var_draw[i-1]^-1 )^-1

        s0_prev = [s_draw[i-1, ii,loc_first_obs[ii]] for ii = 1:N] # last draw of s0

        mean_s0_post = v_s0_post * (s0_var_draw[i-1]^-1 * sum(s0_prev) + inv(v_s0) * mu_s0)
        s0_mean_draw[i] = rand(Normal(mean_s0_post, sqrt(v_s0_post)))

        # draw variance of s0, will be used in the calculation of variance of s
        nu_sigma_s0_post = nu_sigma_s0 + N
        tau_sigma_s0_post = tau_sigma_s0 + sum((s0_prev .- s0_mean_draw[i]).^2)
        s0_var_draw[i] = rand(InverseGamma(nu_sigma_s0_post/2, tau_sigma_s0_post/2))

        # AR coef
        rho_i = rho_draw[i] .+ delta_rho_draw[i,:]

        # covariance matrix of s
        var_s = zeros(T, N)
        for t = 1:T
            tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
            if t == 1
                for ii in 1:N
                    var_s[tt[ii],ii] = rho_i[ii]^2 * s0_var_draw[i] + sigma2_e_it[tt[ii],ii]
                end
                
            else
                i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
                for ii in i_update
                    var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
                end
            end
        end

        cov_s = zeros(T, T, N)
        for ii = 1:N
            for t1 = loc_first_obs[ii]:loc_last_obs[ii]
                for t2 = t1:loc_last_obs[ii]
                    cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                    cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
                end
            end
        end


        # prior covarance matrix for beta (delta-alpha + s)

        # fill in values in the last loc_first_obs[ii] + dimH element
        Sigma_beta_prior = zeros(dimH + T, dimH + T, N)
        # Sigma_beta_prior[:] .= NaN
        for ii = 1:N
            pos  = dimH + loc_first_obs[ii]
            pos2 = dimH + loc_last_obs[ii]
            Sigma_beta_prior[(pos-dimH):(pos-1), (pos-dimH):(pos-1), ii] = make_symmetric(vdelta_alpha_draw[i,:,:]) # delta-alpha
            Sigma_beta_prior[pos:pos2, pos:pos2, ii] = 
                make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) # s_i1:T
        end

        # design matrix (delta-alpha + s_i1 + ... + s_iT)
        X_i = zeros(T, dimH + T, N)
        X_i[:] .= NaN

        for ii = 1:N
            X_i[:,loc_first_obs[ii]:(loc_first_obs[ii]+dimH-1), ii] = H[:,ii,:]
            X_i[loc_first_obs[ii]:loc_last_obs[ii], (loc_first_obs[ii]+dimH):(loc_last_obs[ii]+dimH), ii] = I(T_stay[ii])
        end

        # X_i[17:end,17:end,ii]

        # posterior for beta (delta-alpha + s)
        post_var_beta  = [make_symmetric( inv( 
                            inv(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH, loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) .+ 
                            X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
                            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
                            X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii] ) ) for ii in 1:N]
        post_mean_beta = [post_var_beta[ii] * X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
                            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii], ii].^-1) * 
                            (y[loc_first_obs[ii]:loc_last_obs[ii], ii] - H[loc_first_obs[ii]:loc_last_obs[ii], ii,:] * alpha_draw[i,:]) for ii in 1:N]

        # posterior for s (X_i = I(T))
        post_var_s  = [make_symmetric( inv( inv(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) .+ 
                        Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii], ii].^-1) ) ) for ii in 1:N]
        post_mean_s = [post_var_s[ii] * Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
                        (y[loc_first_obs[ii]:loc_last_obs[ii], ii] - H[loc_first_obs[ii]:loc_last_obs[ii],ii,:] * alpha_draw[i,:]) for ii in 1:N]


        # Z-delta-alpha
        K_alpha = q_alpha_draw[i] / (1-q_alpha_draw[i]) * 
                            exp.([0.5*logdet(post_var_beta[ii]) - 
                            0.5*logdet(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH,loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) - 
                            0.5*logdet(post_var_s[ii]) + 0.5*logdet(cov_s[loc_first_obs[ii]:loc_last_obs[ii],loc_first_obs[ii]:loc_last_obs[ii],ii]) + 
                                0.5*post_mean_beta[ii]' * inv(post_var_beta[ii]) * post_mean_beta[ii] -
                                0.5*post_mean_s[ii]' * inv(post_var_s[ii]) * post_mean_s[ii] for ii in 1:N])

        if sum(K_alpha .== Inf) != 0
            Inf_pos = collect(1:N)[K_alpha .== Inf]
            K_alpha[Inf_pos] .= 10^8
        end

        # prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1

        #* KEY
        prob_alpha = zeros(N,1)

        prob_alpha_draw[i,:] = prob_alpha

        z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

        zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

        ### draw delta_alpha and s when z_alpha_i = 1
        delta_alpha_temp = zeros(dimH, N)
        s_temp = zeros(T, N)
        for ii in 1:N
            beta_temp = rand(MvNormal(post_mean_beta[ii], post_var_beta[ii]))

            delta_alpha_temp[:,ii] = beta_temp[1:dimH]
            s_temp[:,ii] = [NaN*ones(loc_first_obs[ii]-1); beta_temp[(dimH+1):end]; NaN*ones(T - loc_last_obs[ii])]
        end

        delta_alpha_draw[i,:,:] = delta_alpha_temp

        ### draw s when z_alpha_i = 0
        if length(zero_alpha_pos) != 0

            # delta-alpha are zero
            delta_alpha_draw[i, :, zero_alpha_pos] .= 0

            # posterior of beta (X_i = I(T))
            for ii in zero_alpha_pos
                s_draw_1T = rand(MvNormal(post_mean_s[ii], make_symmetric(post_var_s[ii])))
                s_temp[:, ii] = [NaN*ones(loc_first_obs[ii]-1); s_draw_1T; NaN*ones(T - loc_last_obs[ii])]
            end

        end

        # s0 (simultation smoother)
        s00 = s0_mean_draw[i]
        P00 = s0_var_draw[i]
        P10 = rho_i .* P00 .* rho_i + [sigma2_e_it[loc_first_obs[ii], ii] for ii in 1:N]
        
        s1_temp = [s_temp[loc_first_obs[ii],ii] for ii in 1:N]
        post_mean_s0 = s00 .+ P00 .* rho_i .* P10.^-1 .* (s1_temp - rho_i .* s0_mean_draw[i])
        post_var_s0 = P00 .- P00 .* rho_i .* P10.^-1 .* rho_i .* P00
        s0_temp = [rand(Normal(post_mean_s0[ii], sqrt(post_var_s0[ii]))) for ii in 1:N]
        
        # insert S_0 into S_1:T
        s_temp2 = [NaN*ones(1,N); s_temp]
        for ii in 1:N
            s_temp2[loc_first_obs[ii], ii] = s0_temp[ii]
        end
        s_draw[i,:,:] = s_temp2'

        # current values for state variables
        s_lag_temp = s_draw[i,:,1:end-1]' # T x N
        s_temp     = s_draw[i,:,2:end]' # T x N





        ###################################################
        ### BLOCK 5: draw (z,δ) for σ^2_e and σ^2_u
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

        
        ### draw z_sigma_u
        # parameters in posterior of δ^σ
        nu_delta_sigma_u_post  = 2*vdelta_sigma_u_draw[i]^(-1) + 4 .+ T_stay

        sum_y_sigma_u_sq = [sum_skipnan(sigma2_u_draw[i-1,:].^-1 .* (y[:,ii] - H[:,ii,:] * (alpha_draw[i,:] .+ delta_alpha_draw[i,:,ii]) - s_temp[:,ii]).^2) for ii in 1:N]
        tau_delta_sigma_u_post = 2*vdelta_sigma_u_draw[i]^(-1) + 2 .+ sum_y_sigma_u_sq

        # posterior odd
        exp_part = 0.5*sum_y_sigma_u_sq          
        Const    = loggamma.(nu_delta_sigma_u_post/2) .- loggamma(vdelta_sigma_u_draw[i]^(-1)+2) .+ 
                    (vdelta_sigma_u_draw[i]^(-1)+2) * log(vdelta_sigma_u_draw[i]^(-1)+1) .- 
                    (nu_delta_sigma_u_post/2) .* log.(tau_delta_sigma_u_post/2)

        K_sigma_u = q_sigma_u_draw[i] / (1-q_sigma_u_draw[i]) * exp.(Const .+ exp_part)

        if sum(K_sigma_u .== Inf) != 0
            Inf_pos = collect(1:N)[K_sigma_u .== Inf]
            K_sigma_u[Inf_pos] .= 10^8
        end

        prob_sigma_u = K_sigma_u ./ (1 .+ K_sigma_u) # probability of model 1
        prob_sigma_u_draw[i,:] = prob_sigma_u

        z_sigma_u_draw[i,:] = [rand(Bernoulli(x)) for x in prob_sigma_u]

        ### draw δ_sigma_u
        zero_sigma_u_pos = collect(1:N)[z_sigma_u_draw[i,:] .== 0]

        delta_sigma_u_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_u_post[ii]/2, tau_delta_sigma_u_post[ii]/2)) for ii in 1:N]

        if length(zero_sigma_u_pos) != 0
            delta_sigma_u_draw[i,zero_sigma_u_pos] .= 1
        end




        ### draw z_sigma_e
        # parameters in posterior of δ^σ_e
        nu_delta_sigma_e_post  = 2*vdelta_sigma_e_draw[i]^(-1) + 4 .+ T_stay

        sum_y_sigma_e_sq = [sum_skipnan(sigma2_e_draw[i-1,:].^-1 .* (s_temp[:,ii] - (rho_draw[i] + delta_rho_draw[i,ii]).* s_lag_temp[:,ii]).^2) for ii in 1:N]
        tau_delta_sigma_e_post = 2*vdelta_sigma_e_draw[i]^(-1) + 2 .+ sum_y_sigma_e_sq

        # posterior odd
        exp_part = 0.5*sum_y_sigma_e_sq
        Const    = loggamma.(nu_delta_sigma_e_post/2) .- loggamma(vdelta_sigma_e_draw[i]^(-1)+2) .+ 
                    (vdelta_sigma_e_draw[i]^(-1)+2) * log(vdelta_sigma_e_draw[i]^(-1)+1) .- 
                    (nu_delta_sigma_e_post/2) .* log.(tau_delta_sigma_e_post/2)

        K_sigma_e = q_sigma_e_draw[i] / (1-q_sigma_e_draw[i]) * exp.(Const .+ exp_part)

        if sum(K_sigma_e .== Inf) != 0
            Inf_pos = collect(1:N)[K_sigma_e .== Inf]
            K_sigma_e[Inf_pos] .= 10^8
        end

        prob_sigma_e = K_sigma_e ./ (1 .+ K_sigma_e)
        prob_sigma_e_draw[i,:] = prob_sigma_e

        z_sigma_e_draw[i,:] = [rand(Bernoulli(x)) for x in prob_sigma_e]

        ### draw δ_sigma_e
        zero_sigma_e_pos = collect(1:N)[z_sigma_e_draw[i,:] .== 0]

        delta_sigma_e_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_e_post[ii]/2, tau_delta_sigma_e_post[ii]/2)) for ii in 1:N]

        if length(zero_sigma_e_pos) != 0
            delta_sigma_e_draw[i,zero_sigma_e_pos] .= 1
        end





        ###################################################
        ### BLOCK 6: draw σ^2
        ###################################################

        ### draw σ_u^2(t) 
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 7) )
     
        nu_sigma_u_post  = nu_sigma_u .+ Nt
        tau_sigma_u_post = tau_sigma_u .+ [sum_skipnan(delta_sigma_u_draw[i,:].^-1 .* (y[tt,:] - s_temp[tt,:] - sum(H[tt,:,:] .*      
                            (delta_alpha_draw[i,:,:] + repeat(alpha_draw[i,:], outer = [1,N]))', dims = 2) ).^2 ) for tt in 1:T]

        sigma2_u_draw[i,:] = [rand(InverseGamma(nu_sigma_u_post[tt]/2, tau_sigma_u_post[tt]/2)) for tt in 1:T]

        ### draw σ_e^2(t) 
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 8) )
        nu_sigma_e_post  = nu_sigma_e .+ Nt
        tau_sigma_e_post = tau_sigma_e .+ [sum_skipnan(delta_sigma_e_draw[i,:].^-1 .* (s_temp[tt,:] - rho_i .* s_lag_temp[tt,:]).^2) for tt in 1:T]

        sigma2_e_draw[i,:] = [rand(InverseGamma(nu_sigma_e_post[tt]/2, tau_sigma_e_post[tt]/2)) for tt in 1:T]
    end

    # posterior draws
    alpha_draw_post           = alpha_draw[burnin:end,:]
    rho_draw_post             = rho_draw[burnin:end]
    delta_alpha_draw_post     = delta_alpha_draw[burnin:end,:,:]
    delta_rho_draw_post       = delta_rho_draw[burnin:end,:]
    delta_sigma_u_draw_post   = delta_sigma_u_draw[burnin:end,:]
    delta_sigma_e_draw_post   = delta_sigma_e_draw[burnin:end,:]
    vdelta_alpha_draw_post    = vdelta_alpha_draw[burnin:end,:,:]
    vdelta_rho_draw_post      = vdelta_rho_draw[burnin:end]
    vdelta_sigma_u_draw_post  = vdelta_sigma_u_draw[burnin:end,:]
    vdelta_sigma_e_draw_post  = vdelta_sigma_e_draw[burnin:end,:]
    sigma2_u_draw_post        = sigma2_u_draw[burnin:end,:]
    sigma2_e_draw_post        = sigma2_e_draw[burnin:end,:]
    z_alpha_draw_post         = z_alpha_draw[burnin:end,:]
    z_rho_draw_post           = z_rho_draw[burnin:end,:]
    z_sigma_u_draw_post       = z_sigma_u_draw[burnin:end,:]
    z_sigma_e_draw_post       = z_sigma_e_draw[burnin:end,:]
    prob_alpha_draw_post      = prob_alpha_draw[burnin:end,:]
    prob_rho_draw_post        = prob_rho_draw[burnin:end,:]
    prob_sigma_u_draw_post    = prob_sigma_u_draw[burnin:end,:]
    prob_sigma_e_draw_post    = prob_sigma_e_draw[burnin:end,:]
    q_alpha_draw_post         = q_alpha_draw[burnin:end]
    q_rho_draw_post           = q_rho_draw[burnin:end]
    q_sigma_u_draw_post       = q_sigma_u_draw[burnin:end]
    q_sigma_e_draw_post       = q_sigma_e_draw[burnin:end]
    s_draw_post               = s_draw[burnin:end,:,:]
    s0_mean_draw_post         = s0_mean_draw[burnin:end]
    s0_var_draw_post          = s0_var_draw[burnin:end]
   

    # posterior mean
    alpha_hat          = mean( alpha_draw_post, dims = 1)'
    rho_hat            = mean( rho_draw_post )
    delta_alpha_hat    = mean( delta_alpha_draw_post, dims = 1)[1,:,:]'
    delta_rho_hat      = mean( delta_rho_draw_post, dims = 1)'
    delta_sigma_u_hat  = mean( delta_sigma_u_draw_post, dims = 1)'
    delta_sigma_e_hat  = mean( delta_sigma_e_draw_post, dims = 1)'
    vdelta_alpha_hat   = mean( vdelta_alpha_draw_post, dims = 1)[1,:,:]'
    vdelta_rho_hat     = mean( vdelta_rho_draw_post )
    vdelta_sigma_u_hat = mean( vdelta_sigma_u_draw_post )
    vdelta_sigma_e_hat = mean( vdelta_sigma_e_draw_post )
    sigma2_u_hat       = mean( sigma2_u_draw_post, dims = 1)'
    sigma2_e_hat       = mean( sigma2_e_draw_post, dims = 1)'
    z_alpha_hat        = mean( z_alpha_draw_post, dims = 1)'
    z_rho_hat          = mean( z_rho_draw_post, dims = 1)'
    z_sigma_u_hat      = mean( z_sigma_u_draw_post, dims = 1)'
    z_sigma_e_hat      = mean( z_sigma_e_draw_post, dims = 1)'
    prob_alpha_hat     = mean( prob_alpha_draw_post, dims = 1)'
    prob_rho_hat       = mean( prob_rho_draw_post, dims = 1)'
    prob_sigma_u_hat   = mean( prob_sigma_u_draw_post, dims = 1)'
    prob_sigma_e_hat   = mean( prob_sigma_e_draw_post, dims = 1)'
    q_alpha_hat        = mean( q_alpha_draw_post )
    q_rho_hat          = mean( q_rho_draw_post )
    q_sigma_u_hat      = mean( q_sigma_u_draw_post )
    q_sigma_e_hat      = mean( q_sigma_e_draw_post )
    s0_mean_hat        = mean( s0_mean_draw_post )
    s0_var_hat         = mean( s0_var_draw_post )

    s_hat = zeros(T+1, N)
    for ii in 1:N
        for tt in 1:T+1
            s_hat[tt, ii] = mean(skipnan(s_draw_post[:,ii,tt]))
        end
    end

    RWMH_u_accept_hat = mean(RWMH_u_accept_record[burnin:end])
    RWMH_e_accept_hat = mean(RWMH_e_accept_record[burnin:end])

    post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_u_hat = sigma2_u_hat, sigma2_e_hat = sigma2_e_hat,
                 delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat, delta_sigma_u_hat = delta_sigma_u_hat, delta_sigma_e_hat = delta_sigma_e_hat,
                 vdelta_alpha_hat = vdelta_alpha_hat, vdelta_rho_hat = vdelta_rho_hat, vdelta_sigma_u_hat = vdelta_sigma_u_hat, vdelta_sigma_e_hat = vdelta_sigma_e_hat,
                 z_alpha_hat = z_alpha_hat, z_rho_hat = z_rho_hat, z_sigma_u_hat = z_sigma_u_hat, z_sigma_e_hat = z_sigma_e_hat,
                 prob_alpha_hat = prob_alpha_hat, prob_rho_hat = prob_rho_hat, prob_sigma_u_hat = prob_sigma_u_hat, prob_sigma_e_hat = prob_sigma_e_hat,
                 q_alpha_hat = q_alpha_hat, q_rho_hat = q_rho_hat, q_sigma_u_hat = q_sigma_u_hat, q_sigma_e_hat = q_sigma_e_hat,
                 s_hat = s_hat, s0_var_hat = s0_var_hat, s0_mean_hat = s0_mean_hat,
                 RWMH_u_accept_hat = RWMH_u_accept_hat, RWMH_e_accept_hat = RWMH_e_accept_hat)
    
    post_draw = (alpha_draw          = alpha_draw_post,
                rho_draw             = rho_draw_post,
                delta_alpha_draw     = delta_alpha_draw_post,
                delta_rho_draw       = delta_rho_draw_post,
                delta_sigma_u_draw   = delta_sigma_u_draw_post,
                delta_sigma_e_draw   = delta_sigma_e_draw_post,
                vdelta_alpha_draw    = vdelta_alpha_draw_post,
                vdelta_rho_draw      = vdelta_rho_draw_post,
                vdelta_sigma_u_draw  = vdelta_sigma_u_draw_post,
                vdelta_sigma_e_draw  = vdelta_sigma_e_draw_post,
                sigma2_u_draw        = sigma2_u_draw_post,
                sigma2_e_draw        = sigma2_e_draw_post,
                z_alpha_draw         = z_alpha_draw_post,
                z_rho_draw           = z_rho_draw_post,
                z_sigma_u_draw       = z_sigma_u_draw_post,
                z_sigma_e_draw       = z_sigma_e_draw_post,
                prob_alpha_draw      = prob_alpha_draw_post,
                prob_rho_draw        = prob_rho_draw_post,
                prob_sigma_u_draw    = prob_sigma_u_draw_post,
                prob_sigma_e_draw    = prob_sigma_e_draw_post,
                q_alpha_draw         = q_alpha_draw_post,
                q_rho_draw           = q_rho_draw_post,
                q_sigma_u_draw       = q_sigma_u_draw_post,
                q_sigma_e_draw       = q_sigma_e_draw_post,
                s_draw               = s_draw_post,
                s0_mean_draw         = s0_mean_draw_post,
                s0_var_draw          = s0_var_draw_post)

    return post_mean, post_draw

end


# SS-HIP-Hetero (direct sample s and delta-alpha), with alpha0 and alpha1, fix q-alpha and q-rho to 1 --> M2(HIP)
function est_M2_HIP_unb(y_all, H, lambda, opt_ar, len_MCMC, id_simul)

    #* This version directly draws s together with δ_α's.
    #* This verison is designed for unbalanced panel.

    #* this version force q-alpha and q-rho equal to 1

    # len_MCMC = Int(50)
    # id_simul = seed
    # y = y_all

    len_MCMC = Int(len_MCMC)
    burnin   = Int(floor(0.5*len_MCMC))+1
    # burnin = 1

    y = y_all[1:end,:]

    T, N, dimH = size(H)
    
    # characters of unbalanced panel
    loc_nan = (y .=== NaN)
    loc_first_obs = mapslices(find_first_nonNA, y, dims = 1)[1,:];
    loc_last_obs  = mapslices(find_last_nonNA, y, dims = 1)[1,:]

    # T_stay = T .- sum(isnan.(y), dims = 1)[1,:]
    T_stay = loc_last_obs .- loc_first_obs .+ 1
    Nt = N .- sum(isnan.(y), dims = 2)[:,1]

    # unload HP
    mu_alpha, valpha,
    mu_rho, vrho, 
    nu_vdelta_alpha, Psi_vdelta_alpha, 
    nu_vdelta_rho, tau_vdelta_rho,
    nu_vdelta_sigma_u, tau_vdelta_sigma_u,
    nu_vdelta_sigma_e, tau_vdelta_sigma_e,
    nu_sigma_u, tau_sigma_u, nu_sigma_e, tau_sigma_e, 
    a, b, mu_s0, v_s0, nu_sigma_s0, tau_sigma_s0 = lambda

    # useful subfunctions
    crossprod(x) = x' * x
    g(x) = min(abs(x), 10) * sign(x) # helper function in adapative RWMH
    sum_skipnan(x) = sum(skipnan(x))

    q_alpha_draw        = zeros(len_MCMC+1)
    q_rho_draw          = zeros(len_MCMC+1)
    q_sigma_u_draw      = zeros(len_MCMC+1)
    q_sigma_e_draw      = zeros(len_MCMC+1)
    alpha_draw          = zeros(len_MCMC+1, dimH)
    rho_draw            = zeros(len_MCMC+1)
    vdelta_alpha_draw   = zeros(len_MCMC+1, dimH, dimH)
    vdelta_rho_draw     = zeros(len_MCMC+1)
    vdelta_sigma_u_draw = zeros(len_MCMC+1)
    vdelta_sigma_e_draw = zeros(len_MCMC+1)
    delta_alpha_draw    = zeros(len_MCMC+1, dimH, N)
    delta_rho_draw      = zeros(len_MCMC+1, N)
    delta_sigma_u_draw  = zeros(len_MCMC+1, N)
    delta_sigma_e_draw  = zeros(len_MCMC+1, N) 
    z_alpha_draw        = zeros(len_MCMC+1, N)
    z_rho_draw          = zeros(len_MCMC+1, N)
    z_sigma_u_draw      = zeros(len_MCMC+1, N)
    z_sigma_e_draw      = zeros(len_MCMC+1, N)
    sigma2_u_draw       = zeros(len_MCMC+1, T)
    sigma2_e_draw       = zeros(len_MCMC+1, T)
    s_draw              = zeros(len_MCMC+1, N, T+1)
    s0_mean_draw        = zeros(len_MCMC+1)
    s0_var_draw         = zeros(len_MCMC+1)

    prob_alpha_draw     = zeros(len_MCMC+1, N)
    prob_rho_draw       = zeros(len_MCMC+1, N)
    prob_sigma_u_draw   = zeros(len_MCMC+1, N)
    prob_sigma_e_draw   = zeros(len_MCMC+1, N)

    # RWMH
    c_vdelta_sigma_u = zeros(len_MCMC+1) # random walk step size
    c_vdelta_sigma_e = zeros(len_MCMC+1)
    RWMH_u_accept_record = zeros(len_MCMC+1) # record acceptance status
    RWMH_e_accept_record = zeros(len_MCMC+1)

    ### initialize parameters
    # α
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    alpha_draw[1,:] = mu_alpha

    # ρ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    rho_draw[1] = mu_rho

    # q
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
    q_alpha_draw[1]   = mean(Beta(a,b))
    q_rho_draw[1]     = mean(Beta(a,b))
    q_sigma_u_draw[1] = mean(Beta(a,b))
    q_sigma_e_draw[1] = mean(Beta(a,b))

    # v_δ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )
    vdelta_alpha_draw[1,:,:] = mean(InverseWishart(nu_vdelta_alpha, Psi_vdelta_alpha))
    vdelta_rho_draw[1]       = mean(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))
    vdelta_sigma_u_draw[1]   = mean(InverseGamma(nu_vdelta_sigma_u/2, tau_vdelta_sigma_u/2))
    vdelta_sigma_e_draw[1]   = mean(InverseGamma(nu_vdelta_sigma_e/2, tau_vdelta_sigma_e/2))

    # (z,δ)
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

    z_alpha_draw[1,:]   = rand(Bernoulli(q_alpha_draw[1]), N)
    z_rho_draw[1,:]     = rand(Bernoulli(q_rho_draw[1]), N)
    z_sigma_u_draw[1,:] = rand(Bernoulli(q_sigma_u_draw[1]), N)
    z_sigma_e_draw[1,:] = rand(Bernoulli(q_sigma_e_draw[1]), N)

    zero_pos_alpha    = collect(1:N)[z_alpha_draw[1,:] .== 0]
    zero_pos_rho      = collect(1:N)[z_rho_draw[1,:] .== 0]
    zero_pos_sigma_u  = collect(1:N)[z_sigma_u_draw[1,:] .== 0]
    zero_pos_sigma_e  = collect(1:N)[z_sigma_e_draw[1,:] .== 0]

    delta_rho_draw[1,:] = rand(Normal(0, sqrt(vdelta_rho_draw[1])), N)
    delta_rho_draw[1,:] = delta_rho_draw[1,:] .* abs.(delta_rho_draw[1,:] .< 0.2)
    delta_rho_draw[1,zero_pos_rho] .= 0

    delta_sigma_u_draw[1,:] = rand(InverseGamma(1/vdelta_sigma_u_draw[1]+2, 1/vdelta_sigma_u_draw[1]+1), N)
    delta_sigma_u_draw[1,zero_pos_sigma_u] .= 1

    delta_sigma_e_draw[1,:] = rand(InverseGamma(1/vdelta_sigma_e_draw[1]+2, 1/vdelta_sigma_e_draw[1]+1), N)
    delta_sigma_e_draw[1,zero_pos_sigma_e] .= 1

    # σ^2
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    sigma2_u_draw[1,:] = rand(InverseGamma(nu_sigma_u/2, tau_sigma_u/2), T)
    sigma2_e_draw[1,:] = rand(InverseGamma(nu_sigma_e/2, tau_sigma_e/2), T)

    sigma2_u_it = kron(sigma2_u_draw[1,:], delta_sigma_u_draw[1,:]') # T x N
    sigma2_e_it = kron(sigma2_e_draw[1,:], delta_sigma_e_draw[1,:]') # T x N

    sigma2_u_it[loc_nan] .= NaN
    sigma2_e_it[loc_nan] .= NaN

    # s0
    s0_mean_draw[1] = mean(Normal(mu_s0, sqrt(v_s0)))
    s0_var_draw[1]  = mean(InverseGamma(nu_sigma_s0/2, tau_sigma_s0/2))
    s0_temp = [rand(Normal(s0_mean_draw[1], sqrt(s0_var_draw[1]))) for ii in 1:N]

    # AR coef
    rho_i = rho_draw[1] .+ delta_rho_draw[1,:]

    # covariance matrix 
    var_s = zeros(T, N)
    for t = 1:T
        tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
        if t == 1
            for ii in 1:N
                var_s[tt[ii],ii] = rho_i[ii]^2 * s0_var_draw[1] + sigma2_e_it[tt[ii],ii]
            end
            
        else
            i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
            for ii in i_update
                var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
            end
        end
    end

    cov_s = zeros(T, T, N)
    for ii = 1:N
        for t1 = loc_first_obs[ii]:loc_last_obs[ii]
            for t2 = t1:loc_last_obs[ii]
                cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
            end
        end
    end

    s_temp = zeros(N, T+1) # +1 for initial value

    for ii = 1:N
        nobs_ii = T_stay[ii]

        s_temp[ii, loc_first_obs[ii]] = s0_temp[ii]
        s_temp[ii, loc_first_obs[ii]+1:loc_last_obs[ii]+1] = rand(MvNormal(vec(zeros(nobs_ii,1)), 
                   make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii])))
    end
    s_temp[s_temp .== 0] .= NaN

    s_draw[1,:,:] = s_temp

    # c
    c_vdelta_sigma_u[1] = 0.5
    c_vdelta_sigma_e[1] = 0.5

    for i = ProgressBar(2:len_MCMC+1)

        # i = 2
        # println("iter = $i")

        # current values for state variables
        s_lag_temp = s_draw[i-1,:,1:end-1]' # T x N
        s_temp     = s_draw[i-1,:,2:end]'

        # variance of errors
        sigma2_u_it = kron(sigma2_u_draw[i-1,:], delta_sigma_u_draw[i-1,:]') # T x N
        sigma2_e_it = kron(sigma2_e_draw[i-1,:], delta_sigma_e_draw[i-1,:]') # T x N

        sigma2_u_it[loc_nan] .= NaN
        sigma2_e_it[loc_nan] .= NaN

        ###################################################
        ### BLOCK 1: draw α
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 0) )

        sum_in_valpha = zeros(dimH, dimH)
        for ii in 1:N
            for tt in 1:T
                if !any(isnan.(H[tt,ii,:]))
                    sum_in_valpha = sum_in_valpha + sigma2_u_it[tt,ii]^-1 * H[tt,ii,:] * H[tt,ii,:]'
                end
            end
        end
        
        sum_in_mu_alpha = zeros(dimH, 1)
        for ii in 1:N
            for tt in 1:T
                if !any(isnan.(H[tt,ii,:]))
                    sum_in_mu_alpha = sum_in_mu_alpha + sigma2_u_it[tt,ii]^-1 * H[tt,ii,:] * 
                                        (y[tt,ii] - H[tt,ii,:]' * delta_alpha_draw[i-1,:,ii] - s_temp[tt,ii])
                end
            end
        end

        valpha_post = make_symmetric(( inv(valpha) + sum_in_valpha )^-1)
        mean_alpha_post = valpha_post * ( inv(valpha) * mu_alpha + sum_in_mu_alpha)

        alpha_draw[i,:] = rand(MvNormal(mean_alpha_post[:,1], valpha_post))

        



        ###################################################
        ### BLOCK 2: draw ρ
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

        vrho_post = ( inv(vrho) + sum_skipnan(sigma2_e_it.^-1 .* s_lag_temp.^2) )^-1
        mean_rho_post = vrho_post * ( inv(vrho) * mu_rho + sum_skipnan(sigma2_e_it.^-1 .* s_lag_temp .* (s_temp - repeat(delta_rho_draw[i-1,:]', T) .* s_lag_temp)) )

        rho_draw[i] = rand(Normal(mean_rho_post, sqrt(vrho_post)))





        ###################################################
        ### BLOCK 3: draw q
        ###################################################
        
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

        psi_alpha         = sum( z_alpha_draw[i-1,:] )
        psi_rho           = sum( z_rho_draw[i-1,:] )
        psi_sigma_u       = sum( z_sigma_u_draw[i-1,:] )
        psi_sigma_e       = sum( z_sigma_e_draw[i-1,:] )

        q_alpha_draw[i]   = rand( Beta(a + psi_alpha,   b + N - psi_alpha  ) )
        q_rho_draw[i]     = rand( Beta(a + psi_rho,     b + N - psi_rho    ) )
        q_sigma_u_draw[i] = rand( Beta(a + psi_sigma_u, b + N - psi_sigma_u) )
        q_sigma_e_draw[i] = rand( Beta(a + psi_sigma_e, b + N - psi_sigma_e) )





        ###################################################
        ### BLOCK 4: draw variance for δ^α, δ^ρ, δ^σ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

        ### V_δ^α 
        nu_vdelta_alpha_post  = nu_vdelta_alpha + psi_alpha
        Psi_vdelta_alpha_post = Psi_vdelta_alpha + make_symmetric(crossprod(delta_alpha_draw[i-1,:,z_alpha_draw[i-1,:] .== 1]'))

        vdelta_alpha_draw[i,:,:] = rand(InverseWishart(nu_vdelta_alpha_post, Psi_vdelta_alpha_post))


        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

        ### V_δ^ρ 
        nu_vdelta_rho_post  = nu_vdelta_rho + psi_rho
        tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_rho_draw[i-1,:] .== 1].^2)

        vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

        ### V_δ^σ_u (adaptive RWMH)
        # log posterior of ω (will be used in RWMH)
        delta_sigma_u_slab = delta_sigma_u_draw[i-1, z_sigma_u_draw[i-1,:] .== 1]

        log_post_omega_u(x) = psi_sigma_u*(1/x+2)*log(1/x+1) - psi_sigma_u*loggamma(1/x+2) - 
                (nu_vdelta_sigma_u/2+1)*log(x) - 1/x*(sum(log.(delta_sigma_u_slab)) + sum(delta_sigma_u_slab.^-1) + tau_vdelta_sigma_u/2 )

        # RWMH
        c_u_i = c_vdelta_sigma_u[i-1]

        RWMH_draw_u = rand(truncated(Normal(vdelta_sigma_u_draw[i-1], sqrt(c_u_i)), lower = 0))

        # calculate acceptance rate
        diff_log_post = log_post_omega_u(RWMH_draw_u) - log_post_omega_u(vdelta_sigma_u_draw[i-1])
        diff_log_CDF  = log(cdf(Normal(0,sqrt(c_u_i)), RWMH_draw_u)) - log(cdf(Normal(0,sqrt(c_u_i)), vdelta_sigma_u_draw[i-1]))

        prob_RWMH_u = min(1, exp(diff_log_post - diff_log_CDF))

        # accept or not?
        RWMH_accept_u = rand(Bernoulli(prob_RWMH_u))

        if RWMH_accept_u
            vdelta_sigma_u_draw[i] = RWMH_draw_u
            RWMH_u_accept_record[i] = 1
        else
            vdelta_sigma_u_draw[i] = vdelta_sigma_u_draw[i-1]
            RWMH_u_accept_record[i] = 0
        end

        # update random walk step size
        log_c_u = g( log(c_vdelta_sigma_u[i-1]) + i^(-0.55) * (prob_RWMH_u - opt_ar) )
        c_vdelta_sigma_u[i] = exp(log_c_u)





        ### V_δ^σ_e (adaptive RWMH)
        # log posterior of ω (will be used in RWMH)
        delta_sigma_e_slab = delta_sigma_e_draw[i-1, z_sigma_e_draw[i-1,:] .== 1]

        log_post_omega_e(x) = psi_sigma_e*(1/x+2)*log(1/x+1) - psi_sigma_e*loggamma(1/x+2) - 
                (nu_vdelta_sigma_e/2+1)*log(x) - 1/x*(sum(log.(delta_sigma_e_slab)) + sum(delta_sigma_e_slab.^-1) + tau_vdelta_sigma_e/2 )

        # RWMH
        c_e_i = c_vdelta_sigma_e[i-1]

        RWMH_draw_e = rand(truncated(Normal(vdelta_sigma_e_draw[i-1], sqrt(c_e_i)), lower = 0))

        # calculate acceptance rate
        diff_log_post = log_post_omega_e(RWMH_draw_e) - log_post_omega_e(vdelta_sigma_e_draw[i-1])
        diff_log_CDF  = log(cdf(Normal(0, sqrt(c_e_i)), RWMH_draw_e)) - log(cdf(Normal(0, sqrt(c_e_i)), vdelta_sigma_e_draw[i-1]))

        prob_RWMH_e = min(1, exp(diff_log_post - diff_log_CDF))

        # accept?
        RWMH_accept_e = rand(Bernoulli(prob_RWMH_e))

        if RWMH_accept_e
            vdelta_sigma_e_draw[i] = RWMH_draw_e
            RWMH_e_accept_record[i] = 1
        else
            vdelta_sigma_e_draw[i] = vdelta_sigma_e_draw[i-1]
            RWMH_e_accept_record[i] = 0
        end

        # update random walk step size
        log_c_e = g( log(c_vdelta_sigma_e[i-1]) + i^(-0.55) * (prob_RWMH_e - opt_ar) )
        c_vdelta_sigma_e[i] = exp(log_c_e)





        ###################################################
        ### BLOCK 5: draw (z,δ) for α and ρ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

        ### draw z_rho, delta_rho
        ### draw z_rho 			
        # posterior mean and variance of delta_rho_i
        post_var_delta_rho  = [ (vdelta_rho_draw[i]^-1 + sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii].^2) )^-1 for ii in 1:N ]

        post_mean_delta_rho = [ post_var_delta_rho[ii] * sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii] .* 
                            (s_temp[:,ii] - rho_draw[i] * s_lag_temp[:,ii])) for ii in 1:N ]

        K_rho = q_rho_draw[i] / (1-q_rho_draw[i]) * (vdelta_rho_draw[i] ./ post_var_delta_rho).^(-0.5) .*
                exp.( 0.5*post_mean_delta_rho.^2 ./ post_var_delta_rho )

        if sum(K_rho .== Inf) != 0
            Inf_pos = collect(1:N)[K_rho .== Inf]
            K_rho[Inf_pos] .= 10^8
        end

        # prob_rho = K_rho ./ (1 .+ K_rho) # probability of model 1

        #* KEY
        prob_rho = ones(N,1)

        prob_rho_draw[i,:] = prob_rho

        z_rho_draw[i,:] = [rand(Bernoulli(x)) for x in prob_rho]

        ### draw δ_rho 
        zero_rho_pos = collect(1:N)[z_rho_draw[i,:] .== 0]

        delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

        if length(zero_rho_pos) != 0
            delta_rho_draw[i,zero_rho_pos] .= 0
        end


        ### draw z_alpha, delta_alpha
        # posterior mean and variance of beta (delta_alpha_i and s)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 6) )

        # draw mean of s0
        v_s0_post = ( inv(v_s0) + N*s0_var_draw[i-1]^-1 )^-1

        s0_prev = [s_draw[i-1, ii,loc_first_obs[ii]] for ii = 1:N] # last draw of s0

        mean_s0_post = v_s0_post * (s0_var_draw[i-1]^-1 * sum(s0_prev) + inv(v_s0) * mu_s0)
        s0_mean_draw[i] = rand(Normal(mean_s0_post, sqrt(v_s0_post)))

        # draw variance of s0, will be used in the calculation of variance of s
        nu_sigma_s0_post = nu_sigma_s0 + N
        tau_sigma_s0_post = tau_sigma_s0 + sum((s0_prev .- s0_mean_draw[i]).^2)
        s0_var_draw[i] = rand(InverseGamma(nu_sigma_s0_post/2, tau_sigma_s0_post/2))

        # AR coef
        rho_i = rho_draw[i] .+ delta_rho_draw[i,:]

        # covariance matrix of s
        var_s = zeros(T, N)
        for t = 1:T
            tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
            if t == 1
                for ii in 1:N
                    var_s[tt[ii],ii] = rho_i[ii]^2 * s0_var_draw[i] + sigma2_e_it[tt[ii],ii]
                end
                
            else
                i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
                for ii in i_update
                    var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
                end
            end
        end

        cov_s = zeros(T, T, N)
        for ii = 1:N
            for t1 = loc_first_obs[ii]:loc_last_obs[ii]
                for t2 = t1:loc_last_obs[ii]
                    cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                    cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
                end
            end
        end


        # prior covarance matrix for beta (delta-alpha + s)

        # fill in values in the last loc_first_obs[ii] + dimH element
        Sigma_beta_prior = zeros(dimH + T, dimH + T, N)
        # Sigma_beta_prior[:] .= NaN
        for ii = 1:N
            pos  = dimH + loc_first_obs[ii]
            pos2 = dimH + loc_last_obs[ii]
            Sigma_beta_prior[(pos-dimH):(pos-1), (pos-dimH):(pos-1), ii] = make_symmetric(vdelta_alpha_draw[i,:,:]) # delta-alpha
            Sigma_beta_prior[pos:pos2, pos:pos2, ii] = 
                make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) # s_i1:T
        end

        # design matrix (delta-alpha + s_i1 + ... + s_iT)
        X_i = zeros(T, dimH + T, N)
        X_i[:] .= NaN

        for ii = 1:N
            X_i[:,loc_first_obs[ii]:(loc_first_obs[ii]+dimH-1), ii] = H[:,ii,:]
            X_i[loc_first_obs[ii]:loc_last_obs[ii], (loc_first_obs[ii]+dimH):(loc_last_obs[ii]+dimH), ii] = I(T_stay[ii])
        end

        # X_i[17:end,17:end,ii]

        # posterior for beta (delta-alpha + s)
        post_var_beta  = [make_symmetric( inv( 
                            inv(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH, loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) .+ 
                            X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
                            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
                            X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii] ) ) for ii in 1:N]
        post_mean_beta = [post_var_beta[ii] * X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
                            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii], ii].^-1) * 
                            (y[loc_first_obs[ii]:loc_last_obs[ii], ii] - H[loc_first_obs[ii]:loc_last_obs[ii], ii,:] * alpha_draw[i,:]) for ii in 1:N]

        # posterior for s (X_i = I(T))
        post_var_s  = [make_symmetric( inv( inv(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) .+ 
                        Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii], ii].^-1) ) ) for ii in 1:N]
        post_mean_s = [post_var_s[ii] * Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
                        (y[loc_first_obs[ii]:loc_last_obs[ii], ii] - H[loc_first_obs[ii]:loc_last_obs[ii],ii,:] * alpha_draw[i,:]) for ii in 1:N]


        # Z-delta-alpha
        K_alpha = q_alpha_draw[i] / (1-q_alpha_draw[i]) * 
                            exp.([0.5*logdet(post_var_beta[ii]) - 
                            0.5*logdet(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH,loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) - 
                            0.5*logdet(post_var_s[ii]) + 0.5*logdet(cov_s[loc_first_obs[ii]:loc_last_obs[ii],loc_first_obs[ii]:loc_last_obs[ii],ii]) + 
                                0.5*post_mean_beta[ii]' * inv(post_var_beta[ii]) * post_mean_beta[ii] -
                                0.5*post_mean_s[ii]' * inv(post_var_s[ii]) * post_mean_s[ii] for ii in 1:N])

        if sum(K_alpha .== Inf) != 0
            Inf_pos = collect(1:N)[K_alpha .== Inf]
            K_alpha[Inf_pos] .= 10^8
        end

        # prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1

        #* KEY
        prob_alpha = ones(N,1)

        prob_alpha_draw[i,:] = prob_alpha

        z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

        zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

        ### draw delta_alpha and s when z_alpha_i = 1
        delta_alpha_temp = zeros(dimH, N)
        s_temp = zeros(T, N)
        for ii in 1:N
            beta_temp = rand(MvNormal(post_mean_beta[ii], post_var_beta[ii]))

            delta_alpha_temp[:,ii] = beta_temp[1:dimH]
            s_temp[:,ii] = [NaN*ones(loc_first_obs[ii]-1); beta_temp[(dimH+1):end]; NaN*ones(T - loc_last_obs[ii])]
        end

        delta_alpha_draw[i,:,:] = delta_alpha_temp

        ### draw s when z_alpha_i = 0
        if length(zero_alpha_pos) != 0

            # delta-alpha are zero
            delta_alpha_draw[i, :, zero_alpha_pos] .= 0

            # posterior of beta (X_i = I(T))
            for ii in zero_alpha_pos
                s_draw_1T = rand(MvNormal(post_mean_s[ii], make_symmetric(post_var_s[ii])))
                s_temp[:, ii] = [NaN*ones(loc_first_obs[ii]-1); s_draw_1T; NaN*ones(T - loc_last_obs[ii])]
            end

        end

        # s0 (simultation smoother)
        s00 = s0_mean_draw[i]
        P00 = s0_var_draw[i]
        P10 = rho_i .* P00 .* rho_i + [sigma2_e_it[loc_first_obs[ii], ii] for ii in 1:N]
        
        s1_temp = [s_temp[loc_first_obs[ii],ii] for ii in 1:N]
        post_mean_s0 = s00 .+ P00 .* rho_i .* P10.^-1 .* (s1_temp - rho_i .* s0_mean_draw[i])
        post_var_s0 = P00 .- P00 .* rho_i .* P10.^-1 .* rho_i .* P00
        s0_temp = [rand(Normal(post_mean_s0[ii], sqrt(post_var_s0[ii]))) for ii in 1:N]
        
        # insert S_0 into S_1:T
        s_temp2 = [NaN*ones(1,N); s_temp]
        for ii in 1:N
            s_temp2[loc_first_obs[ii], ii] = s0_temp[ii]
        end
        s_draw[i,:,:] = s_temp2'

        # current values for state variables
        s_lag_temp = s_draw[i,:,1:end-1]' # T x N
        s_temp     = s_draw[i,:,2:end]' # T x N





        ###################################################
        ### BLOCK 5: draw (z,δ) for σ^2_e and σ^2_u
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

        
        ### draw z_sigma_u
        # parameters in posterior of δ^σ
        nu_delta_sigma_u_post  = 2*vdelta_sigma_u_draw[i]^(-1) + 4 .+ T_stay

        sum_y_sigma_u_sq = [sum_skipnan(sigma2_u_draw[i-1,:].^-1 .* (y[:,ii] - H[:,ii,:] * (alpha_draw[i,:] .+ delta_alpha_draw[i,:,ii]) - s_temp[:,ii]).^2) for ii in 1:N]
        tau_delta_sigma_u_post = 2*vdelta_sigma_u_draw[i]^(-1) + 2 .+ sum_y_sigma_u_sq

        # posterior odd
        exp_part = 0.5*sum_y_sigma_u_sq          
        Const    = loggamma.(nu_delta_sigma_u_post/2) .- loggamma(vdelta_sigma_u_draw[i]^(-1)+2) .+ 
                    (vdelta_sigma_u_draw[i]^(-1)+2) * log(vdelta_sigma_u_draw[i]^(-1)+1) .- 
                    (nu_delta_sigma_u_post/2) .* log.(tau_delta_sigma_u_post/2)

        K_sigma_u = q_sigma_u_draw[i] / (1-q_sigma_u_draw[i]) * exp.(Const .+ exp_part)

        if sum(K_sigma_u .== Inf) != 0
            Inf_pos = collect(1:N)[K_sigma_u .== Inf]
            K_sigma_u[Inf_pos] .= 10^8
        end

        prob_sigma_u = K_sigma_u ./ (1 .+ K_sigma_u) # probability of model 1
        prob_sigma_u_draw[i,:] = prob_sigma_u

        z_sigma_u_draw[i,:] = [rand(Bernoulli(x)) for x in prob_sigma_u]

        ### draw δ_sigma_u
        zero_sigma_u_pos = collect(1:N)[z_sigma_u_draw[i,:] .== 0]

        delta_sigma_u_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_u_post[ii]/2, tau_delta_sigma_u_post[ii]/2)) for ii in 1:N]

        if length(zero_sigma_u_pos) != 0
            delta_sigma_u_draw[i,zero_sigma_u_pos] .= 1
        end




        ### draw z_sigma_e
        # parameters in posterior of δ^σ_e
        nu_delta_sigma_e_post  = 2*vdelta_sigma_e_draw[i]^(-1) + 4 .+ T_stay

        sum_y_sigma_e_sq = [sum_skipnan(sigma2_e_draw[i-1,:].^-1 .* (s_temp[:,ii] - (rho_draw[i] + delta_rho_draw[i,ii]).* s_lag_temp[:,ii]).^2) for ii in 1:N]
        tau_delta_sigma_e_post = 2*vdelta_sigma_e_draw[i]^(-1) + 2 .+ sum_y_sigma_e_sq

        # posterior odd
        exp_part = 0.5*sum_y_sigma_e_sq
        Const    = loggamma.(nu_delta_sigma_e_post/2) .- loggamma(vdelta_sigma_e_draw[i]^(-1)+2) .+ 
                    (vdelta_sigma_e_draw[i]^(-1)+2) * log(vdelta_sigma_e_draw[i]^(-1)+1) .- 
                    (nu_delta_sigma_e_post/2) .* log.(tau_delta_sigma_e_post/2)

        K_sigma_e = q_sigma_e_draw[i] / (1-q_sigma_e_draw[i]) * exp.(Const .+ exp_part)

        if sum(K_sigma_e .== Inf) != 0
            Inf_pos = collect(1:N)[K_sigma_e .== Inf]
            K_sigma_e[Inf_pos] .= 10^8
        end

        prob_sigma_e = K_sigma_e ./ (1 .+ K_sigma_e)
        prob_sigma_e_draw[i,:] = prob_sigma_e

        z_sigma_e_draw[i,:] = [rand(Bernoulli(x)) for x in prob_sigma_e]

        ### draw δ_sigma_e
        zero_sigma_e_pos = collect(1:N)[z_sigma_e_draw[i,:] .== 0]

        delta_sigma_e_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_e_post[ii]/2, tau_delta_sigma_e_post[ii]/2)) for ii in 1:N]

        if length(zero_sigma_e_pos) != 0
            delta_sigma_e_draw[i,zero_sigma_e_pos] .= 1
        end





        ###################################################
        ### BLOCK 6: draw σ^2
        ###################################################

        ### draw σ_u^2(t) 
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 7) )
     
        nu_sigma_u_post  = nu_sigma_u .+ Nt
        tau_sigma_u_post = tau_sigma_u .+ [sum_skipnan(delta_sigma_u_draw[i,:].^-1 .* (y[tt,:] - s_temp[tt,:] - sum(H[tt,:,:] .*      
                            (delta_alpha_draw[i,:,:] + repeat(alpha_draw[i,:], outer = [1,N]))', dims = 2) ).^2 ) for tt in 1:T]

        sigma2_u_draw[i,:] = [rand(InverseGamma(nu_sigma_u_post[tt]/2, tau_sigma_u_post[tt]/2)) for tt in 1:T]

        ### draw σ_e^2(t) 
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 8) )

        nu_sigma_e_post  = nu_sigma_e .+ Nt
        tau_sigma_e_post = tau_sigma_e .+ [sum_skipnan(delta_sigma_e_draw[i,:].^-1 .* (s_temp[tt,:] - rho_i .* s_lag_temp[tt,:]).^2) for tt in 1:T]

        sigma2_e_draw[i,:] = [rand(InverseGamma(nu_sigma_e_post[tt]/2, tau_sigma_e_post[tt]/2)) for tt in 1:T]
    end

    # posterior draws
    alpha_draw_post           = alpha_draw[burnin:end,:]
    rho_draw_post             = rho_draw[burnin:end]
    delta_alpha_draw_post     = delta_alpha_draw[burnin:end,:,:]
    delta_rho_draw_post       = delta_rho_draw[burnin:end,:]
    delta_sigma_u_draw_post   = delta_sigma_u_draw[burnin:end,:]
    delta_sigma_e_draw_post   = delta_sigma_e_draw[burnin:end,:]
    vdelta_alpha_draw_post    = vdelta_alpha_draw[burnin:end,:,:]
    vdelta_rho_draw_post      = vdelta_rho_draw[burnin:end]
    vdelta_sigma_u_draw_post  = vdelta_sigma_u_draw[burnin:end,:]
    vdelta_sigma_e_draw_post  = vdelta_sigma_e_draw[burnin:end,:]
    sigma2_u_draw_post        = sigma2_u_draw[burnin:end,:]
    sigma2_e_draw_post        = sigma2_e_draw[burnin:end,:]
    z_alpha_draw_post         = z_alpha_draw[burnin:end,:]
    z_rho_draw_post           = z_rho_draw[burnin:end,:]
    z_sigma_u_draw_post       = z_sigma_u_draw[burnin:end,:]
    z_sigma_e_draw_post       = z_sigma_e_draw[burnin:end,:]
    prob_alpha_draw_post      = prob_alpha_draw[burnin:end,:]
    prob_rho_draw_post        = prob_rho_draw[burnin:end,:]
    prob_sigma_u_draw_post    = prob_sigma_u_draw[burnin:end,:]
    prob_sigma_e_draw_post    = prob_sigma_e_draw[burnin:end,:]
    q_alpha_draw_post         = q_alpha_draw[burnin:end]
    q_rho_draw_post           = q_rho_draw[burnin:end]
    q_sigma_u_draw_post       = q_sigma_u_draw[burnin:end]
    q_sigma_e_draw_post       = q_sigma_e_draw[burnin:end]
    s_draw_post               = s_draw[burnin:end,:,:]
    s0_mean_draw_post         = s0_mean_draw[burnin:end]
    s0_var_draw_post          = s0_var_draw[burnin:end]
   

    # posterior mean
    alpha_hat          = mean( alpha_draw_post, dims = 1)'
    rho_hat            = mean( rho_draw_post )
    delta_alpha_hat    = mean( delta_alpha_draw_post, dims = 1)[1,:,:]'
    delta_rho_hat      = mean( delta_rho_draw_post, dims = 1)'
    delta_sigma_u_hat  = mean( delta_sigma_u_draw_post, dims = 1)'
    delta_sigma_e_hat  = mean( delta_sigma_e_draw_post, dims = 1)'
    vdelta_alpha_hat   = mean( vdelta_alpha_draw_post, dims = 1)[1,:,:]'
    vdelta_rho_hat     = mean( vdelta_rho_draw_post )
    vdelta_sigma_u_hat = mean( vdelta_sigma_u_draw_post )
    vdelta_sigma_e_hat = mean( vdelta_sigma_e_draw_post )
    sigma2_u_hat       = mean( sigma2_u_draw_post, dims = 1)'
    sigma2_e_hat       = mean( sigma2_e_draw_post, dims = 1)'
    z_alpha_hat        = mean( z_alpha_draw_post, dims = 1)'
    z_rho_hat          = mean( z_rho_draw_post, dims = 1)'
    z_sigma_u_hat      = mean( z_sigma_u_draw_post, dims = 1)'
    z_sigma_e_hat      = mean( z_sigma_e_draw_post, dims = 1)'
    prob_alpha_hat     = mean( prob_alpha_draw_post, dims = 1)'
    prob_rho_hat       = mean( prob_rho_draw_post, dims = 1)'
    prob_sigma_u_hat   = mean( prob_sigma_u_draw_post, dims = 1)'
    prob_sigma_e_hat   = mean( prob_sigma_e_draw_post, dims = 1)'
    q_alpha_hat        = mean( q_alpha_draw_post )
    q_rho_hat          = mean( q_rho_draw_post )
    q_sigma_u_hat      = mean( q_sigma_u_draw_post )
    q_sigma_e_hat      = mean( q_sigma_e_draw_post )
    s0_mean_hat        = mean( s0_mean_draw_post )
    s0_var_hat         = mean( s0_var_draw_post )

    s_hat = zeros(T+1, N)
    for ii in 1:N
        for tt in 1:T+1
            s_hat[tt, ii] = mean(skipnan(s_draw_post[:,ii,tt]))
        end
    end

    RWMH_u_accept_hat = mean(RWMH_u_accept_record[burnin:end])
    RWMH_e_accept_hat = mean(RWMH_e_accept_record[burnin:end])

    post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_u_hat = sigma2_u_hat, sigma2_e_hat = sigma2_e_hat,
                 delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat, delta_sigma_u_hat = delta_sigma_u_hat, delta_sigma_e_hat = delta_sigma_e_hat,
                 vdelta_alpha_hat = vdelta_alpha_hat, vdelta_rho_hat = vdelta_rho_hat, vdelta_sigma_u_hat = vdelta_sigma_u_hat, vdelta_sigma_e_hat = vdelta_sigma_e_hat,
                 z_alpha_hat = z_alpha_hat, z_rho_hat = z_rho_hat, z_sigma_u_hat = z_sigma_u_hat, z_sigma_e_hat = z_sigma_e_hat,
                 prob_alpha_hat = prob_alpha_hat, prob_rho_hat = prob_rho_hat, prob_sigma_u_hat = prob_sigma_u_hat, prob_sigma_e_hat = prob_sigma_e_hat,
                 q_alpha_hat = q_alpha_hat, q_rho_hat = q_rho_hat, q_sigma_u_hat = q_sigma_u_hat, q_sigma_e_hat = q_sigma_e_hat,
                 s_hat = s_hat, s0_var_hat = s0_var_hat, s0_mean_hat = s0_mean_hat,
                 RWMH_u_accept_hat = RWMH_u_accept_hat, RWMH_e_accept_hat = RWMH_e_accept_hat)
    
    post_draw = (alpha_draw          = alpha_draw_post,
                rho_draw             = rho_draw_post,
                delta_alpha_draw     = delta_alpha_draw_post,
                delta_rho_draw       = delta_rho_draw_post,
                delta_sigma_u_draw   = delta_sigma_u_draw_post,
                delta_sigma_e_draw   = delta_sigma_e_draw_post,
                vdelta_alpha_draw    = vdelta_alpha_draw_post,
                vdelta_rho_draw      = vdelta_rho_draw_post,
                vdelta_sigma_u_draw  = vdelta_sigma_u_draw_post,
                vdelta_sigma_e_draw  = vdelta_sigma_e_draw_post,
                sigma2_u_draw        = sigma2_u_draw_post,
                sigma2_e_draw        = sigma2_e_draw_post,
                z_alpha_draw         = z_alpha_draw_post,
                z_rho_draw           = z_rho_draw_post,
                z_sigma_u_draw       = z_sigma_u_draw_post,
                z_sigma_e_draw       = z_sigma_e_draw_post,
                prob_alpha_draw      = prob_alpha_draw_post,
                prob_rho_draw        = prob_rho_draw_post,
                prob_sigma_u_draw    = prob_sigma_u_draw_post,
                prob_sigma_e_draw    = prob_sigma_e_draw_post,
                q_alpha_draw         = q_alpha_draw_post,
                q_rho_draw           = q_rho_draw_post,
                q_sigma_u_draw       = q_sigma_u_draw_post,
                q_sigma_e_draw       = q_sigma_e_draw_post,
                s_draw               = s_draw_post,
                s0_mean_draw         = s0_mean_draw_post,
                s0_var_draw          = s0_var_draw_post)

    return post_mean, post_draw

end

# AR, estimate para using ind data only --> AR
function est_AR_hetsk_unb(y_all, H, lambda, len_MCMC, id_simul)

    #* this verison is designed for unbalanced panel.
    #* this version estimates the parameters on the own data

    # len_MCMC = Int(50)
    # id_simul = seed
    # y = y_all

    len_MCMC = Int(len_MCMC)
    burnin   = Int(floor(0.5*len_MCMC))+1
    # burnin = 1

    y = y_all[1:end,:]
    
    T, N, dimH = size(H)

    # characters of unbalanced panel
    loc_nan = (y .=== NaN)
    loc_first_obs = mapslices(find_first_nonNA, y, dims = 1)[1,:];
    loc_last_obs  = mapslices(find_last_nonNA, y, dims = 1)[1,:]

    # T_stay = T .- sum(isnan.(y), dims = 1)[1,:]
    T_stay = loc_last_obs .- loc_first_obs .+ 1
    Nt = N .- sum(isnan.(y), dims = 2)[:,1]

    # unload HP
    mu_delta_alpha, mu_delta_rho,
    vdelta_alpha, vdelta_rho,
    nu_vsigma_u, tau_vsigma_u, nu_vsigma_e, tau_vsigma_e, 
    mu_s0, v_s0 = lambda

    # useful subfunctions
    crossprod(x) = x' * x
    g(x) = min(abs(x), 10) * sign(x) # helper function in adapative RWMH
    sum_skipnan(x) = sum(skipnan(x))

    delta_alpha_draw    = zeros(len_MCMC+1, dimH, N)
    delta_rho_draw      = zeros(len_MCMC+1, N)
    delta_sigma_u_draw  = zeros(len_MCMC+1, N)
    delta_sigma_e_draw  = zeros(len_MCMC+1, N) 
    s_draw              = zeros(len_MCMC+1, N, T+1)

    ### initialize parameters

    # δ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

    alpha_temp = [rand(MvNormal(mu_delta_alpha, vdelta_alpha)) for ii in 1:N]
    alpha_temp = reduce(vcat, transpose(alpha_temp))'
    delta_alpha_draw[1,:,:] = alpha_temp

    delta_rho_draw[1,:] = rand(Normal(0, sqrt(vdelta_rho)), N)
    delta_rho_draw[1,:] = delta_rho_draw[1,:] .* abs.(delta_rho_draw[1,:] .< 0.2) # limit explosive series

    delta_sigma_u_draw[1,:] = rand(InverseGamma(nu_vsigma_u/2, tau_vsigma_u/2), N)
    delta_sigma_e_draw[1,:] = rand(InverseGamma(nu_vsigma_e/2, tau_vsigma_e/2), N)

    sigma2_u_it = kron(ones(T,1), delta_sigma_u_draw[1,:]') # T x N
    sigma2_e_it = kron(ones(T,1), delta_sigma_e_draw[1,:]') # T x N

    sigma2_u_it[loc_nan] .= NaN
    sigma2_e_it[loc_nan] .= NaN

    # s0
    s0_temp = rand(Normal(mu_s0, v_s0), N)

    # AR coef
    rho_i = delta_rho_draw[1,:]

    # covariance matrix 
    var_s = zeros(T, N)
    for t = 1:T
        tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
        if t == 1
            for ii in 1:N
                var_s[tt[ii],ii] = rho_i[ii]^2 * v_s0 + sigma2_e_it[tt[ii],ii]
            end
            
        else
            i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
            for ii in i_update
                var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
            end
        end
    end

    cov_s = zeros(T, T, N)
    for ii = 1:N
        for t1 = loc_first_obs[ii]:loc_last_obs[ii]
            for t2 = t1:loc_last_obs[ii]
                cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
            end
        end
    end


    s_temp = zeros(N, T+1) # +1 for initial value

    for ii = 1:N
        nobs_ii = T_stay[ii]

        s_temp[ii, loc_first_obs[ii]] = s0_temp[ii]
        s_temp[ii, loc_first_obs[ii]+1:loc_last_obs[ii]+1] = rand(MvNormal(vec(zeros(nobs_ii,1)), 
                   make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii])))
    end
    s_temp[s_temp .== 0] .= NaN

    s_draw[1,:,:] = s_temp

    for i = ProgressBar(2:len_MCMC+1)

        # i = 2
        # # println("iter = $i")

        # current values for state variables
        s_lag_temp = s_draw[i-1,:,1:end-1]' # T x N
        s_temp     = s_draw[i-1,:,2:end]'

        # variance of errors
        sigma2_u_it = kron(ones(T,1), delta_sigma_u_draw[i-1,:]') # T x N
        sigma2_e_it = kron(ones(T,1), delta_sigma_e_draw[i-1,:]') # T x N

        sigma2_u_it[loc_nan] .= NaN
        sigma2_e_it[loc_nan] .= NaN

        ###################################################
        ### BLOCK 4: draw δ for α and ρ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

        ### draw delta_rho 			
        # posterior mean and variance of delta_rho_i
        post_var_delta_rho  = [ (vdelta_rho^-1 + sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii].^2) )^-1 for ii in 1:N ]

        post_mean_delta_rho = [ post_var_delta_rho[ii] * (sum_skipnan(sigma2_e_it[:,ii].^-1 .* s_lag_temp[:,ii] .* s_temp[:,ii]) + vdelta_rho ^-1 * mu_delta_rho) for ii in 1:N ]

        delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

        ### draw delta_alpha
        # posterior mean and variance of beta (delta_alpha_i and s)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 6) )

        # AR coef
        rho_i = delta_rho_draw[i,:]

        # covariance matrix of s
        var_s = zeros(T, N)
        for t = 1:T
            tt = t - 1 .+ loc_first_obs # time period of the observation for each unit
            if t == 1
                for ii in 1:N
                    var_s[tt[ii],ii] = rho_i[ii]^2 * v_s0 + sigma2_e_it[tt[ii],ii]
                end
                
            else
                i_update = collect(1:N)[tt .<= loc_last_obs] # update units that have obs
                for ii in i_update
                    var_s[tt[ii], ii] = rho_i[ii]^2 * var_s[tt[ii]-1, ii] + sigma2_e_it[tt[ii], ii]
                end
            end
        end

        cov_s = zeros(T, T, N)
        for ii = 1:N
            for t1 = loc_first_obs[ii]:loc_last_obs[ii]
                for t2 = t1:loc_last_obs[ii]
                    cov_s[t1, t2, ii] = rho_i[ii]^(t2-t1) .* var_s[t1,ii]
                    cov_s[t2, t1, ii] = cov_s[t1, t2, ii]
                end
            end
        end

        # prior covarance matrix for beta (delta-alpha + s)
        Sigma_beta_prior = zeros(dimH + T, dimH + T, N)
        # Sigma_beta_prior[:] .= NaN
        for ii = 1:N
            pos  = dimH + loc_first_obs[ii]
            pos2 = dimH + loc_last_obs[ii]
            Sigma_beta_prior[(pos-dimH):(pos-1), (pos-dimH):(pos-1), ii] = vdelta_alpha # delta-alpha
            Sigma_beta_prior[pos:pos2, pos:pos2, ii] = 
                make_symmetric(cov_s[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii], ii]) # s_i1:T
        end

        Mu_beta_prior = [[mu_delta_alpha; zeros(T_stay[ii])] for ii in 1:N]

        # design matrix (delta-alpha + s_i1 + ... + s_iT)
        X_i = zeros(T, dimH + T, N)
        X_i[:] .= NaN

        for ii = 1:N
            X_i[:,loc_first_obs[ii]:(loc_first_obs[ii]+dimH-1), ii] = H[:,ii,:]
            X_i[loc_first_obs[ii]:loc_last_obs[ii], (loc_first_obs[ii]+dimH):(loc_last_obs[ii]+dimH), ii] = I(T_stay[ii])
        end

        # posterior for beta (delta-alpha + s)
        post_var_beta  = [make_symmetric( inv( inv(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH,loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) .+ 
            X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * 
            X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii] ) ) for ii in 1:N]

        post_mean_beta = [post_var_beta[ii] * (X_i[loc_first_obs[ii]:loc_last_obs[ii], loc_first_obs[ii]:loc_last_obs[ii]+dimH, ii]' * 
            Diagonal(sigma2_u_it[loc_first_obs[ii]:loc_last_obs[ii],ii].^-1) * y[loc_first_obs[ii]:loc_last_obs[ii], ii] + 
            inv(Sigma_beta_prior[loc_first_obs[ii]:loc_last_obs[ii]+dimH,loc_first_obs[ii]:loc_last_obs[ii]+dimH,ii]) * Mu_beta_prior[ii]) for ii in 1:N]


        ### draw delta_alpha and s when z_alpha_i = 1
        delta_alpha_temp = zeros(dimH, N)
        s_temp = zeros(T, N)
        for ii in 1:N
            beta_temp = rand(MvNormal(post_mean_beta[ii], post_var_beta[ii]))

            delta_alpha_temp[:,ii] = beta_temp[1:dimH]
            s_temp[:,ii] = [NaN*ones(loc_first_obs[ii]-1); beta_temp[(dimH+1):end]; NaN*ones(T - loc_last_obs[ii])]
        end

        delta_alpha_draw[i,:,:] = delta_alpha_temp


        # s0 (simultation smoother)
        s00 = mu_s0
        P00 = v_s0
        P10 = rho_i .* P00 .* rho_i + [sigma2_e_it[loc_first_obs[ii], ii] for ii in 1:N]
        
        s1_temp = [s_temp[loc_first_obs[ii],ii] for ii in 1:N]
        post_mean_s0 = s00 .+ P00 .* rho_i .* P10.^-1 .* (s1_temp - rho_i .* mu_s0)
        post_var_s0 = P00 .- P00 .* rho_i .* P10.^-1 .* rho_i .* P00
        s0_temp = [rand(Normal(post_mean_s0[ii], sqrt(post_var_s0[ii]))) for ii in 1:N]
        
        # insert S_0 into S_1:T
        s_temp2 = [NaN*ones(1,N); s_temp]
        for ii in 1:N
            s_temp2[loc_first_obs[ii], ii] = s0_temp[ii]
        end
        s_draw[i,:,:] = s_temp2'


        # current values for state variables
        s_lag_temp = s_draw[i,:,1:end-1]' # T x N
        s_temp     = s_draw[i,:,2:end]' # T x N




        ###################################################
        ### BLOCK 6: draw σ^2
        ###################################################

        ### draw σ_u^2
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 7) )
    
        nu_vsigma_u_post  = nu_vsigma_u .+ T_stay
        tau_vsigma_u_post = tau_vsigma_u .+ [sum_skipnan((y[:,ii] - s_temp[:,ii] - H[:,ii,:] * delta_alpha_draw[i,:,ii]).^2) for ii in 1:N]
        
        delta_sigma_u_draw[i,:] = [rand(InverseGamma(nu_vsigma_u_post[ii]/2, tau_vsigma_u_post[ii]/2)) for ii in 1:N]


        ### draw σ_e^2
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 8) )

        nu_vsigma_e_post  = nu_vsigma_e .+ T_stay
        tau_vsigma_e_post = tau_vsigma_e .+ [sum_skipnan((s_temp[:,ii] - rho_i[ii] .* s_lag_temp[:,ii]).^2) for ii in 1:N]

        delta_sigma_e_draw[i,:] = [rand(InverseGamma(nu_vsigma_e_post[ii]/2, tau_vsigma_e_post[ii]/2)) for ii in 1:N]

    end

    # posterior draws
    delta_alpha_draw_post     = delta_alpha_draw[burnin:end,:,:]
    delta_rho_draw_post       = delta_rho_draw[burnin:end,:]
    delta_sigma_u_draw_post   = delta_sigma_u_draw[burnin:end,:]
    delta_sigma_e_draw_post   = delta_sigma_e_draw[burnin:end,:]
    s_draw_post               = s_draw[burnin:end,:,:]


    # posterior mean
    delta_alpha_hat    = mean( delta_alpha_draw_post, dims = 1)[1,:,:]'
    delta_rho_hat      = mean( delta_rho_draw_post, dims = 1)'
    delta_sigma_u_hat  = mean( delta_sigma_u_draw_post, dims = 1)'
    delta_sigma_e_hat  = mean( delta_sigma_e_draw_post, dims = 1)'
    
    s_hat = zeros(T+1, N)
    for ii in 1:N
        for tt in 1:T+1
            s_hat[tt, ii] = mean(skipnan(s_draw_post[:,ii,tt]))
        end
    end

    post_mean = (delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat, 
                delta_sigma_u_hat = delta_sigma_u_hat, delta_sigma_e_hat = delta_sigma_e_hat,
                s_hat = s_hat)
    
    post_draw = (delta_alpha_draw     = delta_alpha_draw_post,
                delta_rho_draw       = delta_rho_draw_post,
                delta_sigma_u_draw   = delta_sigma_u_draw_post,
                delta_sigma_e_draw   = delta_sigma_e_draw_post,
                s_draw               = s_draw_post)

    return post_mean, post_draw
 
end
####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#####################################################################################################

#* This script generates Posterior Distribution for $\theta$
#* think about equal-tail probability 90% credible interval
#* Unbalanced case with ragged edge.

####################################################################################################
#                             Part 0: INTRO
####################################################################################################

cd()
wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/Empirics/Empirics_Unbalanced/"
cd(wd)

estimator = "M2"
estimator = "M2_HIP"
estimator = "M2_RIP"

# folder for jld2 outout for hist
wd_jld = string(wd, "Estimates/", estimator, "/jld_temp/")

# load packages (install them with Pkg.add() if needed)
using JLD2, Distributions, StatisticalRethinking

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################
# band %
ci = 0.1

# t_smpl = (yr0 + T2 - 1)
temp = load(wd_jld * "output.jld2")
post_mean_ss_hetsk = temp["post_mean_ss_hetsk"]
post_draw_ss_hetsk = temp["post_draw_ss_hetsk"]

N = length(post_mean_ss_hetsk.delta_alpha_hat[:,1])

## alpha0
alpha0_mean = post_mean_ss_hetsk.alpha_hat[1]

alpha0_draw = post_draw_ss_hetsk.alpha_draw[:,1]

alpha0_med  = median(alpha0_draw)
alpha0_hpdi = mapslices(x -> hpdi(x, alpha = ci), alpha0_draw; dims = 1)

## alpha1
alpha1_mean = post_mean_ss_hetsk.alpha_hat[2]

alpha1_draw = post_draw_ss_hetsk.alpha_draw[:,2]

alpha1_med  = median(alpha1_draw)
alpha1_hpdi = mapslices(x -> hpdi(x, alpha = ci), alpha1_draw; dims = 1)

## rho
rho_mean = post_mean_ss_hetsk.rho_hat

rho_draw = post_draw_ss_hetsk.rho_draw

rho_med  = median(rho_draw)
rho_hpdi = mapslices(x -> hpdi(x, alpha = ci), rho_draw; dims = 1)

## vdelta_alpha
vdelta_alpha_mean = post_mean_ss_hetsk.vdelta_alpha_hat

vdelta_alpha_draw = post_draw_ss_hetsk.vdelta_alpha_draw

vdelta_alpha_med  = median(vdelta_alpha_draw, dims = 1)[1,:,:]
vdelta_alpha_hpdi = mapslices(x -> hpdi(x, alpha = ci), vdelta_alpha_draw; dims = 1)
# LB: vdelta_alpha_hpdi[1,:,:]
# UB: vdelta_alpha_hpdi[2,:,:]

## vdelta_rho
vdelta_rho_mean = post_mean_ss_hetsk.vdelta_rho_hat

vdelta_rho_draw = post_draw_ss_hetsk.vdelta_rho_draw

vdelta_rho_med  = median(vdelta_rho_draw)
vdelta_rho_hpdi = mapslices(x -> hpdi(x, alpha = ci), vdelta_rho_draw; dims = 1)


## q_alpha
q_alpha_mean = post_mean_ss_hetsk.q_alpha_hat

q_alpha_draw = post_draw_ss_hetsk.q_alpha_draw

q_alpha_med  = median(q_alpha_draw)
q_alpha_hpdi = mapslices(x -> hpdi(x, alpha = ci), q_alpha_draw; dims = 1)


## q_rho
q_rho_mean = post_mean_ss_hetsk.q_rho_hat

q_rho_draw = post_draw_ss_hetsk.q_rho_draw

q_rho_med  = median(q_rho_draw)
q_rho_hpdi = mapslices(x -> hpdi(x, alpha = ci), q_rho_draw; dims = 1)


## q_sigma_u
q_sigma_u_mean = post_mean_ss_hetsk.q_sigma_u_hat

q_sigma_u_draw = post_draw_ss_hetsk.q_sigma_u_draw

q_sigma_u_med  = median(q_sigma_u_draw)
q_sigma_u_hpdi = mapslices(x -> hpdi(x, alpha = ci), q_sigma_u_draw; dims = 1)

## q_sigma_e
q_sigma_e_mean = post_mean_ss_hetsk.q_sigma_e_hat

q_sigma_e_draw = post_draw_ss_hetsk.q_sigma_e_draw

q_sigma_e_med  = median(q_sigma_e_draw)
q_sigma_e_hpdi = mapslices(x -> hpdi(x, alpha = ci), q_sigma_e_draw; dims = 1)


## vdelta_sigma_u
vdelta_sigma_u_mean = post_mean_ss_hetsk.vdelta_sigma_u_hat

vdelta_sigma_u_draw = post_draw_ss_hetsk.vdelta_sigma_u_draw

vdelta_sigma_u_med  = median(vdelta_sigma_u_draw)
vdelta_sigma_u_hpdi = mapslices(x -> hpdi(x, alpha = ci), vdelta_sigma_u_draw; dims = 1)

## vdelta_sigma_e
vdelta_sigma_e_mean = post_mean_ss_hetsk.vdelta_sigma_e_hat

vdelta_sigma_e_draw = post_draw_ss_hetsk.vdelta_sigma_e_draw

vdelta_sigma_e_med  = median(vdelta_sigma_e_draw)
vdelta_sigma_e_hpdi = mapslices(x -> hpdi(x, alpha = ci), vdelta_sigma_e_draw; dims = 1)

## s0_mean
s0_mean_mean = post_mean_ss_hetsk.s0_mean_hat

s0_mean_draw = post_draw_ss_hetsk.s0_mean_draw

s0_mean_med  = median(s0_mean_draw)
s0_mean_hpdi = mapslices(x -> hpdi(x, alpha = ci), s0_mean_draw; dims = 1)

## s0_var
s0_var_mean = post_mean_ss_hetsk.s0_var_hat

s0_var_draw = post_draw_ss_hetsk.s0_var_draw

s0_var_med  = median(s0_var_draw)
s0_var_hpdi = mapslices(x -> hpdi(x, alpha = ci), s0_var_draw; dims = 1)


#* collect estimate in one matrix
output = Array{Float64,2}(undef, 14, 3)

output[1,:]   = [alpha0_med alpha0_hpdi[1] alpha0_hpdi[2]]
output[2,:]   = [alpha1_med alpha1_hpdi[1] alpha1_hpdi[2]]
output[3,:]   = [rho_med rho_hpdi[1] rho_hpdi[2]]
output[4,:]   = [s0_mean_med s0_mean_hpdi[1] s0_mean_hpdi[2]]
output[5,:]   = [s0_var_med s0_var_hpdi[1] s0_var_hpdi[2]]
output[6,:]   = [q_alpha_med q_alpha_hpdi[1] q_alpha_hpdi[2]]
output[7,:]   = [q_rho_med q_rho_hpdi[1] q_rho_hpdi[2]]
output[8,:]   = [q_sigma_u_mean q_sigma_u_hpdi[1] q_sigma_u_hpdi[2]]
output[9,:]   = [q_sigma_e_mean q_sigma_e_hpdi[1] q_sigma_e_hpdi[2]]
output[10,:]  = [vdelta_alpha_med[1,1] vdelta_alpha_hpdi[1,1,1] vdelta_alpha_hpdi[2,1,1]]
output[11,:]  = [vdelta_alpha_med[2,2] vdelta_alpha_hpdi[1,2,2] vdelta_alpha_hpdi[2,2,2]]
output[12,:]  = [vdelta_rho_med vdelta_rho_hpdi[1] vdelta_rho_hpdi[2]]
output[13,:]  = [vdelta_sigma_u_med vdelta_sigma_u_hpdi[1] vdelta_sigma_u_hpdi[2]]
output[14,:]  = [vdelta_sigma_e_med vdelta_sigma_e_hpdi[1] vdelta_sigma_e_hpdi[2]]

round.( output, digits = 2)
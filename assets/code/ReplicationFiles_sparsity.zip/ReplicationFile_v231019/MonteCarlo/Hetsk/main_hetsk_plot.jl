####################################################################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  DGP 4: Heteroskedastic Dynamic Panel Data Model
#####################################################################################################

####################################################################################################
#                             Part 0: INTRO
####################################################################################################

wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/MonteCarlo/Hetsk/"
wd_plots = wd * "Plots/"
cd(wd)

# load packages (install them with Pkg.add() if needed)
using JLD2, FileIO, MutableNamedTuples, Random, Distributions, LinearAlgebra, Dates, SharedArrays
using StatsPlots, KernelDensity, Plots

using Pkg, Dates, Random, Distributions, IterTools, Expectations, Polynomials, SpecialFunctions
using LinearAlgebra, JLD2, FileIO, DataFrames, NLsolve, Plots, QuadGK, MutableNamedTuples
using StatsPlots, KernelDensity

# load subfunction files
include("functions_hetsk.jl")

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

# DGP3 version
data_version_id = 1
# Number of simulation
nSim = 100
# number of observations for each draw
bign = 500
# number of time period
bigt = 8
# number of MCMC draws
nMCMC = 5000
burnin = Int(floor(0.5*nMCMC))+2

# Parameter in the prior of v_δ^α (Inverse Gamma)
prior_mean_delta_alpha = 1
prior_sd_delta_alpha   = 1
nu_vdelta_alpha  = 4+2*prior_mean_delta_alpha^2/prior_sd_delta_alpha^2
tau_vdelta_alpha = 2*prior_mean_delta_alpha*(1+prior_mean_delta_alpha^2/prior_sd_delta_alpha^2)

# Parameter in the prior of v_δ^ρ (Inverse Gamma)
prior_mean_delta_rho = 0.5
prior_sd_delta_rho   = 0.5
nu_vdelta_rho  = 4+2*prior_mean_delta_rho^2/prior_sd_delta_rho^2
tau_vdelta_rho = 2*prior_mean_delta_rho*(1+prior_mean_delta_rho^2/prior_sd_delta_rho^2)

# Hyperparameter in the prior of the implied variance v_δ^σ (Inverse Gamma), ω = V(δ^σ) = 1/(ν_δ^σ/2 - 1)
prior_mean_vdelta_sigma = 1
prior_sd_vdelta_sigma   = 0.5
nu_vdelta_sigma  = 4+2*prior_mean_vdelta_sigma^2/prior_sd_vdelta_sigma^2
tau_vdelta_sigma = 2*prior_mean_vdelta_sigma*(1+prior_mean_vdelta_sigma^2/prior_sd_vdelta_sigma^2)

# homogeneous parameter
theta = MutableNamedTuple(alpha = 1.0, rho = 0.6, sigma2 = 0.8, q = NaN,
        vdelta_alpha = NaN, vdelta_rho = 0.09, nu_delta_sigma = 6, tau_delta_sigma = 4)

# hyperparameters
lambda = MutableNamedTuple(valpha = 1, vrho = 0.25, nu_sigma = 12, tau_sigma = 10, a = 1, b = 1,
        nu_vdelta_alpha = nu_vdelta_alpha, tau_vdelta_alpha = tau_vdelta_alpha,
        nu_vdelta_rho = nu_vdelta_rho, tau_vdelta_rho = tau_vdelta_rho,
        nu_vdelta_sigma = nu_vdelta_sigma, tau_vdelta_sigma = tau_vdelta_sigma)

# grid for q
q_grid = collect(0:0.2:1)

# grid for v_δ^α
vdelta_alpha_grid = [0.05,0.1,0.5,1]

####################################################################################################
#                             Part 2: SIMULATION
####################################################################################################


# vdelta_alpha = 0.5
l = 3

correction_thr = 0.80

# fix random seed
seed = 55 

#### q = 0.2
k = 2

wd_plots_sub = string(wd_plots, "seed$(seed)/")
if !isdir(wd_plots_sub)
 mkdir(wd_plots_sub)
end

theta.q = q_grid[k]
theta.vdelta_alpha = vdelta_alpha_grid[l]

#########################
# Generate panel y
#########################
Random.seed!(seed)
y_all, delta_alpha, delta_rho = generate_paneldata_hetsk(bign, bigt+1, theta, data_version_id)

#########################
# GLP, spike-and-slab, New, version 1
#########################
post_mean_glp, post_draw_glp = SS_hetsk(y_all, lambda, 0.5, nMCMC, 1, seed)


### alpha
# histogram of posterior means
histogram(post_mean_glp.alpha_hat .+ vec(post_mean_glp.delta_alpha_hat), nbin = 60, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)


savefig(wd_plots_sub * "fig_exp2_hist_post_alpha_q$(Int(q_grid[k]*100)).png")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
delta_alpha_nzero = [sum(post_draw_glp.delta_alpha_draw[:,i] .== 0) for i = 1:bign]
delta_alpha_zerod = delta_alpha_nzero .> floor( size(post_draw_glp.delta_alpha_draw,1)*correction_thr )
delta_alpha_post_glp_c = copy(post_mean_glp.delta_alpha_hat)
delta_alpha_post_glp_c[delta_alpha_zerod,:] .= 0

histogram(post_mean_glp.alpha_hat .+ vec(delta_alpha_post_glp_c), nbin = 50, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_plots_sub * "fig_exp2_hist_post_alpha_q$(Int(q_grid[k]*100))_corrected.png")



### rho
# histogram of posterior means
histogram(post_mean_glp.rho_hat .+ vec(post_mean_glp.delta_rho_hat), nbin = 60, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_plots_sub * "fig_exp2_hist_post_rho_q$(Int(q_grid[k]*100)).png")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
delta_rho_nzero = [sum(post_draw_glp.delta_rho_draw[:,i] .== 0) for i = 1:bign]
delta_rho_zerod = delta_rho_nzero .> floor( size(post_draw_glp.delta_rho_draw,1)*correction_thr )
delta_rho_post_glp_c = copy(post_mean_glp.delta_rho_hat)
delta_rho_post_glp_c[delta_rho_zerod,:] .= 0

histogram(post_mean_glp.rho_hat .+ vec(delta_rho_post_glp_c), nbin = 60, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_plots_sub * "fig_exp2_hist_post_rho_q$(Int(q_grid[k]*100))_corrected.png")


### sigma2
# histogram of posterior means
histogram(post_mean_glp.sigma2_hat .* vec(post_mean_glp.delta_sigma_hat), nbin = 70, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10, xlims = (0,4),
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_plots_sub * "fig_exp2_hist_post_sigma2_q$(Int(q_grid[k]*100)).png")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
delta_sigma_nzero = [sum(post_draw_glp.delta_sigma_draw[:,i] .== 1) for i = 1:bign]
delta_sigma_zerod = delta_sigma_nzero .> floor( size(post_draw_glp.delta_sigma_draw,1)*correction_thr)
delta_sigma_post_glp_c = copy(post_mean_glp.delta_sigma_hat)
delta_sigma_post_glp_c[delta_sigma_zerod,:] .= 1

histogram(post_mean_glp.sigma2_hat .* vec(delta_sigma_post_glp_c), nbin = 70, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10, xlims = (0,4),
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_plots_sub * "fig_exp2_hist_post_sigma2_q$(Int(q_grid[k]*100))_corrected.png")

### q
den_alpha = kde(post_draw_glp.q_alpha_draw)
den_rho = kde(post_draw_glp.q_rho_draw)
den_sigma = kde(post_draw_glp.q_sigma_draw)

plot(den_alpha, label = "\$q^{\\alpha}\$", legend = false, xlims = (0,1),
    xtickfontsize = 10, ytickfontsize = 10, linewidth = 2,
    # yticks = (0:1.5:maximum(den_alpha.density)+0.5, string.(0:1.5:maximum(den_alpha.density)+0.5)),
    framestyle = :box, size = (300,200), dpi = 200)
plot!(den_rho, linewidth = 2, label = "\$q^{\\rho}\$")
plot!(den_sigma, linewidth = 2, label = "\$q^{\\sigma}\$")
plot!(Beta(1,1), color = :black, label="", linestyle =:dot)

savefig(wd_plots_sub * "fig_exp2_den_post_q_q$(Int(q_grid[k]*100)).png")




################################################################################################################################


#### q = 0.8
k = 5

theta.q = q_grid[k]
theta.vdelta_alpha = vdelta_alpha_grid[l]

#########################
# Generate panel y
#########################
Random.seed!(seed)
y_all, delta_alpha, delta_rho = generate_paneldata_hetsk(bign, bigt+1, theta, data_version_id)

#########################
# GLP, spike-and-slab, New, version 1
#########################
post_mean_glp, post_draw_glp = SS_hetsk(y_all, lambda, 0.5, nMCMC, 1, seed)

### alpha
# histogram of posterior means
histogram(post_mean_glp.alpha_hat .+ vec(post_mean_glp.delta_alpha_hat), nbin = 40, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)


savefig(wd_plots_sub * "fig_exp2_hist_post_alpha_q$(Int(q_grid[k]*100)).png")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
delta_alpha_nzero = [sum(post_draw_glp.delta_alpha_draw[:,i] .== 0) for i = 1:bign]
delta_alpha_zerod = delta_alpha_nzero .> floor( size(post_draw_glp.delta_alpha_draw,1)*correction_thr )
delta_alpha_post_glp_c = copy(post_mean_glp.delta_alpha_hat)
delta_alpha_post_glp_c[delta_alpha_zerod,:] .= 0

histogram(post_mean_glp.alpha_hat .+ vec(delta_alpha_post_glp_c), nbin = 40, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_plots_sub * "fig_exp2_hist_post_alpha_q$(Int(q_grid[k]*100))_corrected.png")



### rho
# histogram of posterior means
histogram(post_mean_glp.rho_hat .+ vec(post_mean_glp.delta_rho_hat), nbin = 50, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_plots_sub * "fig_exp2_hist_post_rho_q$(Int(q_grid[k]*100)).png")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
delta_rho_nzero = [sum(post_draw_glp.delta_rho_draw[:,i] .== 0) for i = 1:bign]
delta_rho_zerod = delta_rho_nzero .> floor( size(post_draw_glp.delta_rho_draw,1)*correction_thr )
delta_rho_post_glp_c = copy(post_mean_glp.delta_rho_hat)
delta_rho_post_glp_c[delta_rho_zerod,:] .= 0

histogram(post_mean_glp.rho_hat .+ vec(delta_rho_post_glp_c), nbin = 50, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10,
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_plots_sub * "fig_exp2_hist_post_rho_q$(Int(q_grid[k]*100))_corrected.png")


### sigma2
# histogram of posterior means
histogram(post_mean_glp.sigma2_hat .* vec(post_mean_glp.delta_sigma_hat), nbin = 70, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10, xlims = (0,6),
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_plots_sub * "fig_exp2_hist_post_sigma2_q$(Int(q_grid[k]*100)).png")

# histogram of posterior means, corrected with 50% threshold
# if more than 50% draw are zero, then delta_alpha is zero
delta_sigma_nzero = [sum(post_draw_glp.delta_sigma_draw[:,i] .== 1) for i = 1:bign]
delta_sigma_zerod = delta_sigma_nzero .> floor( size(post_draw_glp.delta_sigma_draw,1)*correction_thr)
delta_sigma_post_glp_c = copy(post_mean_glp.delta_sigma_hat)
delta_sigma_post_glp_c[delta_sigma_zerod,:] .= 1

histogram(post_mean_glp.sigma2_hat .* vec(delta_sigma_post_glp_c), nbin = 70, normalize = :probability,
            xtickfontsize = 10, ytickfontsize = 10, xlims = (0,6),
            label = "",  framestyle = :box, size = (300,200), dpi = 200)

savefig(wd_plots_sub * "fig_exp2_hist_post_sigma2_q$(Int(q_grid[k]*100))_corrected.png")

### q
den_alpha = kde(post_draw_glp.q_alpha_draw)
den_rho = kde(post_draw_glp.q_rho_draw)
den_sigma = kde(post_draw_glp.q_sigma_draw)

plot(den_alpha, label = "\$q^{\\alpha}\$", legend = false, xlims = (0,1),
    xtickfontsize = 10, ytickfontsize = 10, linewidth = 2,
    # yticks = (0:1.5:maximum(den_alpha.density)+0.5, string.(0:1.5:maximum(den_alpha.density)+0.5)),
    framestyle = :box, size = (300,200), dpi = 200)
plot!(den_rho, linewidth = 2, label = "\$q^{\\rho}\$")
plot!(den_sigma, linewidth = 2, label = "\$q^{\\sigma}\$")
plot!(Beta(1,1), color = :black, label="", linestyle =:dot)

savefig(wd_plots_sub * "fig_exp2_den_post_q_q$(Int(q_grid[k]*100)).png")



println("Figures for seed = $(seed) are ready.")
##############################################################
#  Bayesian Estimation of Sparsely Heterogenous Panel Models
#  DGP 4: Heteroskedastic Dynamic Panel Data Model
#  Version: Parallel
#  Creation: 12/02/2019
#############################################################

####################################################################################################
#                             Part 0: INTRO
####################################################################################################

using Distributed

rmprocs(workers())
#Add workers
println("Adding workers... ")
addprocs(6)
println("Number of active processors = $(nprocs())")

wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/MonteCarlo/Hetsk/"
# wd = "$(pwd())/ReplicationFile_v231019/MonteCarlo/Hetsk/"

# create folder: Results
wd_results = string(wd, "Results/")
if !isdir(wd_results)
    mkdir(wd_results)
end


# load packages (install them with Pkg.add() if needed)
@everywhere using JLD2, FileIO, MutableNamedTuples, Random, Distributions, LinearAlgebra, Dates, SharedArrays, SpecialFunctions

# load subfunction files
@everywhere include("functions_hetsk.jl")

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

# DGP version
@everywhere data_version_id = 1
# Number of simulation
@everywhere nSim = 100
# number of observations for each draw
@everywhere bign = 500
# number of time period
@everywhere bigt = 8
# number of MCMC draws
@everywhere nMCMC = 5000
@everywhere burnin = Int(floor(0.5*nMCMC))+2

# Hyperparameter in the prior of v_δ^α (Inverse Gamma)
@everywhere prior_mean_delta_alpha = 1
@everywhere prior_sd_delta_alpha  = 0.5
@everywhere nu_vdelta_alpha  = 4+2*prior_mean_delta_alpha^2/prior_sd_delta_alpha^2
@everywhere tau_vdelta_alpha = 2*prior_mean_delta_alpha*(1+prior_mean_delta_alpha^2/prior_sd_delta_alpha^2)

# Hyperparameter in the prior of v_δ^ρ (Inverse Gamma)
@everywhere prior_mean_delta_rho = 0.5
@everywhere prior_sd_delta_rho  = 0.5
@everywhere nu_vdelta_rho  = 4+2*prior_mean_delta_rho^2/prior_sd_delta_rho^2
@everywhere tau_vdelta_rho = 2*prior_mean_delta_rho*(1+prior_mean_delta_rho^2/prior_sd_delta_rho^2)

# Hyperparameter in the prior of the implied variance v_δ^σ (Inverse Gamma), ω = V(δ^σ) = 1/(ν_δ^σ/2 - 1)
@everywhere prior_mean_vdelta_sigma = 1
@everywhere prior_sd_vdelta_sigma   = 0.5
@everywhere nu_vdelta_sigma  = 4+2*prior_mean_vdelta_sigma^2/prior_sd_vdelta_sigma^2
@everywhere tau_vdelta_sigma = 2*prior_mean_vdelta_sigma*(1+prior_mean_vdelta_sigma^2/prior_sd_vdelta_sigma^2)

# homogeneous parameter
@everywhere theta = MutableNamedTuple(alpha = 1.0, rho = 0.6, sigma2 = 0.8, q = NaN,
                    vdelta_alpha = NaN, vdelta_rho = 0.09, nu_delta_sigma = 6, tau_delta_sigma = 4)

# hyperparameters
@everywhere lambda = MutableNamedTuple(valpha = 1, vrho = 0.25, nu_sigma = 12, tau_sigma = 10, a = 1, b = 1,
                    nu_vdelta_alpha = nu_vdelta_alpha, tau_vdelta_alpha = tau_vdelta_alpha,
                    nu_vdelta_rho = nu_vdelta_rho, tau_vdelta_rho = tau_vdelta_rho,
                    nu_vdelta_sigma = nu_vdelta_sigma, tau_vdelta_sigma = tau_vdelta_sigma)

# grid for q
@everywhere q_grid = collect(0:0.2:1)

# grid for v_δ^α
@everywhere vdelta_alpha_grid = [0.05,0.1,0.5,1]

# create empty arrays
@everywhere matMSE_alpha_homo   = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_rho_homo     = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_alpha_hetero = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_rho_hetero   = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_alpha_ss_he  = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_rho_ss_he    = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_alpha_ss_ho  = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_rho_ss_ho    = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_alpha_ss_o   = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_rho_ss_o     = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)

@everywhere matMSE_vdelta_alpha_hetero = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_vdelta_rho_hetero   = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_vdelta_sigma_hetero = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_vdelta_alpha_ss     = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_vdelta_rho_ss       = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_vdelta_sigma_ss     = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)

@everywhere mat_accp_rate_hetero = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere mat_accp_rate_ss    = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)

# target acceptance rate in RWMH
@everywhere opt_ar = 0.44

####################################################################################################
#                             Part 2: MC SIMULATION
####################################################################################################

println(" Simulation starts, # of simulation = $(nSim[1]), # of MCMC chain = $nMCMC, version = $data_version_id")

for k in eachindex(q_grid), l in eachindex(vdelta_alpha_grid)

    @time @sync @distributed for i = 1:nSim

        theta.q = q_grid[k]
        theta.vdelta_alpha = vdelta_alpha_grid[l]

        #########################
        # Generate panel y
        #########################
        Random.seed!(i)
        y_all, delta_alpha, delta_rho, delta_sigma = generate_paneldata_hetsk(bign, bigt+1, theta, data_version_id)

        ##########################
        # GLP, spike-and-slab
        #########################
        post_mean_ss_he, post_draw_ss_he = SS_hetsk(y_all, lambda, opt_ar, nMCMC, 1, i)

        matMSE_alpha_ss_he[i,k,l] = mean( ((post_mean_ss_he.alpha_hat .+ post_mean_ss_he.delta_alpha_hat) .- (theta.alpha .+ delta_alpha)).^2 )
        matMSE_rho_ss_he[i,k,l]   = mean( ((post_mean_ss_he.rho_hat .+ post_mean_ss_he.delta_rho_hat) .- (theta.rho .+ delta_rho)).^2 )

        matMSE_vdelta_alpha_ss[i,k,l] = (post_mean_ss_he.vdelta_alpha_hat - theta.vdelta_alpha)^2
        matMSE_vdelta_rho_ss[i,k,l]   = (post_mean_ss_he.vdelta_rho_hat - theta.vdelta_rho)^2
        matMSE_vdelta_sigma_ss[i,k,l] = (post_mean_ss_he.vdelta_sigma_hat - 1)^2

        mat_accp_rate_ss[i,k,l] = post_mean_ss_he.RWMH_accept_rate

        ##########################
        # GLP, spike-and-slab (oracle)
        #########################
        post_mean_ss_o, post_draw_ss_o = SS_hetsk_oracle(y_all, lambda, theta, nMCMC, 1, i)

        matMSE_alpha_ss_o[i,k,l] = mean( (post_mean_ss_o.delta_alpha_hat .- delta_alpha).^2 )
        matMSE_rho_ss_o[i,k,l]   = mean( (post_mean_ss_o.delta_rho_hat .- delta_rho).^2 )

        #########################
        # GLP, spike-and-slab, homsk (DGP3)
        #########################
        post_mean_ss_ho, post_draw_ss_ho = SS_homsk(y_all, lambda, nMCMC, 1, i)

        matMSE_alpha_ss_ho[i,k,l] = mean( ((post_mean_ss_ho.alpha_hat .+ post_mean_ss_ho.delta_alpha_hat) .- (theta.alpha .+ delta_alpha)).^2 )
        matMSE_rho_ss_ho[i,k,l]   = mean( ((post_mean_ss_ho.rho_hat .+ post_mean_ss_ho.delta_rho_hat) .- (theta.rho .+ delta_rho)).^2 )

        #########################
        # Homogeneity
        #########################
        post_mean_homo, post_draw_homo = Homo_hetsk(y_all, lambda, nMCMC, i)
        # calculate MSE
        matMSE_alpha_homo[i,k,l] = mean( (post_mean_homo.alpha_hat .- (theta.alpha .+ delta_alpha)).^2 )
        matMSE_rho_homo[i,k,l]   = mean( (post_mean_homo.rho_hat  .- (theta.rho .+ delta_rho)).^2 )

        #########################
        # Full Heterogeneity (spike-and-slab with q = 1)
        #########################
        post_mean_hetero, post_draw_hetero = Hetero_hetsk(y_all, lambda, opt_ar, nMCMC, i)

        # calculate MSE
        matMSE_alpha_hetero[i,k,l] = mean( ((post_mean_hetero.alpha_hat .+ post_mean_hetero.delta_alpha_hat) .- (theta.alpha .+ delta_alpha)).^2 )
        matMSE_rho_hetero[i,k,l]   = mean( ((post_mean_hetero.rho_hat .+ post_mean_hetero.delta_rho_hat) .- (theta.rho .+ delta_rho)).^2 )

        matMSE_vdelta_alpha_hetero[i,k,l] = (post_mean_hetero.vdelta_alpha_hat - theta.vdelta_alpha)^2
        matMSE_vdelta_rho_hetero[i,k,l]   = (post_mean_hetero.vdelta_rho_hat - theta.vdelta_rho)^2
        matMSE_vdelta_sigma_hetero[i,k,l] = (post_mean_hetero.vdelta_sigma_hat - 1)^2

        mat_accp_rate_hetero[i,k,l] = post_mean_hetero.RWMH_accept_rate

    end
    println("Simulation for q = $(q_grid[k]), vdelta_alpha = $(vdelta_alpha_grid[l]) is done.")

end

####################################################################################################
#                             Part 3: CALCULATE MSE AND SAVE OUTPUT
####################################################################################################

# MSE for estimated α + δ^α_i
MSE_temp   = mapslices(mean, matMSE_alpha_ss_he, dims = 1)
MSE_alpha_ss_he = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_alpha_ss_ho, dims = 1)
MSE_alpha_ss_ho = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_alpha_ss_o, dims = 1)
MSE_alpha_ss_o  = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_alpha_homo, dims = 1)
MSE_alpha_homo   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_alpha_hetero, dims = 1)
MSE_alpha_hetero = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

# MSE for estimated ρ + δ^ρ_i
MSE_temp   = mapslices(mean, matMSE_rho_ss_he, dims = 1)
MSE_rho_ss_he = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_rho_ss_ho, dims = 1)
MSE_rho_ss_ho = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_rho_ss_o, dims = 1)
MSE_rho_ss_o  = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_rho_homo, dims = 1)
MSE_rho_homo   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_rho_hetero, dims = 1)
MSE_rho_hetero = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

# MSE for estimated variance of δ^α_i and δ^ρ_i
MSE_temp   = mapslices(mean, matMSE_vdelta_alpha_ss, dims = 1)
MSE_vdelta_alpha_ss   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_vdelta_rho_ss, dims = 1)
MSE_vdelta_rho_ss     = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_vdelta_sigma_ss, dims = 1)
MSE_vdelta_sigma_ss   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_vdelta_alpha_hetero, dims = 1)
MSE_vdelta_alpha_hetero = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_vdelta_rho_hetero, dims = 1)
MSE_vdelta_rho_hetero   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_vdelta_sigma_hetero, dims = 1)
MSE_vdelta_sigma_hetero   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

# Acceptance rate
MSE_temp   = mapslices(mean, mat_accp_rate_ss, dims = 1)
mat_avg_accp_rate_ss   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, mat_accp_rate_hetero, dims = 1)
mat_avg_accp_rate_hetero = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

save(wd_results * "Simulation_result_hetsk_N$(bign)_v$(data_version_id)_$(Dates.format(today(), "yymmdd")).jld2",
    "MSE_alpha_ss_he", MSE_alpha_ss_he,
    "MSE_alpha_ss_ho", MSE_alpha_ss_ho,
    "MSE_alpha_ss_o", MSE_alpha_ss_o,
    "MSE_alpha_homo", MSE_alpha_homo,
    "MSE_alpha_hetero", MSE_alpha_hetero,
    "MSE_rho_ss_he", MSE_rho_ss_he,
    "MSE_rho_ss_ho", MSE_rho_ss_ho,
    "MSE_rho_ss_o", MSE_rho_ss_o,
    "MSE_rho_homo", MSE_rho_homo,
    "MSE_rho_hetero", MSE_rho_hetero,
    "MSE_vdelta_alpha_ss",MSE_vdelta_alpha_ss,
    "MSE_vdelta_rho_ss",MSE_vdelta_rho_ss,
    "MSE_vdelta_sigma_ss",MSE_vdelta_sigma_ss,
    "MSE_vdelta_alpha_hetero",MSE_vdelta_alpha_hetero,
    "MSE_vdelta_rho_hetero",MSE_vdelta_rho_hetero,
    "MSE_vdelta_sigma_hetero",MSE_vdelta_sigma_hetero,
    "mat_avg_accp_rate_ss", mat_avg_accp_rate_ss,
    "mat_avg_accp_rate_hetero", mat_avg_accp_rate_hetero
    )


# Remove the additional workers
print("Removing workers...")
rmprocs(workers())
println("Done.")

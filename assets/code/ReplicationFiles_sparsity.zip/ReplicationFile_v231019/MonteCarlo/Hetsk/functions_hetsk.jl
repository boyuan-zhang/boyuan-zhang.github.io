## subfucntions for DGP4:  Heteroskedastic Dynamic Panel Data Model
# Creation: 11/29/2019
# Last Modification: 01/19/2022
##################################################################################

function generate_paneldata_hetsk(N, T, theta, data_version_id)
    # N = bign
    # T = bigt+1

    if data_version_id == 1 # different locations of nonzeros

        # draw delta_alpha_i for i = 1,...,N
        delta_alpha      = rand(Normal(0,sqrt(theta.vdelta_alpha)),N)
        id_nonzero_alpha = rand(Bernoulli(theta.q), N)
        zero_pos_alpha   = collect(1:N)[id_nonzero_alpha.== 0]
        delta_alpha[zero_pos_alpha] .= 0

        # draw delta_rho_i for i = 1,...,N
        delta_rho      = rand(Normal(0,sqrt(theta.vdelta_rho)),N)
        id_nonzero_rho = rand(Bernoulli(theta.q), N)
        zero_pos_rho   = collect(1:N)[id_nonzero_rho.== 0]
        delta_rho[zero_pos_rho] .= 0

        # draw delta_sigma_i for i = 1,...,N
        delta_sigma = rand(InverseGamma(theta.nu_delta_sigma/2, theta.tau_delta_sigma/2),N)
        id_nonzero = rand(Bernoulli(theta.q), N)
        zero_pos = collect(1:N)[id_nonzero.== 0]
        delta_sigma[zero_pos] .= 1 # not 0

    else # identical locations of nonzeros

        # draw delta_alpha_i for i = 1,...,N
        delta_alpha  = rand(Normal(0,sqrt(theta.vdelta_alpha)),N)
        # draw delta_rho_i for i = 1,...,N
        delta_rho    = rand(Normal(0,sqrt(theta.vdelta_rho)),N)
        # draw delta_sigma_i for i = 1,...,N
        delta_sigma = rand(InverseGamma(theta.nu_delta_sigma/2, theta.tau_delta_sigma/2),N)

        id_nonzero = rand(Bernoulli(theta.q), N)
        zero_pos = collect(1:N)[id_nonzero.== 0]
        delta_alpha[zero_pos] .= 0
        delta_rho[zero_pos]   .= 0
        delta_sigma[zero_pos] .= 1 # not 0

    end

    # draw u_it for i = 1,...,N, t = 1,...,T
    u = rand(Normal(0,1),T,N)

    # construct panel y
    y_all = Array{Float64,2}(undef,T+1,N)
    y_all[1,:] .= 0 # the first row corresponding to t = 0

    for i in 1:N, t in 2:(T+1)
        y_all[t,i] = theta.alpha + delta_alpha[i] + (theta.rho + delta_rho[i]) * y_all[t-1,i] + sqrt(theta.sigma2 * delta_sigma[i]) * u[t-1,i]
    end

    y_all = y_all[2:(T+1),:] # remove the first row

    return y_all, delta_alpha, delta_rho, delta_sigma, u
end







##################################################################################
# SS
function SS_hetsk(y_all, lambda, opt_ar, len_MCMC, data_version_id, id_simul)

    # len_MCMC = Int(5000)
    # id_simul = 1
    # c = 0.5

    len_MCMC = Int(len_MCMC)
    burnin = Int(floor(0.5*len_MCMC))+2

    y    = y_all[2:end,:]
    ylag = y_all[1:(end-1),:]

    T, N = size(y)

    # unload HP
    valpha, vrho, nu_sigma, tau_sigma, a, b, nu_vdelta_alpha, tau_vdelta_alpha, nu_vdelta_rho, tau_vdelta_rho, nu_vdelta_sigma, tau_vdelta_sigma = lambda

    Vbeta = [valpha 0; 0 vrho]

    # useful subfunctions
    crossprod(x) = x' * x
    g(x) = min(abs(x), 10) * sign(x) # helper function in adapative RWMH

    # some shortcuts
    xx = [crossprod([ones(T,1) ylag[:,ii]]) for ii in 1:N]

    if data_version_id == 1 # different locations of nonzeros

        q_alpha_draw      = zeros(len_MCMC+1)
        q_rho_draw        = zeros(len_MCMC+1)
        q_sigma_draw      = zeros(len_MCMC+1)
        beta_draw         = zeros(len_MCMC+1, 2) # β = [α, ρ]'
        vdelta_alpha_draw = zeros(len_MCMC+1)
        vdelta_rho_draw   = zeros(len_MCMC+1)
        vdelta_sigma_draw = zeros(len_MCMC+1)
        delta_alpha_draw  = zeros(len_MCMC+1, N)
        delta_rho_draw    = zeros(len_MCMC+1, N)
        delta_sigma_draw  = zeros(len_MCMC+1, N)
        z_alpha_draw      = zeros(len_MCMC+1, N)
        z_rho_draw        = zeros(len_MCMC+1, N)
        z_sigma_draw      = zeros(len_MCMC+1, N)
        sigma2_draw       = zeros(len_MCMC+1)

        # RWMH
        c_vdelta_sigma = zeros(len_MCMC+1) # random walk step size
        RWMH_accept_record  = zeros(len_MCMC+1) # record acceptance status

        ### initialize parameters
        # σ^2
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
        sigma2_draw[1]   = mean(InverseGamma(nu_sigma/2, tau_sigma/2))

        # q
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
        q_alpha_draw[1]  = mean(Beta(a,b))
        q_rho_draw[1]    = mean(Beta(a,b))
        q_sigma_draw[1]  = mean(Beta(a,b))

        # v_δ
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )
        vdelta_alpha_draw[1] = mean(InverseGamma(nu_vdelta_alpha/2, tau_vdelta_alpha/2))
        vdelta_rho_draw[1]   = mean(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))
        vdelta_sigma_draw[1] = mean(InverseGamma(nu_vdelta_sigma/2, tau_vdelta_sigma/2))

        # (z,δ)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

        z_alpha_draw[1,:] = rand(Bernoulli(q_alpha_draw[1]), N)
        z_rho_draw[1,:]   = rand(Bernoulli(q_rho_draw[1]), N)
        z_sigma_draw[1,:] = rand(Bernoulli(q_sigma_draw[1]), N)

        zero_pos_alpha    = collect(1:N)[z_alpha_draw[1,:] .== 0]
        zero_pos_rho      = collect(1:N)[z_rho_draw[1,:] .== 0]
        zero_pos_sigma    = collect(1:N)[z_sigma_draw[1,:] .== 0]

        delta_alpha_draw[1,:] = rand(Normal(0, sqrt(vdelta_alpha_draw[1])), N)
        delta_alpha_draw[1,zero_pos_alpha] .= 0

        delta_rho_draw[1,:]   = rand(Normal(0, sqrt(vdelta_rho_draw[1])), N)
        delta_rho_draw[1,zero_pos_rho]     .= 0

        delta_sigma_draw[1,:] = rand(InverseGamma(1/vdelta_sigma_draw[1]+2, 1/vdelta_sigma_draw[1]+1), N)
        delta_sigma_draw[1,zero_pos_sigma] .= 1

        # c
        c_vdelta_sigma[1] = 1

        for i = 2:len_MCMC+1

            ###################################################
            ### BLOCK 1: draw β
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

            sigma2_i = sigma2_draw[i-1] * delta_sigma_draw[i-1,:]

            sum_in_var_beta = sum(sigma2_i[ii]^-1 * xx[ii] for ii in 1:N) # sum_i^N sigma_i^-2 * (x_i'x_i)
            vbeta_post = ( inv(Vbeta) + sum_in_var_beta )^-1 # posterior variance of β

            sum_in_mean_beta = sum(sigma2_i[ii]^-1 * [ones(T,1) ylag[:,ii]]' *
                                    (y[:,ii] - [ones(T,1) ylag[:,ii]] * [delta_alpha_draw[i-1,ii]; delta_rho_draw[i-1,ii]]) for ii in 1:N)
            mean_beta_post = vbeta_post * sum_in_mean_beta

            beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

            alpha = beta_draw[i,1]
            rho   = beta_draw[i,2]

            ###################################################
            ### BLOCK 2: draw q
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

            psi_alpha       = sum( z_alpha_draw[i-1,:] )
            psi_rho         = sum( z_rho_draw[i-1,:] )
            psi_sigma       = sum( z_sigma_draw[i-1,:] )

            q_alpha_draw[i] = rand( Beta(a + psi_alpha, b + N - psi_alpha) )
            q_rho_draw[i]   = rand( Beta(a + psi_rho,   b + N - psi_rho) )
            q_sigma_draw[i] = rand( Beta(a + psi_sigma, b + N - psi_sigma) )


            ###################################################
            ### BLOCK 3: draw variance for δ^α and δ^ρ
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

            ### δ^α
            nu_vdelta_alpha_post  = nu_vdelta_alpha + psi_alpha
            tau_vdelta_alpha_post = tau_vdelta_alpha + sum(delta_alpha_draw[i-1, z_alpha_draw[i-1,:] .== 1].^2)

            vdelta_alpha_draw[i] = rand(InverseGamma(nu_vdelta_alpha_post/2, tau_vdelta_alpha_post/2))

            ### δ^ρ
            nu_vdelta_rho_post  = nu_vdelta_rho + psi_rho
            tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_rho_draw[i-1,:] .== 1].^2)

            vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

            ### δ^σ
            # log posterior of ω (will be used in RWMH)
            delta_sigma_slab = delta_sigma_draw[i-1, z_sigma_draw[i-1,:] .== 1]
            log_post_omega(x) = psi_sigma*(1/x+2)*log(1/x+1) - psi_sigma*loggamma(1/x+2) - (nu_vdelta_sigma/2+1)*log(x) - 1/x*(sum(log.(delta_sigma_slab)) + sum(delta_sigma_slab.^-1) + tau_vdelta_sigma/2 )

            ### Random Walk Metropolis Hastings
            c_i = c_vdelta_sigma[i-1]
            # draw from truncated normal bounded below by 0
            RWMH_draw = rand(truncated(Normal(vdelta_sigma_draw[i-1], c_i), lower = 0))

            # calculate acceptance rate
            diff_log_post = log_post_omega(RWMH_draw) - log_post_omega(vdelta_sigma_draw[i-1])
            diff_log_CDF  = log(cdf(Normal(0, sqrt(c_i)), RWMH_draw)) - log(cdf(Normal(0, sqrt(c_i)), vdelta_sigma_draw[i-1]))

            prob_RWMH = min(1, exp(diff_log_post - diff_log_CDF))

            RWMH_accept = rand(Bernoulli(prob_RWMH))

            if RWMH_accept
                vdelta_sigma_draw[i] = RWMH_draw
                RWMH_accept_record[i] = 1
            else
                vdelta_sigma_draw[i] = vdelta_sigma_draw[i-1]
                RWMH_accept_record[i] = 0
            end

            # update random walk step size
            log_c = g( log(c_vdelta_sigma[i-1]) + i^(-0.55) * (prob_RWMH - opt_ar) )
            c_vdelta_sigma[i] = exp(log_c)


            ###################################################
            ### BLOCK 3: draw (z,δ)
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

            ### draw z_alpha
            # posterior mean and variance of delta_alpha_i
            post_var_delta_alpha  = (vdelta_alpha_draw[i]^-1 .+ T * sigma2_i.^-1).^-1
            post_mean_delta_alpha = [post_var_delta_alpha[ii] * sigma2_i[ii]^-1 *
                                    sum(y[:,ii] .- alpha .- (rho .+ delta_rho_draw[i-1,ii]) * ylag[:,ii]) for ii in 1:N]

            K_alpha = q_alpha_draw[i] / (1-q_alpha_draw[i]) * (vdelta_alpha_draw[i] ./ post_var_delta_alpha).^(-0.5) .*
                        exp.(0.5*post_mean_delta_alpha.^2 ./ post_var_delta_alpha)

            if sum(K_alpha .== Inf) != 0
                Inf_pos = collect(1:N)[K_alpha .== Inf]
                K_alpha[Inf_pos] .= 10^8
            end

            prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1

            z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

            ### draw δ_alpha
            zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

            delta_alpha_draw[i,:] = [rand(Normal(post_mean_delta_alpha[ii], sqrt(post_var_delta_alpha[ii]))) for ii in 1:N]

            if length(zero_alpha_pos) != 0
                delta_alpha_draw[i, zero_alpha_pos] .= 0
            end

            ### draw z_rho
            # posterior mean and variance of delta_alpha_i
            post_var_delta_rho  = [ (vdelta_rho_draw[i]^-1 + sigma2_i[ii]^-1 * sum(ylag[:,ii].^2) )^-1 for ii in 1:N]

            post_mean_delta_rho = [ post_var_delta_rho[ii] * sigma2_i[ii]^-1 *
                                    sum( ylag[:,ii] .* (y[:,ii] .- alpha .- delta_alpha_draw[i,ii] - rho * ylag[:,ii])) for ii in 1:N ]

            K_rho = q_rho_draw[i] / (1-q_rho_draw[i]) * (vdelta_rho_draw[i] ./ post_var_delta_rho).^(-0.5) .*
                    exp.( 0.5*post_mean_delta_rho.^2 ./ post_var_delta_rho )

            if sum(K_rho .== Inf) != 0
                Inf_pos = collect(1:N)[K_rho .== Inf]
                K_rho[Inf_pos] .= 10^8
            end

            prob_rho = K_rho ./ (1 .+ K_rho) # probability of model 1

            z_rho_draw[i,:] = [rand(Bernoulli(x)) for x in prob_rho]

            ### draw δ_rho
            zero_rho_pos = collect(1:N)[z_rho_draw[i,:] .== 0]

            delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

            if length(zero_rho_pos) != 0
                delta_rho_draw[i,zero_rho_pos] .= 0
            end

            ### draw z_sigma
            sum_y_sigma_sq = [crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta_draw[i,:] +
                                    [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N]

            # parameters in posterior of δ^σ
            nu_delta_sigma_post  = 2*vdelta_sigma_draw[i]^(-1) + 4 + T
            tau_delta_sigma_post = 2*vdelta_sigma_draw[i]^(-1) + 2 .+ sigma2_draw[i-1]^-1 * sum_y_sigma_sq

            # posterior odd
            exp_part = exp.(0.5*sigma2_draw[i-1]^-1 * sum_y_sigma_sq)
            Const    = gamma(nu_delta_sigma_post/2) / gamma(vdelta_sigma_draw[i]^(-1)+2) .*
                        (vdelta_sigma_draw[i]^(-1)+1).^(vdelta_sigma_draw[i]^(-1)+2) ./ (tau_delta_sigma_post/2).^(nu_delta_sigma_post/2)
            K_sigma  = q_sigma_draw[i] / (1-q_sigma_draw[i]) * Const .* exp_part

            if sum(K_sigma .== Inf) != 0
                Inf_pos = collect(1:N)[K_sigma .== Inf]
                K_sigma[Inf_pos] .= 10^8
            end

            prob_sigma = K_sigma ./ (1 .+ K_sigma) # probability of model 1

            if sum( zero(prob_sigma) .<= prob_sigma .<= one.(prob_sigma) ) < size(prob_sigma)[1]
                @show prob_sigma
                @show alpha
                @show sigma
                @show K_sigma
                @show q_sigma_draw[i]
                @show sigma2_draw[(i-1)]
                @show delta_sigma_draw[i-1,:]
            end

            z_sigma_draw[i,:] = [rand(Bernoulli(x)) for x in prob_sigma]

            ### draw δ_sigma
            zero_sigma_pos = collect(1:N)[z_sigma_draw[i,:] .== 0]

            delta_sigma_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_post/2, tau_delta_sigma_post[ii]/2)) for ii in 1:N]

            if length(zero_sigma_pos) != 0
                delta_sigma_draw[i,zero_sigma_pos] .= 1
            end

            ###################################################
            ### BLOCK 4: draw σ^2
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

            nu_sigma_post  = nu_sigma + N*T
            tau_sigma_post = tau_sigma + sum( delta_sigma_draw[i,ii]^-1 * crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta_draw[i,:] +
                            [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N)

            sigma2_draw[i] = rand(InverseGamma(nu_sigma_post/2, tau_sigma_post/2))

            # print(i)
        end

        # posteriod mean
        alpha_hat        = mean( beta_draw[burnin:end,1] )
        rho_hat          = mean( beta_draw[burnin:end,2] )
        sigma2_hat       = mean( sigma2_draw[burnin:end] )
        delta_alpha_hat  = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
        delta_rho_hat    = mean( delta_rho_draw[burnin:end,:], dims = 1)'
        delta_sigma_hat  = mean( delta_sigma_draw[burnin:end,:], dims = 1)'
        z_alpha_hat      = mean( z_alpha_draw[burnin:end,:], dims = 1)'
        z_rho_hat        = mean( z_rho_draw[burnin:end,:], dims = 1)'
        z_sigma_hat      = mean( z_sigma_draw[burnin:end,:], dims = 1)'
        q_alpha_hat      = mean( q_alpha_draw[burnin:end] )
        q_rho_hat        = mean( q_rho_draw[burnin:end] )
        q_sigma_hat      = mean( q_sigma_draw[burnin:end] )
        vdelta_alpha_hat = mean( vdelta_alpha_draw[burnin:end] )
        vdelta_rho_hat   = mean( vdelta_rho_draw[burnin:end] )
        vdelta_sigma_hat = mean( vdelta_sigma_draw[burnin:end] )

        post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_hat = sigma2_hat,
                     delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat, delta_sigma_hat = delta_sigma_hat,
                     vdelta_alpha_hat = vdelta_alpha_hat, vdelta_rho_hat = vdelta_rho_hat, vdelta_sigma_hat = vdelta_sigma_hat,
                     z_alpha_hat = z_alpha_hat, z_rho_hat = z_rho_hat, z_sigma_hat = z_sigma_hat,
                     q_alpha_hat = q_alpha_hat, q_rho_hat = q_rho_hat, q_sigma_hat = q_sigma_hat,
                     RWMH_accept_rate = mean(RWMH_accept_record[burnin:end]))

        post_draw = (alpha_draw = beta_draw[burnin:end,1], rho_draw = beta_draw[burnin:end,2], sigma2_draw = sigma2_draw[burnin:end],
                     delta_alpha_draw = delta_alpha_draw[burnin:end,:], delta_rho_draw = delta_rho_draw[burnin:end,:], delta_sigma_draw = delta_sigma_draw[burnin:end,:],
                     z_alpha_draw = z_alpha_draw[burnin:end,:], z_rho_draw = z_rho_draw[burnin:end,:], z_sigma_draw = z_sigma_draw[burnin:end,:],
                     q_alpha_draw = q_alpha_draw[burnin:end], q_rho_draw = q_rho_draw[burnin:end], q_sigma_draw = q_sigma_draw[burnin:end],
                     c_vdelta_sigma = c_vdelta_sigma,
                     RWMH_accept_record = RWMH_accept_record[burnin:end])

        return post_mean, post_draw



    elseif data_version_id == 2 # identical locations of nonzeros

        q_draw           = zeros(len_MCMC+1)
        beta_draw        = zeros(len_MCMC+1, 2) # β = [α, ρ]'
        delta_alpha_draw = zeros(len_MCMC+1, N)
        delta_rho_draw   = zeros(len_MCMC+1, N)
        delta_sigma_draw = zeros(len_MCMC+1, N)
        z_draw           = zeros(len_MCMC+1, N)
        sigma2_draw      = zeros(len_MCMC+1)

        ### initialize parameters
        # sigma2
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )
        sigma2_draw[1]   = mean(InverseGamma(s/2, vsigma/2))

        # q
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
        q_draw[1] = mean(Beta(a,b))

        # (z,δ)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )

        z_draw[1,:] = rand(Bernoulli(q_draw[1]), N)

        zero_pos    = collect(1:N)[z_draw[1,:] .== 0]

        var_delta_alpha0  = (vdelta_alpha^-1 + N * sigma2_draw[1]^-1)^-1

        delta_alpha_draw[1,:] = rand(Normal(0, sqrt(var_delta_alpha0)), N)
        delta_alpha_draw[1,zero_pos] .= 0

        delta_rho_draw[1,:]   = [rand(Normal(0, sqrt( (vdelta_rho^-1 + sigma2_draw[1]^-1 * sum(ylag[t,ii]^2 for t in 1:T))^-1)) ) for ii in 1:N]
        delta_rho_draw[1,zero_pos] .= 0

        delta_sigma_draw[1,:] = rand(Normal(mudelta_sigma, sqrt(c^2*vdelta_sigma)), N)
        delta_sigma_draw[1,zero_pos] .= 0

        RWMH_accept_record = zeros(len_MCMC,N)

        for i = 2:len_MCMC+1

            ###################################################
            ### BLOCK 1: draw β
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

            sigma2_i = sigma2_draw[i-1] * exp.(2*delta_sigma_draw[i-1,:])

            sum_in_var_beta = sum(sigma2_i[ii]^-1 * xx[ii] for ii in 1:N) # sum_i^N (x_i'x_i)

            vbeta_post = ( inv(Vbeta) + sum_in_var_beta )^-1 # posterior variance of β

            sum_in_mean_beta = sum(sigma2_i[ii]^-1 * [ones(T,1) ylag[:,ii]]' *
                                    (y[:,ii] - [ones(T,1) ylag[:,ii]] * [delta_alpha_draw[i-1,ii]; delta_rho_draw[i-1,ii]]) for ii in 1:N)
            mean_beta_post = vbeta_post * sum_in_mean_beta

            beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

            alpha = beta_draw[i,1]
            rho   = beta_draw[i,2]

            ###################################################
            ### BLOCK 2: draw q
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

            tau       = sum( z_draw[i-1,:] )
            q_draw[i] = rand( Beta(a + tau, b + N - tau) )


            ###################################################
            ### BLOCK 3: draw (z,δ)
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

            ### draw z
            K = zeros(N,1) # posterior odds of model 1 vs model 0


            # components of K_sigma

            exp_part = exp.( (2*sigma2_draw[i-1])^-1 * [crossprod(y[:,ii] .- alpha - rho * ylag[:,ii]) for ii in 1:N] )

            # integrand

            # some shortcuts
            yy_residual = [crossprod( (y[:,ii] .- alpha - rho * ylag[:,ii]) ) for ii in 1:N]
            xy_nodelta = [[ones(T,1) ylag[:,ii]]' * (y[:,ii] .- alpha - rho * ylag[:,ii]) for ii in 1:N]

            f(x) = [ det( Vdelta^-1 + (sigma2_draw[i-1]*exp(2*x))^-1 * xx[ii] )^-0.5 *
                     exp( - yy_residual[ii] / (2*sigma2_draw[i-1]*exp(2*x))
                          + 0.5 * (sigma2_draw[i-1] * exp(2*x))^-2
                                * xy_nodelta[ii]'
                                * (Vdelta^-1 + (sigma2_draw[i-1] * exp(2*x))^-1 * xx[ii])^-1
                                * xy_nodelta[ii]
                          - T*x
                          - (x - mudelta_sigma)^2/(2*vdelta_sigma)) for ii in 1:N]

            C_i = quadgk(f, -10, 10, rtol = 1e-3)
            C_i = C_i[1]

            K = q_draw[i] / (1 - q_draw[i]) * (2*pi * vdelta_alpha * det(Vdelta))^-0.5 .* C_i .* exp_part


            if sum(K .== Inf) != 0
                Inf_pos = collect(1:N)[K .== Inf]
                K[Inf_pos] .= 10^8
            end

            prob = K ./ (1 .+ K) # probability of model 1

            z_draw[i,:] = [rand(Bernoulli(x)) for x in prob]
            zero_pos = collect(1:N)[z_draw[i,:] .== 0]

            ## draw δ_alpha and δ_rho

            # posterior mean and variance of delta_alpha_i and delta_rho_i
            post_var_delta  = [ ( Vdelta^-1 + sigma2_i[ii]^-1 * xx[ii] )^-1  for ii in 1:N ]

            post_mean_delta = [ post_var_delta[ii] * sigma2_i[ii]^-1 * [ones(T,1) ylag[:,ii]]' *
                                (y[:,ii] - [ones(T,1) ylag[:,ii]] * beta_draw[i,:])
                                for ii in 1:N ]

            delta_draw = [ rand(MvNormal(post_mean_delta[ii], Symmetric(post_var_delta[ii]))) for ii in 1:N ]

            delta_alpha_draw[i,:] = [delta_draw[ii][1] for ii in 1:N]
            delta_rho_draw[i,:]   = [delta_draw[ii][2] for ii in 1:N]

            if length(zero_pos) != 0
                delta_alpha_draw[i, zero_pos] .= 0
                delta_rho_draw[i, zero_pos]   .= 0
            end

            ## draw δ_sigma

            # Random Walk Metropolis Hastings Step
            RWMH_draw = [rand(Normal(delta_sigma_draw[i-1,ii], sqrt(c^2*vdelta_sigma))) for ii in 1:N]

            prob_RWMH = zeros(N,1)

            # evaluate at new draw and previous draw
            for ii = 1:N
                log_lik_prior(x) = (- T*x
                                    - sum( (y[:,ii] .- alpha .- delta_alpha_draw[i,ii] - (rho + delta_rho_draw[i,ii]) *
                                    ylag[:,ii]).^2 ) / (2*sigma2_draw[i-1]*exp(2*x))
                                    - (x - mudelta_sigma)^2/(2*vdelta_sigma))
                prob_RWMH[ii] = min( 1, exp( log_lik_prior(RWMH_draw[ii]) - log_lik_prior(delta_sigma_draw[i-1,ii]) ) )
            end

            RWMH_accept = [rand(Bernoulli(x)) for x in prob_RWMH]
            RWMH_accept_record[i-1,:] = RWMH_accept  #record acceptance rate
            RWMH_reject_pos = collect(1:N)[RWMH_accept[:,1] .== 0]

            delta_sigma_draw[i,:] = RWMH_draw
            delta_sigma_draw[i, RWMH_reject_pos] = delta_sigma_draw[i-1, RWMH_reject_pos]

            if length(zero_pos) != 0
                delta_sigma_draw[i, zero_pos] .= 0
            end

            ###################################################
            ### BLOCK 4: draw σ^2
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

            s_post = s + N*T
            vsigma_post = vsigma + sum( exp(-2*delta_sigma_draw[i,ii]) * crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta_draw[i,:] +
                            [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N)

            sigma2_draw[i] = rand(InverseGamma(s_post/2, vsigma_post/2))

            # print(i)
        end

        RWMH_accept_rate = mean( RWMH_accept_record, dims = 1)'

        # posteriod mean
        alpha_hat       = mean( beta_draw[burnin:end,1] )
        rho_hat         = mean( beta_draw[burnin:end,2] )
        sigma2_hat      = mean( sigma2_draw[burnin:end] )
        delta_alpha_hat = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
        delta_rho_hat   = mean( delta_rho_draw[burnin:end,:], dims = 1)'
        delta_sigma_hat = mean( delta_sigma_draw[burnin:end,:], dims = 1)'
        z_hat           = mean( z_draw[burnin:end,:], dims = 1)'
        q_hat           = q_draw[1:end]

        return alpha_hat, rho_hat, sigma2_hat, delta_alpha_hat, delta_rho_hat, delta_sigma_hat,
               z_hat, q_hat, RWMH_accept_rate

    end

end












##################################################################################
# SS - Oracle
function SS_hetsk_oracle(y_all, lambda, theta, len_MCMC, data_version_id, id_simul)

    # len_MCMC = Int(5000)
    # id_simul = 1
    # c = 0.5

    len_MCMC = Int(len_MCMC)
    burnin = Int(floor(0.5*len_MCMC))+2

    y    = y_all[2:end,:]
    ylag = y_all[1:(end-1),:]

    T, N = size(y)

    # unload HP
    valpha, vrho, nu_sigma, tau_sigma, a, b, nu_vdelta_alpha, tau_vdelta_alpha, nu_vdelta_rho, tau_vdelta_rho, nu_vdelta_sigma, tau_vdelta_sigma = lambda

    Vbeta = [valpha 0; 0 vrho]

    # unload homo parameters
    alpha, rho, sigma2, q, vdelta_alpha, vdelta_rho, nu_delta_sigma, tau_delta_sigma = theta

    # useful subfunctions
    crossprod(x) = x' * x

    # some shortcuts
    xx = [crossprod([ones(T,1) ylag[:,ii]]) for ii in 1:N]

    if data_version_id == 1 # different locations of nonzeros

        delta_alpha_draw  = zeros(len_MCMC+1, N)
        delta_rho_draw    = zeros(len_MCMC+1, N)
        delta_sigma_draw  = zeros(len_MCMC+1, N)
        z_alpha_draw      = zeros(len_MCMC+1, N)
        z_rho_draw        = zeros(len_MCMC+1, N)
        z_sigma_draw      = zeros(len_MCMC+1, N)

        ### initialize parameters

        # (z,δ)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

        z_alpha_draw[1,:] = rand(Bernoulli(q), N)
        z_rho_draw[1,:]   = rand(Bernoulli(q), N)
        z_sigma_draw[1,:] = rand(Bernoulli(q), N)

        zero_pos_alpha    = collect(1:N)[z_alpha_draw[1,:] .== 0]
        zero_pos_rho      = collect(1:N)[z_rho_draw[1,:] .== 0]
        zero_pos_sigma    = collect(1:N)[z_sigma_draw[1,:] .== 0]

        delta_alpha_draw[1,:] = rand(Normal(0, sqrt(vdelta_alpha)), N)
        delta_alpha_draw[1,zero_pos_alpha] .= 0

        delta_rho_draw[1,:]   = rand(Normal(0, sqrt(vdelta_rho)), N)
        delta_rho_draw[1,zero_pos_rho]     .= 0

        delta_sigma_draw[1,:] = rand(InverseGamma(nu_delta_sigma/2, tau_delta_sigma/2), N)
        delta_sigma_draw[1,zero_pos_sigma] .= 1

        for i = 2:len_MCMC+1

            sigma2_i = sigma2 * delta_sigma_draw[i-1,:]
            beta = [alpha; rho]

            ###################################################
            ### BLOCK 3: draw (z,δ)
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

            ### draw z_alpha
            # posterior mean and variance of delta_alpha_i
            post_var_delta_alpha  = (vdelta_alpha^-1 .+ T * sigma2_i.^-1).^-1
            post_mean_delta_alpha = [post_var_delta_alpha[ii] * sigma2_i[ii]^-1 *
                                    sum(y[:,ii] .- alpha .- (rho .+ delta_rho_draw[i-1,ii]) * ylag[:,ii]) for ii in 1:N]

            K_alpha = q / (1-q) * (vdelta_alpha ./ post_var_delta_alpha).^(-0.5) .*
                        exp.(0.5*post_mean_delta_alpha.^2 ./ post_var_delta_alpha)

            if sum(K_alpha .== Inf) != 0
                Inf_pos = collect(1:N)[K_alpha .== Inf]
                K_alpha[Inf_pos] .= 10^8
            end

            prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1

            z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

            ### draw δ_alpha
            zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

            delta_alpha_draw[i,:] = [rand(Normal(post_mean_delta_alpha[ii], sqrt(post_var_delta_alpha[ii]))) for ii in 1:N]

            if length(zero_alpha_pos) != 0
                delta_alpha_draw[i, zero_alpha_pos] .= 0
            end

            ### draw z_rho
            # posterior mean and variance of delta_alpha_i
            post_var_delta_rho  = [ (vdelta_rho^-1 + sigma2_i[ii]^-1 * sum(ylag[:,ii].^2) )^-1 for ii in 1:N]

            post_mean_delta_rho = [ post_var_delta_rho[ii] * sigma2_i[ii]^-1 *
                                    sum( ylag[:,ii] .* (y[:,ii] .- alpha .- delta_alpha_draw[i,ii] - rho * ylag[:,ii])) for ii in 1:N ]

            K_rho = q / (1-q) * (vdelta_rho ./ post_var_delta_rho).^(-0.5) .*
                    exp.( 0.5*post_mean_delta_rho.^2 ./ post_var_delta_rho )

            if sum(K_rho .== Inf) != 0
                Inf_pos = collect(1:N)[K_rho .== Inf]
                K_rho[Inf_pos] .= 10^8
            end

            prob_rho = K_rho ./ (1 .+ K_rho) # probability of model 1

            z_rho_draw[i,:] = [rand(Bernoulli(x)) for x in prob_rho]

            ### draw δ_rho
            zero_rho_pos = collect(1:N)[z_rho_draw[i,:] .== 0]

            delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

            if length(zero_rho_pos) != 0
                delta_rho_draw[i,zero_rho_pos] .= 0
            end

            ### draw z_sigma
            sum_y_sigma_sq = [crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta + [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N]

            # parameters in posterior of δ^σ
            nu_delta_sigma_post  = nu_delta_sigma + T
            tau_delta_sigma_post = tau_delta_sigma .+ sigma2^-1 * sum_y_sigma_sq

            # posterior odd
            exp_part = exp.(0.5*sigma2^-1 * sum_y_sigma_sq)
            Const    = gamma(nu_delta_sigma_post/2) / gamma(nu_delta_sigma/2) .*
                        (tau_delta_sigma/2).^(nu_delta_sigma/2) ./ (tau_delta_sigma_post/2).^(nu_delta_sigma_post/2)
            K_sigma  = q / (1-q) * Const .* exp_part

            if sum(K_sigma .== Inf) != 0
                Inf_pos = collect(1:N)[K_sigma .== Inf]
                K_sigma[Inf_pos] .= 10^8
            end

            prob_sigma = K_sigma ./ (1 .+ K_sigma) # probability of model 1

            z_sigma_draw[i,:] = [rand(Bernoulli(x)) for x in prob_sigma]

            ### draw δ_sigma
            zero_sigma_pos = collect(1:N)[z_sigma_draw[i,:] .== 0]

            delta_sigma_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_post/2, tau_delta_sigma_post[ii]/2)) for ii in 1:N]

            if length(zero_sigma_pos) != 0
                delta_sigma_draw[i,zero_sigma_pos] .= 1
            end

            # print(i)
        end

        # posteriod mean
        delta_alpha_hat  = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
        delta_rho_hat    = mean( delta_rho_draw[burnin:end,:], dims = 1)'
        delta_sigma_hat  = mean( delta_sigma_draw[burnin:end,:], dims = 1)'
        z_alpha_hat      = mean( z_alpha_draw[burnin:end,:], dims = 1)'
        z_rho_hat        = mean( z_rho_draw[burnin:end,:], dims = 1)'
        z_sigma_hat      = mean( z_sigma_draw[burnin:end,:], dims = 1)'


        post_mean = (delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat, delta_sigma_hat = delta_sigma_hat,
                     z_alpha_hat = z_alpha_hat, z_rho_hat = z_rho_hat, z_sigma_hat = z_sigma_hat)

        post_draw = (delta_alpha_draw = delta_alpha_draw[burnin:end,:], delta_rho_draw = delta_rho_draw[burnin:end,:], delta_sigma_draw = delta_sigma_draw[burnin:end,:],
                     z_alpha_draw = z_alpha_draw[burnin:end,:], z_rho_draw = z_rho_draw[burnin:end,:], z_sigma_draw = z_sigma_draw[burnin:end,:])

        return post_mean, post_draw



    elseif data_version_id == 2 # identical locations of nonzeros



    end

end









### ################################################################################
# SS - Homoskedastic
function SS_homsk(y_all, lambda, len_MCMC, data_version_id, id_simul)

    # len_MCMC = Int(2000)
    # id_simul = 1

    len_MCMC = Int(len_MCMC)
    burnin = Int(floor(0.5*len_MCMC))+2

    y    = y_all[2:end,:]
    ylag = y_all[1:(end-1),:]

    T, N = size(y)

    # unload HP
    valpha, vrho, nu_sigma, tau_sigma, a, b, nu_vdelta_alpha, tau_vdelta_alpha, nu_vdelta_rho, tau_vdelta_rho, nu_vdelta_sigma, tau_vdelta_sigma = lambda

    Vbeta = [valpha 0; 0 vrho]

    # useful subfunctions
    crossprod(x) = x' * x

    # some shortcuts
    xx = [crossprod([ones(T,1) ylag[:,ii]]) for ii in 1:N]

    if data_version_id == 1 # different locations of nonzeros

        q_alpha_draw      = zeros(len_MCMC+1)
        q_rho_draw        = zeros(len_MCMC+1)
        beta_draw         = zeros(len_MCMC+1, 2) # β = [α, ρ]'
        vdelta_alpha_draw = zeros(len_MCMC+1)
        vdelta_rho_draw   = zeros(len_MCMC+1)
        delta_alpha_draw  = zeros(len_MCMC+1, N)
        delta_rho_draw    = zeros(len_MCMC+1, N)
        z_alpha_draw      = zeros(len_MCMC+1, N)
        z_rho_draw        = zeros(len_MCMC+1, N)
        sigma2_draw       = zeros(len_MCMC+1)

        ### initialize parameters
        # σ^2
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
        sigma2_draw[1]   = mean(InverseGamma(nu_sigma/2, tau_sigma/2))

        # q
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
        q_alpha_draw[1]  = mean(Beta(a,b))
        q_rho_draw[1]    = mean(Beta(a,b))

        # v_δ
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )
        vdelta_alpha_draw[1] = mean(InverseGamma(nu_vdelta_alpha/2, tau_vdelta_alpha/2))
        vdelta_rho_draw[1]   = mean(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))

        # (z,δ)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

        z_alpha_draw[1,:] = rand(Bernoulli(q_alpha_draw[1]), N)
        z_rho_draw[1,:]   = rand(Bernoulli(q_rho_draw[1]), N)

        zero_pos_alpha    = collect(1:N)[z_alpha_draw[1,:] .== 0]
        zero_pos_rho      = collect(1:N)[z_rho_draw[1,:] .== 0]

        delta_alpha_draw[1,:] = rand(Normal(0, sqrt(vdelta_alpha_draw[1])), N)
        delta_alpha_draw[1,zero_pos_alpha] .= 0

        delta_rho_draw[1,:]   = rand(Normal(0, sqrt(vdelta_rho_draw[1])), N)
        delta_rho_draw[1,zero_pos_rho]     .= 0

        sum_in_var_beta = sum(xx[ii] for ii in 1:N) # sum_i^N (x_i'x_i)

        for i = 2:len_MCMC+1

            ###################################################
            ### BLOCK 1: draw β
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

            vbeta_post = ( inv(Vbeta) + sigma2_draw[i-1]^-1 * sum_in_var_beta )^-1 # posterior variance of β

            sum_in_mean_beta = sum([ones(T,1) ylag[:,ii]]' *
                                    (y[:,ii] - [ones(T,1) ylag[:,ii]] * [delta_alpha_draw[i-1,ii]; delta_rho_draw[i-1,ii]]) for ii in 1:N)
            mean_beta_post = vbeta_post * sigma2_draw[i-1]^-1 * sum_in_mean_beta

            beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

            alpha = beta_draw[i,1]
            rho   = beta_draw[i,2]

            ###################################################
            ### BLOCK 2: draw q
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

            psi_alpha       = sum( z_alpha_draw[i-1,:] )
            psi_rho         = sum( z_rho_draw[i-1,:] )
            q_alpha_draw[i] = rand( Beta(a + psi_alpha, b + N - psi_alpha) )
            q_rho_draw[i]   = rand( Beta(a + psi_rho, b + N - psi_rho) )

            ###################################################
            ### BLOCK 3: draw variance for δ^α and δ^ρ
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

            # δ^α
            nu_vdelta_alpha_post  = nu_vdelta_alpha + psi_alpha
            tau_vdelta_alpha_post = tau_vdelta_alpha + sum(delta_alpha_draw[i-1, z_alpha_draw[i-1,:] .== 1].^2)

            vdelta_alpha_draw[i] = rand(InverseGamma(nu_vdelta_alpha_post/2, tau_vdelta_alpha_post/2))

            # δ^ρ
            nu_vdelta_rho_post  = nu_vdelta_rho + psi_rho
            tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_rho_draw[i-1,:] .== 1].^2)

            vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

            ###################################################
            ### BLOCK 4: draw (z,δ)
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

            # draw z_alpha

            # posterior mean and variance of delta_alpha_i
            post_var_delta_alpha  = (vdelta_alpha_draw[i]^-1 + T * sigma2_draw[i-1]^-1)^-1
            post_mean_delta_alpha = [post_var_delta_alpha * sigma2_draw[i-1]^-1 *
                                    sum(y[:,ii] .- alpha .- (rho .+ delta_rho_draw[i-1,ii]) * ylag[:,ii]) for ii in 1:N]

            K_alpha = q_alpha_draw[i] / (1-q_alpha_draw[i]) * (vdelta_alpha_draw[i] / post_var_delta_alpha)^(-0.5) *
                        exp.(0.5*post_mean_delta_alpha.^2 / post_var_delta_alpha)

            if sum(K_alpha .== Inf) != 0
                Inf_pos = collect(1:N)[K_alpha .== Inf]
                K_alpha[Inf_pos] .= 10^8
            end

            prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1

            # prob_alpha = zero(prob_alpha) .+ 1 # uncommment this line if want to keep all delta_alpha
            # prob_alpha = zero(prob_alpha) # uncommment this line if want to shut down delta_alpha

            if sum( zero(prob_alpha) .<= prob_alpha .<= one.(prob_alpha) ) < size(prob_alpha)[1]
                @show prob_alpha
                @show K_alpha
                @show q_alpha_draw[i]
                @show sigma2_draw[(i-1)]
                @show delta_alpha_draw[i-1,:]
                @show delta_rho_draw[i-1,:]
            end

            z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

            # draw δ_alpha
            zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

            delta_alpha_draw[i,:] = [rand(Normal(post_mean_delta_alpha[ii], sqrt(post_var_delta_alpha))) for ii in 1:N]

            if length(zero_alpha_pos) != 0
                delta_alpha_draw[i,zero_alpha_pos] .= 0
            end

            # draw z_rho
            # posterior mean and variance of delta_alpha_i
            post_var_delta_rho  = [ (vdelta_rho_draw[i]^-1 + sigma2_draw[i-1]^-1 * sum(ylag[:,ii].^2) )^-1 for ii in 1:N]

            post_mean_delta_rho = [ post_var_delta_rho[ii] * sigma2_draw[i-1]^-1 *
                                    sum( ylag[:,ii] .* (y[:,ii] .- alpha .- delta_alpha_draw[i,ii] - rho * ylag[:,ii])) for ii in 1:N ]

            K_rho = q_rho_draw[i] / (1-q_rho_draw[i]) * (vdelta_rho_draw[i] ./ post_var_delta_rho).^(-0.5) .* exp.(0.5*post_mean_delta_rho.^2 ./ post_var_delta_rho)

            if sum(K_rho .== Inf) != 0
                Inf_pos = collect(1:N)[K_rho .== Inf]
                K_rho[Inf_pos] .= 10^8
            end

            prob_rho = K_rho ./ (1 .+ K_rho) # probability of model 1

            z_rho_draw[i,:] = [rand(Bernoulli(x)) for x in prob_rho]

            # draw δ_rho
            zero_rho_pos = collect(1:N)[z_rho_draw[i,:] .== 0]

            delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

            if length(zero_rho_pos) != 0
                delta_rho_draw[i,zero_rho_pos] .= 0
            end

            ###################################################
            ### BLOCK 5: draw σ^2
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

            nu_sigma_post = nu_sigma + N*T
            tau_sigma_post = tau_sigma + sum( crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta_draw[i,:] +
                            [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N)

            sigma2_draw[i] = rand(InverseGamma(nu_sigma_post/2, tau_sigma_post/2))
            # print(i)
        end


        # posteriod mean
        alpha_hat        = mean( beta_draw[burnin:end,1] )
        rho_hat          = mean( beta_draw[burnin:end,2] )
        sigma2_hat       = mean( sigma2_draw[burnin:end] )
        delta_alpha_hat  = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
        delta_rho_hat    = mean( delta_rho_draw[burnin:end,:], dims = 1)'
        z_alpha_hat      = mean( z_alpha_draw[burnin:end,:], dims = 1)'
        z_rho_hat        = mean( z_rho_draw[burnin:end,:], dims = 1)'
        q_alpha_hat      = mean( q_alpha_draw[burnin:end] )
        q_rho_hat        = mean( q_rho_draw[burnin:end] )
        vdelta_alpha_hat = mean( vdelta_alpha_draw[burnin:end] )
        vdelta_rho_hat   = mean( vdelta_rho_draw[burnin:end] )

        post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_hat = sigma2_hat,
                     delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat,
                     vdelta_alpha_hat = vdelta_alpha_hat, vdelta_rho_hat = vdelta_rho_hat,
                     z_alpha_hat = z_alpha_hat, z_rho_hat = z_rho_hat,
                     q_alpha_hat = q_alpha_hat, q_rho_hat = q_rho_hat)

        post_draw = (alpha_draw = beta_draw[burnin:end,1], rho_draw = beta_draw[burnin:end,2], sigma2_draw = sigma2_draw[burnin:end],
                     delta_alpha_draw = delta_alpha_draw[burnin:end,:], delta_rho_draw = delta_rho_draw[burnin:end,:],
                     z_alpha_draw = z_alpha_draw[burnin:end,:], z_rho_draw = z_rho_draw[burnin:end,:],
                     q_alpha_draw = q_alpha_draw[burnin:end], q_rho_draw = q_rho_draw[burnin:end])

        return post_mean, post_draw


    elseif data_version_id == 2 # identical locations of nonzeros

        q_draw            = zeros(len_MCMC+1)
        beta_draw         = zeros(len_MCMC+1, 2) # β = [α, ρ]'
        vdelta_alpha_draw = zeros(len_MCMC+1)
        vdelta_rho_draw   = zeros(len_MCMC+1)
        delta_alpha_draw  = zeros(len_MCMC+1, N)
        delta_rho_draw    = zeros(len_MCMC+1, N)
        z_draw            = zeros(len_MCMC+1, N)
        sigma2_draw       = zeros(len_MCMC+1)

        ### initialize parameters
        # sigma2
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )
        sigma2_draw[1]   = mean(InverseGamma(nu_sigma/2, tau_sigma/2))

        # q
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
        q_draw[1]  = mean(Beta(a,b))

        # variance of δ
        vdelta_alpha_draw[1] = rand(InverseGamma(nu_vdelta_alpha/2, tau_vdelta_alpha/2))
        vdelta_rho_draw[1]   = rand(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))

        # (z,δ)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )

        z_draw[1,:] = rand(Bernoulli(q_draw[1]), N)

        zero_pos    = collect(1:N)[z_draw[1,:] .== 0]

        var_delta_alpha0  = (vdelta_alpha_draw[1]^-1 + N * sigma2_draw[1]^-1)^-1

        delta_alpha_draw[1,:] = rand(Normal(0,sqrt(var_delta_alpha0)), N)
        delta_alpha_draw[1,zero_pos] .= 0

        delta_rho_draw[1,:]   = [rand(Normal(0, sqrt( (vdelta_rho_draw[1]^-1 + sigma2_draw[1]^-1 * sum(ylag[t,ii]^2 for t in 1:T))^-1)) ) for ii in 1:N]
        delta_rho_draw[1,zero_pos] .= 0

        sum_in_var_beta = sum(xx[ii] for ii in 1:N) # sum_i^N (x_i'x_i)

        for i = 2:len_MCMC+1

            ###################################################
            ### BLOCK 1: draw β
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

            vbeta_post = ( inv(Vbeta) + sigma2_draw[i-1]^-1 * sum_in_var_beta )^-1 # posterior variance of β

            sum_in_mean_beta = sum([ones(T,1) ylag[:,ii]]' *
                                    (y[:,ii] - [ones(T,1) ylag[:,ii]] * [delta_alpha_draw[i-1,ii]; delta_rho_draw[i-1,ii]]) for ii in 1:N)
            mean_beta_post = vbeta_post * sigma2_draw[i-1]^-1 * sum_in_mean_beta

            beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

            alpha = beta_draw[i,1]
            rho   = beta_draw[i,2]

            ###################################################
            ### BLOCK 2: draw q
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

            psi       = sum( z_draw[i-1,:] )
            q_draw[i] = rand( Beta(a + psi, b + N - psi) )

            ###################################################
            ### BLOCK 3: draw variance for δ^α and δ^ρ
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

            # δ^α
            nu_vdelta_alpha_post  = nu_vdelta_alpha + psi
            tau_vdelta_alpha_post = tau_vdelta_alpha + sum(delta_alpha_draw[i-1, z_draw[i-1,:] .== 1].^2)

            vdelta_alpha_draw[i] = rand(InverseGamma(nu_vdelta_alpha_post/2, tau_vdelta_alpha_post/2))

            # δ^ρ
            nu_vdelta_rho_post  = nu_vdelta_rho + psi
            tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_draw[i-1,:] .== 1].^2)

            vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

            ###################################################
            ### BLOCK 4: draw (z,δ)
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

            Vdelta = [vdelta_alpha_draw[i-1] 0; 0 vdelta_rho_draw[i-1]]

            # draw z
            post_var_delta  = [ ( Vdelta^-1 + sigma2_draw[i-1]^-1 * xx[ii] )^-1  for ii in 1:N ]

            post_mean_delta = [ post_var_delta[ii] * sigma2_draw[i-1]^-1 * [ones(T,1) ylag[:,ii]]' *
                                (y[:,ii] - [ones(T,1) ylag[:,ii]] * beta_draw[i,:])
                                for ii in 1:N ]

            K = q_draw[i] / (1-q_draw[i]) * [ ( det(Vdelta)/det(post_var_delta[ii]) )^(-0.5) *
                exp(0.5 * post_mean_delta[ii]' * post_var_delta[ii]^(-1) * post_mean_delta[ii]) for ii in 1:N ]

            prob = K ./ (1 .+ K) # probability of model 1

            z_draw[i,:] = [rand(Bernoulli(x)) for x in prob]

            # draw δ
            zero_pos = collect(1:N)[z_draw[i,:] .== 0]

            delta_draw = [ rand(MvNormal(post_mean_delta[ii], Symmetric(post_var_delta[ii]))) for ii in 1:N ]

            delta_alpha_draw[i,:] = [delta_draw[ii][1] for ii in 1:N]
            delta_rho_draw[i,:]   = [delta_draw[ii][2] for ii in 1:N]

            if length(zero_pos) != 0
                delta_alpha_draw[i,zero_pos] .= 0
                delta_rho_draw[i,zero_pos]   .= 0
            end

            ###################################################
            ### BLOCK 5: draw σ^2
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

            nu_sigma_post = nu_sigma + N*T
            tau_sigma_post = tau_sigma + sum( crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta_draw[i,:] +
                            [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N)

            sigma2_draw[i] = rand(InverseGamma(nu_sigma_post/2, tau_sigma_post/2))
            # print(i)
        end

        # posteriod mean
        alpha_hat        = mean( beta_draw[burnin:end,1] )
        rho_hat          = mean( beta_draw[burnin:end,2] )
        delta_alpha_hat  = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
        delta_rho_hat    = mean( delta_rho_draw[burnin:end,:], dims = 1)'
        z_hat            = mean( z_draw[burnin:end,:], dims = 1)'
        q_hat            = mean( q_draw[1:end] )
        vdelta_alpha_hat = mean( vdelta_alpha_draw[burnin:end] )
        vdelta_rho_hat   = mean( vdelta_rho_draw[burnin:end] )

        return alpha_hat, rho_hat, delta_alpha_hat, delta_rho_hat, vdelta_alpha_hat, vdelta_rho_hat, z_hat, q_hat

    end
end





## ################################################################################
# Full Homogeneity (q = 0)
function Homo_hetsk(y_all, lambda, len_MCMC, id_simul)

    # len_MCMC = Int(10000)

    len_MCMC = Int(len_MCMC)
    burnin = Int(floor(0.5*len_MCMC))+2

    y    = y_all[2:end,:]
    ylag = y_all[1:(end-1),:]

    T, N = size(y)

    # unload HP
    valpha, vrho, nu_sigma, tau_sigma, a, b, nu_vdelta_alpha, tau_vdelta_alpha, nu_vdelta_rho, tau_vdelta_rho = lambda

    Vbeta = [valpha 0; 0 vrho]

    beta_draw      = zeros(len_MCMC+1, 2) # β = [α, ρ]'
    sigma2_draw    = zeros(len_MCMC+1)

    # initialize parameters
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
    sigma2_draw[1] = mean(InverseGamma(nu_sigma/2, tau_sigma/2))

    # useful subfunctions
    crossprod(x) = x' * x

    sum_in_var_beta = sum(crossprod([ones(T,1) ylag[:,ii]]) for ii in 1:N) # sum_i^N (x_i'x_i)

    for i = 2:len_MCMC+1

        ###################################################
        ### BLOCK 1: β
        ###################################################
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

        # draw β
        vbeta_post = ( inv(Vbeta) + sigma2_draw[i-1]^-1 * sum_in_var_beta)^-1 # posterior variance of β

        sum_in_mean_beta = sum([ones(T,1) ylag[:,ii]]' * y[:,ii] for ii in 1:N)

        mean_beta_post = vbeta_post * sigma2_draw[i-1]^-1 * sum_in_mean_beta

        beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

        ###################################################
        ### BLOCK 2: σ^2
        ###################################################
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

        # draw σ^2
        nu_sigma_post = nu_sigma + N*T
        tau_sigma_post = tau_sigma + sum( crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * beta_draw[i,:]) for ii in 1:N)

        sigma2_draw[i] = rand(InverseGamma(nu_sigma_post/2, tau_sigma_post/2))
        # print(i)
    end

    # posteriod mean
    alpha_hat       = mean( beta_draw[burnin:end,1] )
    rho_hat         = mean( beta_draw[burnin:end,2] )
    sigma2_hat      = mean( sigma2_draw[burnin:end] )

    post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_hat = sigma2_hat)

    post_draw = (alpha_draw = beta_draw[burnin:end,1], rho_draw = beta_draw[burnin:end,2], sigma2_draw = sigma2_draw[burnin:end])

    return post_mean, post_draw

end







##################################################################################
# Full Heterogeneity (q = 1)
function Hetero_hetsk(y_all, lambda, opt_ar, len_MCMC, id_simul)

    # len_MCMC = Int(5000)
    # id_simul = 1
    # c = 0.5

    len_MCMC = Int(len_MCMC)
    burnin = Int(floor(0.5*len_MCMC))+2

    y    = y_all[2:end,:]
    ylag = y_all[1:(end-1),:]

    T, N = size(y)

    # unload HP
    valpha, vrho, nu_sigma, tau_sigma, a, b, nu_vdelta_alpha, tau_vdelta_alpha, nu_vdelta_rho, tau_vdelta_rho, nu_vdelta_sigma, tau_vdelta_sigma = lambda

    Vbeta = [valpha 0; 0 vrho]

    # useful subfunctions
    crossprod(x) = x' * x
    g(x) = min(abs(x), 10) * sign(x) # helper function in adapative RWMH

    # some shortcuts
    xx = [crossprod([ones(T,1) ylag[:,ii]]) for ii in 1:N]

    beta_draw         = zeros(len_MCMC+1, 2) # β = [α, ρ]'
    vdelta_alpha_draw = zeros(len_MCMC+1)
    vdelta_rho_draw   = zeros(len_MCMC+1)
    vdelta_sigma_draw = zeros(len_MCMC+1)
    delta_alpha_draw  = zeros(len_MCMC+1, N)
    delta_rho_draw    = zeros(len_MCMC+1, N)
    delta_sigma_draw  = zeros(len_MCMC+1, N)
    sigma2_draw       = zeros(len_MCMC+1)

    # RWMH
    c_vdelta_sigma = zeros(len_MCMC+1) # random walk step size
    RWMH_accept_record = zeros(len_MCMC+1)

    ### initialize parameters
    # σ^2
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    sigma2_draw[1]   = mean(InverseGamma(nu_sigma/2, tau_sigma/2))

    # v_δ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )
    vdelta_alpha_draw[1] = mean(InverseGamma(nu_vdelta_alpha/2, tau_vdelta_alpha/2))
    vdelta_rho_draw[1]   = mean(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))
    vdelta_sigma_draw[1] = mean(InverseGamma(nu_vdelta_sigma/2, tau_vdelta_sigma/2))

    # δ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

    delta_alpha_draw[1,:] = rand(Normal(0, sqrt(vdelta_alpha_draw[1])), N)
    delta_rho_draw[1,:]   = rand(Normal(0, sqrt(vdelta_rho_draw[1])), N)
    delta_sigma_draw[1,:] = rand(InverseGamma(nu_vdelta_sigma/2, tau_vdelta_sigma/2), N)

    # c
    c_vdelta_sigma[1] = 1

    for i = 2:len_MCMC+1

        ###################################################
        ### BLOCK 1: draw β
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

        sigma2_i = sigma2_draw[i-1] * delta_sigma_draw[i-1,:]

        sum_in_var_beta = sum(sigma2_i[ii]^-1 * xx[ii] for ii in 1:N) # sum_i^N (x_i'x_i)

        vbeta_post = ( inv(Vbeta) + sum_in_var_beta )^-1 # posterior variance of β

        sum_in_mean_beta = sum(sigma2_i[ii]^-1 * [ones(T,1) ylag[:,ii]]' *
                                (y[:,ii] - [ones(T,1) ylag[:,ii]] * [delta_alpha_draw[i-1,ii]; delta_rho_draw[i-1,ii]]) for ii in 1:N)
        mean_beta_post = vbeta_post * sum_in_mean_beta

        beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

        alpha = beta_draw[i,1]
        rho   = beta_draw[i,2]


        ###################################################
        ### BLOCK 3: draw variance for δ^α and δ^ρ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

        psi_alpha = psi_rho = psi_sigma = N

        ### δ^α
        nu_vdelta_alpha_post  = nu_vdelta_alpha + psi_alpha
        tau_vdelta_alpha_post = tau_vdelta_alpha + sum(delta_alpha_draw[i-1,:].^2)

        vdelta_alpha_draw[i] = rand(InverseGamma(nu_vdelta_alpha_post/2, tau_vdelta_alpha_post/2))

        ### δ^ρ
        nu_vdelta_rho_post  = nu_vdelta_rho + psi_rho
        tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1,:].^2)

        vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

        ### δ^σ
        # log posterior of ω (will be used in RWMH)
        delta_sigma_slab = delta_sigma_draw[i-1,:]
        log_post_omega(x) = psi_sigma*(1/x+2)*log(1/x+1) - psi_sigma*loggamma(1/x+2) - (nu_vdelta_sigma/2+1)*log(x) - 1/x*(sum(log.(delta_sigma_slab)) + sum(delta_sigma_slab.^-1) + tau_vdelta_sigma/2 )

        ### Random Walk Metropolis Hastings
        c_i = c_vdelta_sigma[i-1]
        # draw from truncated normal bounded below by 0
        RWMH_draw = rand(truncated(Normal(vdelta_sigma_draw[i-1], c_i), lower = 0))

        # calculate acceptance rate
        diff_log_post = log_post_omega(RWMH_draw) - log_post_omega(vdelta_sigma_draw[i-1])
        diff_log_CDF  = log(cdf(Normal(0, sqrt(c_i)), RWMH_draw)) - log(cdf(Normal(0, sqrt(c_i)), vdelta_sigma_draw[i-1]))


        prob_RWMH = min(1, exp(diff_log_post - diff_log_CDF))

        RWMH_accept = rand(Bernoulli(prob_RWMH))

        if RWMH_accept
            vdelta_sigma_draw[i] = RWMH_draw
            RWMH_accept_record[i] = 1
        else
            vdelta_sigma_draw[i] = vdelta_sigma_draw[i-1]
            RWMH_accept_record[i] = 0
        end

        # update random walk step size
        log_c = g( log(c_vdelta_sigma[i-1]) + i^(-0.55) * (prob_RWMH - opt_ar) )
        c_vdelta_sigma[i] = exp(log_c)


        ###################################################
        ### BLOCK 3: draw (z,δ)
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

        ### draw δ_alpha
        # posterior mean and variance of delta_alpha_i
        post_var_delta_alpha  = (vdelta_alpha_draw[i]^-1 .+ T * sigma2_i.^-1).^-1
        post_mean_delta_alpha = [post_var_delta_alpha[ii] * sigma2_i[ii]^-1 *
                                sum(y[:,ii] .- alpha .- (rho .+ delta_rho_draw[i-1,ii]) * ylag[:,ii]) for ii in 1:N]

        delta_alpha_draw[i,:] = [rand(Normal(post_mean_delta_alpha[ii], sqrt(post_var_delta_alpha[ii]))) for ii in 1:N]


        ### draw δ_rho
        post_var_delta_rho  = [ (vdelta_rho_draw[i]^-1 + sigma2_i[ii]^-1 * sum(ylag[t,ii]^2 for t in 1:T) )^-1 for ii in 1:N]
        post_mean_delta_rho = [ post_var_delta_rho[ii] * sigma2_i[ii]^-1 *
                                sum( ylag[:,ii] .* (y[:,ii] .- alpha .- delta_alpha_draw[i,ii] - rho * ylag[:,ii])) for ii in 1:N ]

        delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

        ### draw δ_sigma
        sum_y_sigma_sq = [crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta_draw[i,:] + [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N]

        # parameters in posterior of δ^σ
        nu_delta_sigma_post  = 2*vdelta_sigma_draw[i]^(-1) + 4 + T
        tau_delta_sigma_post = 2*vdelta_sigma_draw[i]^(-1) + 2 .+ sigma2_draw[i-1]^-1 * sum_y_sigma_sq

        delta_sigma_draw[i,:] = [rand(InverseGamma(nu_delta_sigma_post/2, tau_delta_sigma_post[ii]/2)) for ii in 1:N]

        ###################################################
        ### BLOCK 4: draw σ^2
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

        nu_sigma_post  = nu_sigma + N*T
        tau_sigma_post = tau_sigma + sum( delta_sigma_draw[i,ii]^-1 * crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta_draw[i,:] +
                        [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N)

        sigma2_draw[i] = rand(InverseGamma(nu_sigma_post/2, tau_sigma_post/2))

        # print(i)
    end

    # posteriod mean
    alpha_hat        = mean( beta_draw[burnin:end,1] )
    rho_hat          = mean( beta_draw[burnin:end,2] )
    sigma2_hat       = mean( sigma2_draw[burnin:end] )
    delta_alpha_hat  = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
    delta_rho_hat    = mean( delta_rho_draw[burnin:end,:], dims = 1)'
    delta_sigma_hat  = mean( delta_sigma_draw[burnin:end,:], dims = 1)'
    vdelta_alpha_hat = mean( vdelta_alpha_draw[burnin:end] )
    vdelta_rho_hat   = mean( vdelta_rho_draw[burnin:end] )
    vdelta_sigma_hat = mean( vdelta_rho_draw[burnin:end] )

    post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_hat = sigma2_hat,
                 delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat, delta_sigma_hat = delta_sigma_hat,
                 vdelta_alpha_hat = vdelta_alpha_hat, vdelta_rho_hat = vdelta_rho_hat, vdelta_sigma_hat = vdelta_sigma_hat,
                 RWMH_accept_rate = mean(RWMH_accept_record[burnin:end]))

    post_draw = (alpha_draw = beta_draw[burnin:end,1], rho_draw = beta_draw[burnin:end,2], sigma2_draw = sigma2_draw[burnin:end],
                 delta_alpha_draw = delta_alpha_draw[burnin:end,:], delta_rho_draw = delta_rho_draw[burnin:end,:], delta_sigma_draw = delta_sigma_draw[burnin:end,:],
                 c_vdelta_sigma = c_vdelta_sigma,
                 RWMH_accept_record = RWMH_accept_record[burnin:end])

    return post_mean, post_draw


end

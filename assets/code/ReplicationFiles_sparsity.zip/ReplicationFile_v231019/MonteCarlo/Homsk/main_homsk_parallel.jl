##############################################################
#  Bayesian Estimation of Panel Models under Potentially Sparse Heterogeneity
#  DGP 3: Homoskedastic Dynamic Panel Data Model
#  Version: Parallel
#  Creation: 08/06/2019
#  Last change: 10/22/2023
#############################################################

####################################################################################################
#                             Part 0: INTRO
####################################################################################################

using Distributed

rmprocs(workers())

#Add workers
println("Adding workers... ")
addprocs(8)
println("Number of active processors = $(nprocs())")

wd = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/MonteCarlo/Homsk/"
# wd = "$(pwd())/ReplicationFile_v231019/MonteCarlo/Homsk/"

# create folder: Results
wd_results = string(wd, "Results/")
if !isdir(wd_results)
    mkdir(wd_results)
end

# load packages (install them with Pkg.add() if needed)
@everywhere using JLD2, FileIO, MutableNamedTuples, Random, Distributions, LinearAlgebra, Dates, SharedArrays

# load subfunction files
@everywhere include("functions_homsk.jl")

####################################################################################################
#                             Part 1: INITALIZATION
####################################################################################################

# DGP3 version
@everywhere data_version_id = 1
# Number of simulation
@everywhere nSim = 100
# number of observations for each draw
@everywhere bign = 500
# number of time period
@everywhere bigt = 8
# number of MCMC draws
@everywhere nMCMC = 5000

# Parameter in the prior of v_δ^α (Inverse Gamma)
@everywhere prior_mean_delta_alpha = 1
@everywhere prior_sd_delta_alpha  = 1
@everywhere nu_delta_alpha  = 4+2*prior_mean_delta_alpha^2/prior_sd_delta_alpha^2
@everywhere tau_delta_alpha = 2*prior_mean_delta_alpha*(1+prior_mean_delta_alpha^2/prior_sd_delta_alpha^2)

# Parameter in the prior of v_δ^ρ (Inverse Gamma)
@everywhere prior_mean_delta_rho = 0.5
@everywhere prior_sd_delta_rho  = 0.5
@everywhere nu_delta_rho  = 4+2*prior_mean_delta_rho^2/prior_sd_delta_rho^2
@everywhere tau_delta_rho = 2*prior_mean_delta_rho*(1+prior_mean_delta_rho^2/prior_sd_delta_rho^2)

# homogeneous parameter
@everywhere theta = MutableNamedTuple(alpha = 1.0, rho = 0.6, sigma2 = 0.8, q = NaN, vdelta_alpha = NaN, vdelta_rho = 0.09)

# hyperparameters
@everywhere lambda = MutableNamedTuple(valpha = 1, vrho = 0.25, nu_sigma = 12, tau_sigma = 10, a = 1, b = 1,
        nu_delta_alpha = nu_delta_alpha, tau_delta_alpha = tau_delta_alpha, nu_delta_rho = nu_delta_rho, tau_delta_rho = tau_delta_rho)

# grid for q
@everywhere q_grid = collect(0:0.2:1)

# grid for v_δ^α
@everywhere vdelta_alpha_grid = [0.05,0.1,0.5,1]

# create empty arrays
@everywhere matMSE_alpha_homo   = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_rho_homo     = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_alpha_hetero = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_rho_hetero   = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_alpha_ss     = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_rho_ss       = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_alpha_ss_o   = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_rho_ss_o     = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)

@everywhere matMSE_vdelta_alpha_hetero = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_vdelta_rho_hetero   = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_vdelta_alpha_ss     = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)
@everywhere matMSE_vdelta_rho_ss       = SharedArray{Float64,3}((nSim,length(q_grid),length(vdelta_alpha_grid)), init = 0)


####################################################################################################
#                              Part 2: MC SIMULATION
####################################################################################################

println(" Simulation starts, # of simulation = $(nSim[1]), # of MCMC chain = $nMCMC, version = $data_version_id")

for k in eachindex(q_grid), l in eachindex(vdelta_alpha_grid)

    @time @sync @distributed for i = 1:nSim

        theta.q = q_grid[k]
        theta.vdelta_alpha = vdelta_alpha_grid[l]

        #########################
        # Generate panel y
        #########################
        Random.seed!(i)
        y_all, delta_alpha, delta_rho = generate_paneldata_homsk(bign, bigt+1, theta, data_version_id)

        #########################
        # Spike-and-Slab, version 1
        #########################
        post_mean_ss, post_draw_ss = SS_homsk(y_all, lambda, nMCMC, 1, i)

        matMSE_alpha_ss[i,k,l] = mean( ((post_mean_ss.alpha_hat .+ post_mean_ss.delta_alpha_hat) .- (theta.alpha .+ delta_alpha)).^2 )
        matMSE_rho_ss[i,k,l]   = mean( ((post_mean_ss.rho_hat .+ post_mean_ss.delta_rho_hat) .- (theta.rho .+ delta_rho)).^2 )

        matMSE_vdelta_alpha_ss[i,k,l] = (post_mean_ss.vdelta_alpha_hat - theta.vdelta_alpha)^2
        matMSE_vdelta_rho_ss[i,k,l]   = (post_mean_ss.vdelta_rho_hat - theta.vdelta_rho)^2

        #########################
        # Spike-and-Slab, oracle, version 1
        #########################
        post_mean_ss_o, post_draw_ss_o = SS_homsk_oracle(y_all, lambda, theta, nMCMC, 1, i)

        matMSE_alpha_ss_o[i,k,l] = mean( ((theta.alpha .+ post_mean_ss_o.delta_alpha_hat) .- (theta.alpha .+ delta_alpha)).^2 )
        matMSE_rho_ss_o[i,k,l]   = mean( ((theta.rho .+ post_mean_ss_o.delta_rho_hat) .- (theta.rho .+ delta_rho)).^2 )

        #########################
        # Homogeneity
        #########################
        post_mean_homo, post_draw_homo = Homo_homsk(y_all, lambda, nMCMC, i)
        # calculate MSE
        matMSE_alpha_homo[i,k,l] = mean( (post_mean_homo.alpha_hat .- (theta.alpha .+ delta_alpha)).^2 )
        matMSE_rho_homo[i,k,l]   = mean( (post_mean_homo.rho_hat  .- (theta.rho .+ delta_rho)).^2 )

        #########################
        # Full Heterogeneity (spike-and-slab with q = 1)
        #########################
        post_mean_hetero, post_draw_hetero = Hetero_homsk(y_all, lambda, nMCMC, i)

        # calculate MSE
        matMSE_alpha_hetero[i,k,l] = mean( ((post_mean_hetero.alpha_hat .+ post_mean_hetero.delta_alpha_hat) .- (theta.alpha .+ delta_alpha)).^2 )
        matMSE_rho_hetero[i,k,l]   = mean( ((post_mean_hetero.rho_hat .+ post_mean_hetero.delta_rho_hat) .- (theta.rho .+ delta_rho)).^2 )

        matMSE_vdelta_alpha_hetero[i,k,l] = (post_mean_hetero.vdelta_alpha_hat - theta.vdelta_alpha)^2
        matMSE_vdelta_rho_hetero[i,k,l]   = (post_mean_hetero.vdelta_rho_hat - theta.vdelta_rho)^2

    end
    println("Simulation for bign = $(bign), q = $(q_grid[k]), vdelta_alpha = $(vdelta_alpha_grid[l]) is done.")

end

####################################################################################################
#                             Part 3: CALCULATE MSE AND SAVE OUTPUT
####################################################################################################

# MSE for estimated α + δ^α_i
MSE_temp   = mapslices(mean, matMSE_alpha_ss, dims = 1)
MSE_alpha_ss   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_alpha_ss_o, dims = 1)
MSE_alpha_ss_o = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_alpha_homo, dims = 1)
MSE_alpha_homo   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_alpha_hetero, dims = 1)
MSE_alpha_hetero = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

# MSE for estimated ρ + δ^ρ_i
MSE_temp   = mapslices(mean, matMSE_rho_ss, dims = 1)
MSE_rho_ss   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_rho_ss_o, dims = 1)
MSE_rho_ss_o = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_rho_homo, dims = 1)
MSE_rho_homo   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_rho_hetero, dims = 1)
MSE_rho_hetero = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

# MSE for estimated variance of δ^α_i and δ^ρ_i
MSE_temp   = mapslices(mean, matMSE_vdelta_alpha_ss, dims = 1)
MSE_vdelta_alpha_ss   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_vdelta_rho_ss, dims = 1)
MSE_vdelta_rho_ss     = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_vdelta_alpha_hetero, dims = 1)
MSE_vdelta_alpha_hetero = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

MSE_temp   = mapslices(mean, matMSE_vdelta_rho_hetero, dims = 1)
MSE_vdelta_rho_hetero   = dropdims(MSE_temp, dims = (findall(size(MSE_temp) .== 1)...,))

# save results in jld2 file
save(wd_results * "Simulation_result_homsk_v$(data_version_id)_N$(bign)_$(Dates.format(today(), "yymmdd")).jld2",
    "MSE_alpha_ss", MSE_alpha_ss,
    "MSE_alpha_ss_o", MSE_alpha_ss_o,
    "MSE_alpha_homo", MSE_alpha_homo,
    "MSE_alpha_hetero", MSE_alpha_hetero,
    "MSE_rho_ss", MSE_rho_ss,
    "MSE_rho_ss_o", MSE_rho_ss_o,
    "MSE_rho_homo", MSE_rho_homo,
    "MSE_rho_hetero", MSE_rho_hetero,
    "MSE_vdelta_alpha_ss",MSE_vdelta_alpha_ss,
    "MSE_vdelta_rho_ss",MSE_vdelta_rho_ss,
    "MSE_vdelta_alpha_hetero",MSE_vdelta_alpha_hetero,
    "MSE_vdelta_rho_hetero",MSE_vdelta_rho_hetero
    )

#Remove the additional workers
print("Removing workers...")
rmprocs(workers())
println("Done.")

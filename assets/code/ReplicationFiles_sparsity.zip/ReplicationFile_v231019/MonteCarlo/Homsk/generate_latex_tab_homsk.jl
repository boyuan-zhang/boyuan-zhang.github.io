##############################################################
# Print Julia array in LaTeX
#############################################################

# wd_results = "$(pwd())/Dropbox/SparseHetero/Software/ReplicationFile_v231019/MonteCarlo/Homsk/Results/"
wd_results = "$(pwd())/ReplicationFile_v231019/MonteCarlo/Homsk/Results/"
cd(wd_results)

# "add https://github.com/scheinerman/LatexPrint.jl" in package manager mode
using LatexPrint, FileIO, JLD2

# @load "Simulation_result_homsk_v1_N500_220224.jld2"
@load "Simulation_result_homsk_v1_N500_231023.jld2"

# τ = collect(0.1:0.2:0.9)
q = collect(0:0.2:1)
v = [0.05,0.10,0.50,1]
est_name = repeat(["S\\&S","q = 0","q = 1.0","Oracle"], length(v))
est_name2 = repeat(["S\\&S" ,"q = 1.0"], length(v))

# first_column = [string(v[1]),"  ","",string(v[2]),"  ","",string(v[3]),"  ",""]
first_column = [string(v[1])," "," "," ",string(v[2])," "," "," ",
                string(v[3])," "," "," ",string(v[4])," "," "," "]
first_column2 = [string(v[1])," ",string(v[2])," ",
                string(v[3])," ",string(v[4])," "]

print(" \n\n\n\n\n\n")

#################################################################
# Part 1: MSE of α+δ_α
################################################################

################################################################
println("MSE for α")
print(" \n\n")
MSE_alpha = Array{Float64,2}(undef,length(est_name),length(q))
let
counter = 0
for l in eachindex(v)
    MSE_alpha[counter+1,:] = MSE_alpha_ss[:,l]
    MSE_alpha[counter+2,:] = MSE_alpha_homo[:,l]
    MSE_alpha[counter+3,:] = MSE_alpha_hetero[:,l]
    MSE_alpha[counter+4,:] = MSE_alpha_ss_o[:,l]
    counter = counter + 4
end
end
tabular([first_column est_name round.( MSE_alpha, digits = 3)])

print(" \n\n\n\n\n\n")


################################################################
# Part 2: MSE of ρ+δ_ρ
################################################################

################################################################
println("MSE for ρ")
print(" \n\n")
MSE_rho = Array{Float64,2}(undef,length(est_name),length(q))
let
counter = 0
for l in eachindex(v)
    MSE_rho[counter+1,:] = MSE_rho_ss[:,l]
    MSE_rho[counter+2,:] = MSE_rho_homo[:,l]
    MSE_rho[counter+3,:] = MSE_rho_hetero[:,l]
    MSE_rho[counter+4,:] = MSE_rho_ss_o[:,l]
    counter = counter + 4
end
end
tabular([first_column est_name round.( MSE_rho, digits = 3)])

print(" \n\n\n\n\n\n")


################################################################
# Part 3: MSE of V_δ^α
################################################################

println("MSE for V_δ^α")
print(" \n\n")
MSE_vdelta_alpha = Array{Float64,2}(undef,length(v)*2,length(q))

let
counter = 0
for l in eachindex(v)
    MSE_vdelta_alpha[counter+1,:] = MSE_vdelta_alpha_ss[:,l]
    MSE_vdelta_alpha[counter+2,:] = MSE_vdelta_alpha_hetero[:,l]
    counter = counter + 2
end
end
tabular([first_column2 est_name2 round.( MSE_vdelta_alpha, digits = 3)])

print(" \n\n\n\n\n\n")



################################################################
# Part 4: MSE of V_δ^ρ
################################################################

println("MSE for V_δ^ρ")
print(" \n\n")
MSE_vdelta_rho = Array{Float64,2}(undef,length(v)*2,length(q))

let
counter = 0
for l in eachindex(v)
    MSE_vdelta_rho[counter+1,:] = MSE_vdelta_rho_ss[:,l]
    MSE_vdelta_rho[counter+2,:] = MSE_vdelta_rho_hetero[:,l]
    counter = counter + 2
end
end
tabular([first_column2 est_name2 round.( MSE_vdelta_rho, digits = 3)])

print(" \n\n\n\n\n\n")

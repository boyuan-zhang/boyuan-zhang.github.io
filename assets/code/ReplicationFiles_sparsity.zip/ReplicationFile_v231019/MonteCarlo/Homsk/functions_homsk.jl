## Subfucntions for DGP3:  Homoskedastic Dynamic Panel Data Model
# Creation: 08/06/2019
# Last Modification: 09/29/2020
##################################################################################

function generate_paneldata_homsk(N, T, theta, data_version_id)
    # N = bign
    # T = bigt+1

    if data_version_id == 1 # different locations of nonzeros

        # draw delta_alpha_i for i = 1,...,N
        delta_alpha      = rand(Normal(0,sqrt(theta.vdelta_alpha)),N)
        id_nonzero_alpha = rand(Bernoulli(theta.q), N)
        zero_pos_alpha   = collect(1:N)[id_nonzero_alpha.== 0]
        delta_alpha[zero_pos_alpha] .= 0

        # draw delta_rho_i for i = 1,...,N
        delta_rho      = rand(Normal(0,sqrt(theta.vdelta_rho)),N)
        id_nonzero_rho = rand(Bernoulli(theta.q), N)
        zero_pos_rho   = collect(1:N)[id_nonzero_rho.== 0]
        delta_rho[zero_pos_rho] .= 0

    else # identical locations of nonzeros

        # draw delta_alpha_i for i = 1,...,N
        delta_alpha  = rand(Normal(0,sqrt(theta.vdelta_alpha)),N)
        # draw delta_rho_i for i = 1,...,N
        delta_rho    = rand(Normal(0,sqrt(theta.vdelta_rho)),N)

        id_nonzero = rand(Bernoulli(theta.q), N)
        zero_pos = collect(1:N)[id_nonzero.== 0]
        delta_alpha[zero_pos] .= 0
        delta_rho[zero_pos]   .= 0

    end

    # draw u_it for i = 1,...,N, t = 1,...,T
    u = rand(Normal(0,1),T,N)

    # construct panel y
    y_all = Array{Float64,2}(undef,T+1,N)
    y_all[1,:] .= 0 # the first row corresponding to t = 0

    for i in 1:N, t in 2:(T+1)
        y_all[t,i] = theta.alpha + delta_alpha[i] + (theta.rho + delta_rho[i]) * y_all[t-1,i] + sqrt(theta.sigma2) * u[t-1,i]
    end

    # remove the first row
    y_all = y_all[2:(T+1),:]

    return y_all, delta_alpha, delta_rho, u
end



### ################################################################################
# SS
function SS_homsk(y_all, lambda, len_MCMC, data_version_id, id_simul)

    # len_MCMC = Int(2000)
    # id_simul = 1

    len_MCMC = Int(len_MCMC)
    burnin = Int(floor(0.5*len_MCMC))+2

    y    = y_all[2:end,:]
    ylag = y_all[1:(end-1),:]

    T, N = size(y)

    # unload HP
    valpha, vrho, nu_sigma, tau_sigma, a, b, nu_vdelta_alpha, tau_vdelta_alpha, nu_vdelta_rho, tau_vdelta_rho = lambda

    Vbeta = [valpha 0; 0 vrho]

    # useful subfunctions
    crossprod(x) = x' * x

    # some shortcuts
    xx = [crossprod([ones(T,1) ylag[:,ii]]) for ii in 1:N]

    if data_version_id == 1 # different locations of nonzeros

        q_alpha_draw      = zeros(len_MCMC+1)
        q_rho_draw        = zeros(len_MCMC+1)
        beta_draw         = zeros(len_MCMC+1, 2) # β = [α, ρ]'
        vdelta_alpha_draw = zeros(len_MCMC+1)
        vdelta_rho_draw   = zeros(len_MCMC+1)
        delta_alpha_draw  = zeros(len_MCMC+1, N)
        delta_rho_draw    = zeros(len_MCMC+1, N)
        z_alpha_draw      = zeros(len_MCMC+1, N)
        z_rho_draw        = zeros(len_MCMC+1, N)
        sigma2_draw       = zeros(len_MCMC+1)

        ### initialize parameters
        # σ^2
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
        sigma2_draw[1]   = mean(InverseGamma(nu_sigma/2, tau_sigma/2))

        # q
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
        q_alpha_draw[1]  = mean(Beta(a,b))
        q_rho_draw[1]    = mean(Beta(a,b))

        # v_δ
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )
        vdelta_alpha_draw[1] = mean(InverseGamma(nu_vdelta_alpha/2, tau_vdelta_alpha/2))
        vdelta_rho_draw[1]   = mean(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))

        # (z,δ)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

        z_alpha_draw[1,:] = rand(Bernoulli(q_alpha_draw[1]), N)
        z_rho_draw[1,:]   = rand(Bernoulli(q_rho_draw[1]), N)

        zero_pos_alpha    = collect(1:N)[z_alpha_draw[1,:] .== 0]
        zero_pos_rho      = collect(1:N)[z_rho_draw[1,:] .== 0]

        delta_alpha_draw[1,:] = rand(Normal(0, sqrt(vdelta_alpha_draw[1])), N)
        delta_alpha_draw[1,zero_pos_alpha] .= 0

        delta_rho_draw[1,:]   = rand(Normal(0, sqrt(vdelta_rho_draw[1])), N)
        delta_rho_draw[1,zero_pos_rho]     .= 0

        sum_in_var_beta = sum(xx[ii] for ii in 1:N) # sum_i^N (x_i'x_i)

        for i = 2:len_MCMC+1

            ###################################################
            ### BLOCK 1: draw β
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

            vbeta_post = ( inv(Vbeta) + sigma2_draw[i-1]^-1 * sum_in_var_beta )^-1 # posterior variance of β

            sum_in_mean_beta = sum([ones(T,1) ylag[:,ii]]' *
                                    (y[:,ii] - [ones(T,1) ylag[:,ii]] * [delta_alpha_draw[i-1,ii]; delta_rho_draw[i-1,ii]]) for ii in 1:N)
            mean_beta_post = vbeta_post * sigma2_draw[i-1]^-1 * sum_in_mean_beta

            beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

            alpha = beta_draw[i,1]
            rho   = beta_draw[i,2]

            ###################################################
            ### BLOCK 2: draw q
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

            psi_alpha       = sum( z_alpha_draw[i-1,:] )
            psi_rho         = sum( z_rho_draw[i-1,:] )
            q_alpha_draw[i] = rand( Beta(a + psi_alpha, b + N - psi_alpha) )
            q_rho_draw[i]   = rand( Beta(a + psi_rho, b + N - psi_rho) )

            ###################################################
            ### BLOCK 3: draw variance for δ^α and δ^ρ
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

            # δ^α
            nu_vdelta_alpha_post  = nu_vdelta_alpha + psi_alpha
            tau_vdelta_alpha_post = tau_vdelta_alpha + sum(delta_alpha_draw[i-1, z_alpha_draw[i-1,:] .== 1].^2)

            vdelta_alpha_draw[i] = rand(InverseGamma(nu_vdelta_alpha_post/2, tau_vdelta_alpha_post/2))

            # δ^ρ
            nu_vdelta_rho_post  = nu_vdelta_rho + psi_rho
            tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_rho_draw[i-1,:] .== 1].^2)

            vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

            ###################################################
            ### BLOCK 4: draw (z,δ)
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

            # draw z_alpha

            # posterior mean and variance of delta_alpha_i
            post_var_delta_alpha  = (vdelta_alpha_draw[i]^-1 + T * sigma2_draw[i-1]^-1)^-1
            post_mean_delta_alpha = [post_var_delta_alpha * sigma2_draw[i-1]^-1 *
                                    sum(y[:,ii] .- alpha .- (rho .+ delta_rho_draw[i-1,ii]) * ylag[:,ii]) for ii in 1:N]

            K_alpha = q_alpha_draw[i] / (1-q_alpha_draw[i]) * (vdelta_alpha_draw[i] / post_var_delta_alpha)^(-0.5) *
                        exp.(0.5*post_mean_delta_alpha.^2 / post_var_delta_alpha)

            if sum(K_alpha .== Inf) != 0
                Inf_pos = collect(1:N)[K_alpha .== Inf]
                K_alpha[Inf_pos] .= 10^8
            end

            prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1

            z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

            # draw δ_alpha
            zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

            delta_alpha_draw[i,:] = [rand(Normal(post_mean_delta_alpha[ii], sqrt(post_var_delta_alpha))) for ii in 1:N]

            if length(zero_alpha_pos) != 0
                delta_alpha_draw[i,zero_alpha_pos] .= 0
            end

            # draw z_rho
            # posterior mean and variance of delta_alpha_i
            post_var_delta_rho  = [ (vdelta_rho_draw[i]^-1 + sigma2_draw[i-1]^-1 * sum(ylag[:,ii].^2) )^-1 for ii in 1:N]
            post_mean_delta_rho = [ post_var_delta_rho[ii] * sigma2_draw[i-1]^-1 *
                                sum( ylag[:,ii] .* (y[:,ii] .- alpha .- delta_alpha_draw[i,ii] - rho * ylag[:,ii])) for ii in 1:N ]

            K_rho = q_rho_draw[i] / (1-q_rho_draw[i]) * (vdelta_rho_draw[i] ./ post_var_delta_rho).^(-0.5) .* exp.(0.5*post_mean_delta_rho.^2 ./ post_var_delta_rho)

            if sum(K_rho .== Inf) != 0
                Inf_pos = collect(1:N)[K_rho .== Inf]
                K_rho[Inf_pos] .= 10^8
            end

            prob_rho = K_rho ./ (1 .+ K_rho) # probability of model 1

            z_rho_draw[i,:] = [rand(Bernoulli(x)) for x in prob_rho]

            # draw δ_rho
            zero_rho_pos = collect(1:N)[z_rho_draw[i,:] .== 0]

            delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

            if length(zero_rho_pos) != 0
                delta_rho_draw[i,zero_rho_pos] .= 0
            end

            ###################################################
            ### BLOCK 5: draw σ^2
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

            nu_sigma_post = nu_sigma + N*T
            tau_sigma_post = tau_sigma + sum( crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta_draw[i,:] +
                            [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N)

            sigma2_draw[i] = rand(InverseGamma(nu_sigma_post/2, tau_sigma_post/2))
            # print(i)
        end


        # posteriod mean
        alpha_hat        = mean( beta_draw[burnin:end,1] )
        rho_hat          = mean( beta_draw[burnin:end,2] )
        sigma2_hat       = mean( sigma2_draw[burnin:end] )
        delta_alpha_hat  = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
        delta_rho_hat    = mean( delta_rho_draw[burnin:end,:], dims = 1)'
        z_alpha_hat      = mean( z_alpha_draw[burnin:end,:], dims = 1)'
        z_rho_hat        = mean( z_rho_draw[burnin:end,:], dims = 1)'
        q_alpha_hat      = mean( q_alpha_draw[burnin:end] )
        q_rho_hat        = mean( q_rho_draw[burnin:end] )
        vdelta_alpha_hat = mean( vdelta_alpha_draw[burnin:end] )
        vdelta_rho_hat   = mean( vdelta_rho_draw[burnin:end] )

        post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_hat = sigma2_hat,
                     delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat,
                     vdelta_alpha_hat = vdelta_alpha_hat, vdelta_rho_hat = vdelta_rho_hat,
                     z_alpha_hat = z_alpha_hat, z_rho_hat = z_rho_hat,
                     q_alpha_hat = q_alpha_hat, q_rho_hat = q_rho_hat)

        post_draw = (alpha_draw = beta_draw[burnin:end,1], rho_draw = beta_draw[burnin:end,2], sigma2_draw = sigma2_draw[burnin:end],
                     delta_alpha_draw = delta_alpha_draw[burnin:end,:], delta_rho_draw = delta_rho_draw[burnin:end,:],
                     z_alpha_draw = z_alpha_draw[burnin:end,:], z_rho_draw = z_rho_draw[burnin:end,:],
                     q_alpha_draw = q_alpha_draw[burnin:end], q_rho_draw = q_rho_draw[burnin:end])

        return post_mean, post_draw


    elseif data_version_id == 2 # identical locations of nonzeros

        q_draw            = zeros(len_MCMC+1)
        beta_draw         = zeros(len_MCMC+1, 2) # β = [α, ρ]'
        vdelta_alpha_draw = zeros(len_MCMC+1)
        vdelta_rho_draw   = zeros(len_MCMC+1)
        delta_alpha_draw  = zeros(len_MCMC+1, N)
        delta_rho_draw    = zeros(len_MCMC+1, N)
        z_draw            = zeros(len_MCMC+1, N)
        sigma2_draw       = zeros(len_MCMC+1)

        ### initialize parameters
        # sigma2
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )
        sigma2_draw[1]   = mean(InverseGamma(nu_sigma/2, tau_sigma/2))

        # q
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
        q_draw[1]  = mean(Beta(a,b))

        # variance of δ
        vdelta_alpha_draw[1] = rand(InverseGamma(nu_vdelta_alpha/2, tau_vdelta_alpha/2))
        vdelta_rho_draw[1]   = rand(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))

        # (z,δ)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )

        z_draw[1,:] = rand(Bernoulli(q_draw[1]), N)

        zero_pos    = collect(1:N)[z_draw[1,:] .== 0]

        var_delta_alpha0  = (vdelta_alpha_draw[1]^-1 + N * sigma2_draw[1]^-1)^-1

        delta_alpha_draw[1,:] = rand(Normal(0,sqrt(var_delta_alpha0)), N)
        delta_alpha_draw[1,zero_pos] .= 0

        delta_rho_draw[1,:]   = [rand(Normal(0, sqrt( (vdelta_rho_draw[1]^-1 + sigma2_draw[1]^-1 * sum(ylag[t,ii]^2 for t in 1:T))^-1)) ) for ii in 1:N]
        delta_rho_draw[1,zero_pos] .= 0

        sum_in_var_beta = sum(xx[ii] for ii in 1:N) # sum_i^N (x_i'x_i)

        for i = 2:len_MCMC+1

            ###################################################
            ### BLOCK 1: draw β
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

            vbeta_post = ( inv(Vbeta) + sigma2_draw[i-1]^-1 * sum_in_var_beta )^-1 # posterior variance of β

            sum_in_mean_beta = sum([ones(T,1) ylag[:,ii]]' *
                                    (y[:,ii] - [ones(T,1) ylag[:,ii]] * [delta_alpha_draw[i-1,ii]; delta_rho_draw[i-1,ii]]) for ii in 1:N)
            mean_beta_post = vbeta_post * sigma2_draw[i-1]^-1 * sum_in_mean_beta

            beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

            alpha = beta_draw[i,1]
            rho   = beta_draw[i,2]

            ###################################################
            ### BLOCK 2: draw q
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

            psi       = sum( z_draw[i-1,:] )
            q_draw[i] = rand( Beta(a + psi, b + N - psi) )

            ###################################################
            ### BLOCK 3: draw variance for δ^α and δ^ρ
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

            # δ^α
            nu_vdelta_alpha_post  = nu_vdelta_alpha + psi
            tau_vdelta_alpha_post = tau_vdelta_alpha + sum(delta_alpha_draw[i-1, z_draw[i-1,:] .== 1].^2)

            vdelta_alpha_draw[i] = rand(InverseGamma(nu_vdelta_alpha_post/2, tau_vdelta_alpha_post/2))

            # δ^ρ
            nu_vdelta_rho_post  = nu_vdelta_rho + psi
            tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_draw[i-1,:] .== 1].^2)

            vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

            ###################################################
            ### BLOCK 4: draw (z,δ)
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

            Vdelta = [vdelta_alpha_draw[i-1] 0; 0 vdelta_rho_draw[i-1]]

            # draw z
            post_var_delta  = [ ( Vdelta^-1 + sigma2_draw[i-1]^-1 * xx[ii] )^-1  for ii in 1:N ]

            post_mean_delta = [ post_var_delta[ii] * sigma2_draw[i-1]^-1 * [ones(T,1) ylag[:,ii]]' *
                                (y[:,ii] - [ones(T,1) ylag[:,ii]] * beta_draw[i,:])
                                for ii in 1:N ]

            K = q_draw[i] / (1-q_draw[i]) * [ ( det(Vdelta)/det(post_var_delta[ii]) )^(-0.5) *
                exp(0.5 * post_mean_delta[ii]' * post_var_delta[ii]^(-1) * post_mean_delta[ii]) for ii in 1:N ]

            prob = K ./ (1 .+ K) # probability of model 1

            z_draw[i,:] = [rand(Bernoulli(x)) for x in prob]

            # draw δ
            zero_pos = collect(1:N)[z_draw[i,:] .== 0]

            delta_draw = [ rand(MvNormal(post_mean_delta[ii], Symmetric(post_var_delta[ii]))) for ii in 1:N ]

            delta_alpha_draw[i,:] = [delta_draw[ii][1] for ii in 1:N]
            delta_rho_draw[i,:]   = [delta_draw[ii][2] for ii in 1:N]

            if length(zero_pos) != 0
                delta_alpha_draw[i,zero_pos] .= 0
                delta_rho_draw[i,zero_pos]   .= 0
            end

            ###################################################
            ### BLOCK 5: draw σ^2
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

            nu_sigma_post = nu_sigma + N*T
            tau_sigma_post = tau_sigma + sum( crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta_draw[i,:] +
                            [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N)

            sigma2_draw[i] = rand(InverseGamma(nu_sigma_post/2, tau_sigma_post/2))
            # print(i)
        end

        # posteriod mean
        alpha_hat        = mean( beta_draw[burnin:end,1] )
        rho_hat          = mean( beta_draw[burnin:end,2] )
        delta_alpha_hat  = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
        delta_rho_hat    = mean( delta_rho_draw[burnin:end,:], dims = 1)'
        z_hat            = mean( z_draw[burnin:end,:], dims = 1)'
        q_hat            = mean( q_draw[1:end] )
        vdelta_alpha_hat = mean( vdelta_alpha_draw[burnin:end] )
        vdelta_rho_hat   = mean( vdelta_rho_draw[burnin:end] )

        return alpha_hat, rho_hat, delta_alpha_hat, delta_rho_hat, vdelta_alpha_hat, vdelta_rho_hat, z_hat, q_hat

    end
end







## ################################################################################
# SS - oracle
function SS_homsk_oracle(y_all, lambda, theta, len_MCMC, data_version_id, id_simul)

    # len_MCMC = Int(2000)
    # id_simul = 1

    len_MCMC = Int(len_MCMC)
    burnin = Int(floor(0.5*len_MCMC))+2

    y    = y_all[2:end,:]
    ylag = y_all[1:(end-1),:]

    T, N = size(y)

    # unload HP
    valpha, vrho, nu_sigma, tau_sigma, a, b, nu_vdelta_alpha, tau_vdelta_alpha, nu_vdelta_rho, tau_vdelta_rho = lambda

    Vbeta = [valpha 0; 0 vrho]

    # unload homo parameters
    alpha, rho, sigma2, q, vdelta_alpha, vdelta_rho = theta

    # useful subfunctions
    crossprod(x) = x' * x

    # some shortcuts
    xx = [crossprod([ones(T,1) ylag[:,ii]]) for ii in 1:N]

    if data_version_id == 1 # different locations of nonzeros

        delta_alpha_draw  = zeros(len_MCMC+1, N)
        delta_rho_draw    = zeros(len_MCMC+1, N)
        z_alpha_draw      = zeros(len_MCMC+1, N)
        z_rho_draw        = zeros(len_MCMC+1, N)

        ### initialize parameters

        # (z,δ)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )

        z_alpha_draw[1,:] = rand(Bernoulli(q), N)
        z_rho_draw[1,:]   = rand(Bernoulli(q), N)

        zero_pos_alpha    = collect(1:N)[z_alpha_draw[1,:] .== 0]
        zero_pos_rho      = collect(1:N)[z_rho_draw[1,:] .== 0]

        delta_alpha_draw[1,:] = rand(Normal(0, sqrt(vdelta_alpha)), N)
        delta_alpha_draw[1,zero_pos_alpha] .= 0

        delta_rho_draw[1,:]   = [rand(Normal(0, sqrt( (vdelta_rho^-1 + sigma2^-1 * sum(ylag[t,ii]^2 for t in 1:T))^-1) )) for ii in 1:N]
        delta_rho_draw[1,zero_pos_rho] .= 0

        sum_in_var_beta = sum(xx[ii] for ii in 1:N) # sum_i^N (x_i'x_i)

        for i = 2:len_MCMC+1

            ###################################################
            ### BLOCK 4: draw (z,δ)
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

            # draw z_alpha

            # posterior mean and variance of delta_alpha_i
            post_var_delta_alpha  = (vdelta_alpha^-1 + T * sigma2^-1)^-1
            post_mean_delta_alpha = [post_var_delta_alpha * sigma2^-1 *
                                    sum(y[:,ii] .- alpha .- (rho .+ delta_rho_draw[i-1,ii]) * ylag[:,ii]) for ii in 1:N]

            K_alpha = q / (1-q) * (vdelta_alpha / post_var_delta_alpha)^(-0.5) *
                        exp.(0.5*post_mean_delta_alpha.^2 / post_var_delta_alpha)

            if sum(K_alpha .== Inf) != 0
                Inf_pos = collect(1:N)[K_alpha .== Inf]
                K_alpha[Inf_pos] .= 10^8
            end

            prob_alpha = K_alpha ./ (1 .+ K_alpha) # probability of model 1

            z_alpha_draw[i,:] = [rand(Bernoulli(x)) for x in prob_alpha]

            # draw δ_alpha
            zero_alpha_pos = collect(1:N)[z_alpha_draw[i,:] .== 0]

            delta_alpha_draw[i,:] = [rand(Normal(post_mean_delta_alpha[ii], sqrt(post_var_delta_alpha))) for ii in 1:N]

            if length(zero_alpha_pos) != 0
                delta_alpha_draw[i,zero_alpha_pos] .= 0
            end

            # draw z_rho

            # posterior mean and variance of delta_alpha_i
            post_var_delta_rho  = [ (vdelta_rho^-1 + sigma2^-1 * sum(ylag[t,ii]^2 for t in 1:T) )^-1 for ii in 1:N]
            post_mean_delta_rho = [ post_var_delta_rho[ii] * sigma2^-1 *
                                    sum( ylag[:,ii] .* (y[:,ii] .- alpha .- delta_alpha_draw[i,ii] - rho * ylag[:,ii])) for ii in 1:N ]

            K_rho = q / (1-q) * (vdelta_rho ./ post_var_delta_rho).^(-0.5) .* exp.(0.5*post_mean_delta_rho.^2 ./ post_var_delta_rho)

            if sum(K_rho .== Inf) != 0
                Inf_pos = collect(1:N)[K_rho .== Inf]
                K_rho[Inf_pos] .= 10^8
            end

            prob_rho = K_rho ./ (1 .+ K_rho) # probability of model 1

            z_rho_draw[i,:] = [rand(Bernoulli(x)) for x in prob_rho]

            # draw δ_rho
            zero_rho_pos = collect(1:N)[z_rho_draw[i,:] .== 0]

            delta_rho_draw[i,:] = [rand(Normal(post_mean_delta_rho[ii], sqrt(post_var_delta_rho[ii]))) for ii in 1:N]

            if length(zero_rho_pos) != 0
                delta_rho_draw[i,zero_rho_pos] .= 0
            end
        end

        # posteriod mean
        delta_alpha_hat  = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
        delta_rho_hat    = mean( delta_rho_draw[burnin:end,:], dims = 1)'
        z_alpha_hat      = mean( z_alpha_draw[burnin:end,:], dims = 1)'
        z_rho_hat        = mean( z_rho_draw[burnin:end,:], dims = 1)'

        post_mean = (delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat,
                     z_alpha_hat = z_alpha_hat, z_rho_hat = z_rho_hat)

        post_draw = (delta_alpha_draw = delta_alpha_draw[burnin:end,:], delta_rho_draw = delta_rho_draw[burnin:end,:],
                     z_alpha_draw = z_alpha_draw[burnin:end,:], z_rho_draw = z_rho_draw[burnin:end,:])

        return post_mean, post_draw


    elseif data_version_id == 2 # identical locations of nonzeros

        q_draw            = zeros(len_MCMC+1)
        beta_draw         = zeros(len_MCMC+1, 2) # β = [α, ρ]'
        vdelta_alpha_draw = zeros(len_MCMC+1)
        vdelta_rho_draw   = zeros(len_MCMC+1)
        delta_alpha_draw  = zeros(len_MCMC+1, N)
        delta_rho_draw    = zeros(len_MCMC+1, N)
        z_draw            = zeros(len_MCMC+1, N)
        sigma2_draw       = zeros(len_MCMC+1)

        ### initialize parameters
        # sigma2
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 4) )
        sigma2_draw[1]   = mean(InverseGamma(nu_sigma/2, tau_sigma/2))

        # q
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
        q_draw[1]  = mean(Beta(a,b))

        # variance of δ
        vdelta_alpha_draw[1] = rand(InverseGamma(nu_vdelta_alpha/2, tau_vdelta_alpha/2))
        vdelta_rho_draw[1]   = rand(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))

        # (z,δ)
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )

        z_draw[1,:] = rand(Bernoulli(q_draw[1]), N)

        zero_pos    = collect(1:N)[z_draw[1,:] .== 0]

        var_delta_alpha0  = (vdelta_alpha_draw[1]^-1 + N * sigma2_draw[1]^-1)^-1

        delta_alpha_draw[1,:] = rand(Normal(0,sqrt(var_delta_alpha0)), N)
        delta_alpha_draw[1,zero_pos] .= 0

        delta_rho_draw[1,:]   = [rand(Normal(0, sqrt( (vdelta_rho_draw[1]^-1 + sigma2_draw[1]^-1 * sum(ylag[t,ii]^2 for t in 1:T))^-1)) ) for ii in 1:N]
        delta_rho_draw[1,zero_pos] .= 0

        sum_in_var_beta = sum(xx[ii] for ii in 1:N) # sum_i^N (x_i'x_i)

        for i = 2:len_MCMC+1

            ###################################################
            ### BLOCK 1: draw β
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

            vbeta_post = ( inv(Vbeta) + sigma2_draw[i-1]^-1 * sum_in_var_beta )^-1 # posterior variance of β

            sum_in_mean_beta = sum([ones(T,1) ylag[:,ii]]' *
                                    (y[:,ii] - [ones(T,1) ylag[:,ii]] * [delta_alpha_draw[i-1,ii]; delta_rho_draw[i-1,ii]]) for ii in 1:N)
            mean_beta_post = vbeta_post * sigma2_draw[i-1]^-1 * sum_in_mean_beta

            beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

            alpha = beta_draw[i,1]
            rho   = beta_draw[i,2]

            ###################################################
            ### BLOCK 2: draw q
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

            psi       = sum( z_draw[i-1,:] )
            q_draw[i] = rand( Beta(a + psi, b + N - psi) )

            ###################################################
            ### BLOCK 3: draw variance for δ^α and δ^ρ
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

            # δ^α
            nu_vdelta_alpha_post  = nu_vdelta_alpha + psi
            tau_vdelta_alpha_post = tau_vdelta_alpha + sum(delta_alpha_draw[i-1, z_draw[i-1,:] .== 1].^2)

            vdelta_alpha_draw[i] = rand(InverseGamma(nu_vdelta_alpha_post/2, tau_vdelta_alpha_post/2))

            # δ^ρ
            nu_vdelta_rho_post  = nu_vdelta_rho + psi
            tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1, z_draw[i-1,:] .== 1].^2)

            vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

            ###################################################
            ### BLOCK 4: draw (z,δ)
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

            Vdelta = [vdelta_alpha_draw[i-1] 0; 0 vdelta_rho_draw[i-1]]

            # draw z
            post_var_delta  = [ ( Vdelta^-1 + sigma2_draw[i-1]^-1 * xx[ii] )^-1  for ii in 1:N ]

            post_mean_delta = [ post_var_delta[ii] * sigma2_draw[i-1]^-1 * [ones(T,1) ylag[:,ii]]' *
                                (y[:,ii] - [ones(T,1) ylag[:,ii]] * beta_draw[i,:])
                                for ii in 1:N ]

            K = q_draw[i] / (1-q_draw[i]) * [ ( det(Vdelta)/det(post_var_delta[ii]) )^(-0.5) *
                exp(0.5 * post_mean_delta[ii]' * post_var_delta[ii]^(-1) * post_mean_delta[ii]) for ii in 1:N ]

            prob = K ./ (1 .+ K) # probability of model 1

            z_draw[i,:] = [rand(Bernoulli(x)) for x in prob]

            # draw δ
            zero_pos = collect(1:N)[z_draw[i,:] .== 0]

            delta_draw = [ rand(MvNormal(post_mean_delta[ii], Symmetric(post_var_delta[ii]))) for ii in 1:N ]

            delta_alpha_draw[i,:] = [delta_draw[ii][1] for ii in 1:N]
            delta_rho_draw[i,:]   = [delta_draw[ii][2] for ii in 1:N]

            if length(zero_pos) != 0
                delta_alpha_draw[i,zero_pos] .= 0
                delta_rho_draw[i,zero_pos]   .= 0
            end

            ###################################################
            ### BLOCK 5: draw σ^2
            ###################################################

            Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 5) )

            nu_sigma_post = nu_sigma + N*T
            tau_sigma_post = tau_sigma + sum( crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * (beta_draw[i,:] +
                            [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N)

            sigma2_draw[i] = rand(InverseGamma(nu_sigma_post/2, tau_sigma_post/2))
            # print(i)
        end

        # posteriod mean
        alpha_hat        = mean( beta_draw[burnin:end,1] )
        rho_hat          = mean( beta_draw[burnin:end,2] )
        delta_alpha_hat  = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
        delta_rho_hat    = mean( delta_rho_draw[burnin:end,:], dims = 1)'
        z_hat            = mean( z_draw[burnin:end,:], dims = 1)'
        q_hat            = mean( q_draw[1:end] )
        vdelta_alpha_hat = mean( vdelta_alpha_draw[burnin:end] )
        vdelta_rho_hat   = mean( vdelta_rho_draw[burnin:end] )

        return alpha_hat, rho_hat, delta_alpha_hat, delta_rho_hat, vdelta_alpha_hat, vdelta_rho_hat, z_hat, q_hat

    end

end




## ################################################################################
# Full Homogeneity (q = 0)
function Homo_homsk(y_all, lambda, len_MCMC, id_simul)

    # len_MCMC = Int(10000)

    len_MCMC = Int(len_MCMC)
    burnin = Int(floor(0.5*len_MCMC))+2

    y    = y_all[2:end,:]
    ylag = y_all[1:(end-1),:]

    T, N = size(y)

    # unload HP
    valpha, vrho, nu_sigma, tau_sigma, a, b, nu_vdelta_alpha, tau_vdelta_alpha, nu_vdelta_rho, tau_vdelta_rho = lambda

    Vbeta = [valpha 0; 0 vrho]

    beta_draw      = zeros(len_MCMC+1, 2) # β = [α, ρ]'
    sigma2_draw    = zeros(len_MCMC+1)

    # initialize parameters
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
    sigma2_draw[1] = mean(InverseGamma(nu_sigma/2, tau_sigma/2))

    # useful subfunctions
    crossprod(x) = x' * x

    sum_in_var_beta = sum(crossprod([ones(T,1) ylag[:,ii]]) for ii in 1:N) # sum_i^N (x_i'x_i)

    for i = 2:len_MCMC+1

        ###################################################
        ### BLOCK 1: β
        ###################################################
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

        # draw β
        vbeta_post = ( inv(Vbeta) + sigma2_draw[i-1]^-1 * sum_in_var_beta)^-1 # posterior variance of β

        sum_in_mean_beta = sum([ones(T,1) ylag[:,ii]]' * y[:,ii] for ii in 1:N)

        mean_beta_post = vbeta_post * sigma2_draw[i-1]^-1 * sum_in_mean_beta

        beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

        ###################################################
        ### BLOCK 2: σ^2
        ###################################################
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

        # draw σ^2
        nu_sigma_post = nu_sigma + N*T
        tau_sigma_post = tau_sigma + sum( crossprod(y[:,ii] - [ones(T,1) ylag[:,ii]] * beta_draw[i,:]) for ii in 1:N)

        sigma2_draw[i] = rand(InverseGamma(nu_sigma_post/2, tau_sigma_post/2))
        # print(i)
    end

    # posteriod mean
    alpha_hat       = mean( beta_draw[burnin:end,1] )
    rho_hat         = mean( beta_draw[burnin:end,2] )
    sigma2_hat      = mean( sigma2_draw[burnin:end] )

    post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_hat = sigma2_hat)

    post_draw = (alpha_draw = beta_draw[burnin:end,1], rho_draw = beta_draw[burnin:end,2], sigma2_draw = sigma2_draw[burnin:end])

    return post_mean, post_draw
end









## ################################################################################
# Full Heterogeneity (q = 1)
function Hetero_homsk(y_all, lambda, len_MCMC, id_simul)
    # len_MCMC = nMCMC

    len_MCMC = Int(len_MCMC)
    burnin = Int(floor(0.5*len_MCMC))+2

    y    = y_all[2:end,:]
    ylag = y_all[1:(end-1),:]

    T, N = size(y)

    # unload HP
    valpha, vrho, nu_sigma, tau_sigma, a, b, nu_vdelta_alpha, tau_vdelta_alpha, nu_vdelta_rho, tau_vdelta_rho = lambda

    Vbeta = [valpha 0; 0 vrho]

    beta_draw         = zeros(len_MCMC+1, 2) # β = [α, ρ]'
    delta_alpha_draw  = zeros(len_MCMC+1, N)
    delta_rho_draw    = zeros(len_MCMC+1, N)
    vdelta_alpha_draw = zeros(len_MCMC+1)
    vdelta_rho_draw   = zeros(len_MCMC+1)
    sigma2_draw       = zeros(len_MCMC+1)

    # initialize parameters
    # σ^2
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 1) )
    sigma2_draw[1]    = mean(InverseGamma(nu_sigma/2, tau_sigma/2))

    # variance of δ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 2) )
    vdelta_alpha_draw[1] = mean(InverseGamma(nu_vdelta_alpha/2, tau_vdelta_alpha/2))
    vdelta_rho_draw[1]   = mean(InverseGamma(nu_vdelta_rho/2, tau_vdelta_rho/2))

    # δ
    Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + 1*10 + 3) )
    var_delta_alpha0  = (vdelta_alpha_draw[1]^-1 + T * sigma2_draw[1]^-1)^-1

    delta_alpha_draw[1,:] = rand(Normal(0, sqrt(var_delta_alpha0)), N)
    delta_rho_draw[1,:]   = [rand(Normal(0, sqrt( (vdelta_rho_draw[1]^-1 + sigma2_draw[1]^-1 * sum(ylag[t,ii]^2 for t in 1:T))^-1)) ) for ii in 1:N]

    # useful subfunctions
    crossprod(x) = x' * x

    # some shortcuts
    xx = [crossprod([ones(T,1) ylag[:,ii]]) for ii in 1:N]

    sum_in_var_beta = sum(crossprod([ones(T,1) ylag[:,ii]]) for ii in 1:N) # sum_i^N (x_i'x_i)

    for i = 2:len_MCMC+1

        ###################################################
        ### BLOCK 1: β
        ###################################################
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 1) )

        # draw β
        vbeta_post = ( inv(Vbeta) + sigma2_draw[i-1]^-1 * sum_in_var_beta)^-1 # posterior variance of β

        sum_in_mean_beta = sum([ones(T,1) ylag[:,ii]]' *
                                (y[:,ii] - [ones(T,1) ylag[:,ii]] * [delta_alpha_draw[i-1,ii]; delta_rho_draw[i-1,ii]]) for ii in 1:N)
        mean_beta_post = vbeta_post * sigma2_draw[i-1]^-1 * sum_in_mean_beta
        beta_draw[i,:] = rand(MvNormal(mean_beta_post, Symmetric(vbeta_post)))

        alpha = beta_draw[i,1]
        rho   = beta_draw[i,2]


        ###################################################
        ### BLOCK 2: draw variance for δ^α and δ^ρ
        ###################################################

        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 2) )

        # δ^α
        nu_vdelta_alpha_post  = nu_vdelta_alpha + N
        tau_vdelta_alpha_post = tau_vdelta_alpha + sum(delta_alpha_draw[i-1,:].^2)

        vdelta_alpha_draw[i] = rand(InverseGamma(nu_vdelta_alpha_post/2, tau_vdelta_alpha_post/2))

        # δ^ρ
        nu_vdelta_rho_post  = nu_vdelta_rho + N
        tau_vdelta_rho_post = tau_vdelta_rho + sum(delta_rho_draw[i-1,:].^2)

        vdelta_rho_draw[i] = rand(InverseGamma(nu_vdelta_rho_post/2, tau_vdelta_rho_post/2))

        ###################################################
        ### BLOCK 3: δ
        ###################################################
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 3) )

        Vdelta = [ vdelta_alpha_draw[i-1] 0; 0 vdelta_rho_draw[i-1] ]

        post_var_delta  = [ ( Vdelta^-1 + sigma2_draw[i-1]^-1 * xx[ii] )^-1  for ii in 1:N ]

        post_mean_delta = [ post_var_delta[ii] * sigma2_draw[i-1]^-1 * [ones(T,1) ylag[:,ii]]' *
                            (y[:,ii] - [ones(T,1) ylag[:,ii]] * beta_draw[i,:])
                            for ii in 1:N ]

        delta_draw = [ rand(MvNormal(post_mean_delta[ii], Symmetric(post_var_delta[ii]))) for ii in 1:N ]

        delta_alpha_draw[i,:] = [delta_draw[ii][1] for ii in 1:N]
        delta_rho_draw[i,:]   = [delta_draw[ii][2] for ii in 1:N]

        ###################################################
        ### BLOCK 4: σ^2
        ###################################################
        Random.seed!( Int(id_simul * 10^(floor(log(10,len_MCMC))+2) + i*10 + 4) )

        # draw σ^2
        nu_sigma_post  = nu_sigma + N*T
        tau_sigma_post = tau_sigma + sum( crossprod( y[:,ii] - [ones(T,1) ylag[:,ii]] *
                        (beta_draw[i,:] + [delta_alpha_draw[i,ii]; delta_rho_draw[i,ii]]) ) for ii in 1:N)

        sigma2_draw[i] = rand(InverseGamma(nu_sigma_post/2, tau_sigma_post/2))

    end

    # posteriod mean
    alpha_hat        = mean( beta_draw[burnin:end,1] )
    rho_hat          = mean( beta_draw[burnin:end,2] )
    sigma2_hat       = mean( sigma2_draw[burnin:end] )
    delta_alpha_hat  = mean( delta_alpha_draw[burnin:end,:], dims = 1)'
    delta_rho_hat    = mean( delta_rho_draw[burnin:end,:], dims = 1)'
    vdelta_alpha_hat = mean( vdelta_alpha_draw[burnin:end] )
    vdelta_rho_hat   = mean( vdelta_rho_draw[burnin:end] )

    post_mean = (alpha_hat = alpha_hat, rho_hat = rho_hat, sigma2_hat = sigma2_hat,
                 delta_alpha_hat = delta_alpha_hat, delta_rho_hat = delta_rho_hat,
                 vdelta_alpha_hat = vdelta_alpha_hat, vdelta_rho_hat = vdelta_rho_hat)

    post_draw = (alpha_draw = beta_draw[burnin:end,1], rho_draw = beta_draw[burnin:end,2], sigma2_draw = sigma2_draw[burnin:end],
                 delta_alpha_draw = delta_alpha_draw[burnin:end,:], delta_rho_draw = delta_rho_draw[burnin:end,:])

    return post_mean, post_draw

end

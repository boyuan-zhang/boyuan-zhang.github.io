========================================================================================================
# Replication Files for "Bayesian Estimation of Panel Models under Potentially Sparse Heterogeneity"
# by Hyungsik Roger Moon, Frank Schorfheide, and Boyuan Zhang
# For questions, please email Boyuan Zhang at zhang.boyuan@hotmail.com
# Version: 231019
========================================================================================================


========================================================================================================
# Monte Carlo Simualtion
========================================================================================================

/MonteCarlo/

- This folder contains code to perform MC simulation in Section 4.


----------------------------------------
# Homoskedastic design
----------------------------------------

/MonteCarlo/Homsk/

- This folder contains scripts for the homoskedastic design in Section 4.1.



# ------ #
Julia Scripts:

(1) functions_homsk.jl

- all subfunctions used to generate simulated data and estimate S&S, S&S(q=0), S&S(q=1), and SS-Oracle.



(2) main_homsk.jl

- Estimates the homoskedastic model with S&S, S&S(q=0), S&S(q=1), and SS-Oracle estimators. 



(3) main_homsk_parallel.jl

- The parallel version of (2)



(4) generate_latex_tab_homsk.jl

- Generates MSE for estimates of alpha and rho, and creates Table 2.



(5) main_homsk_plot.jl

- Generates histrograms of posterior mean of alpha and rho and posterior densities for q (Figure 1).





----------------------------------------
# Heteroskedastic design
----------------------------------------

/MonteCarlo/Hetsk/

- This folder contains scripts for the heteroskedastic design in Section 4.2.



# ------ #
Julia Scripts:

(1) functions_hetsk.jl

- All subfunctions used to generate simulated data and estimate S&S(hetsk), S&S(homosk), S&S(q=0), S&S(q=1), and SS-Oracle



(2) main_hetsk.jl

- Estimates the heteroskedastic model with S&S(hetsk), S&S(homosk), S&S(q=0), S&S(q=1), and SS-Oracle estimators.



(3) main_hetsk_parallel.jl

- The parallel version of (2)



(4) generate_latex_tab_hetsk.jl

- Generates MSE for estimates of alpha and rho, and creates Table 3



(5) main_hetsk_plot.jl

- Generates histrograms of posterior mean of alpha, rho, and sigma2, and posterior densities for q (Figure 2)





========================================================================================================
# Empirical Analysis
========================================================================================================


/Empirics/

- This folder contains code to prepare the dataset used in the empirical analysis and generate all tables and figures in Section 5.


---------------------------------------------------------
# Construct Samples
---------------------------------------------------------

/Empirics/Empirics_Data/

- This folder contains Rcode to generate both balanced and unbalanced datasets, csv files for the names of variable to be used in the analysis, and PCE series for inflation adjustment.



# ------ #
R Scripts:

(1) gen_PSID_data_68_97_balanced.R

- Generates balanced subsamples with T = 4, 6, 10, 15, 20, 25, 28
- For each T and tau, the subsample is saved in the folder /Empirics/Empirics_Data/data_balanced/, along with individuals' demographic information in a companion txt file. 



(2) gen_PSID_data_68_97_unbalanced.R

- Generates the unbalanced sample
- The dataset is saved in the folder /Empirics/Empirics_Data/data_unbalanced/, along with individuals' demographic information in a companion txt file. 






# ------ #
CVS files:

(1) famvars_68_97.csv

- IDs of all variables to be retrieve from family files.



(2) indvars_68_97.csv

- IDs of all variables to be retrieve from individual files.



(3) PCE.csv

- Historical PCE from https://fred.stlouisfed.org/series/PCE






---------------------------------------------------------
# Balanced Panel: Estimation
---------------------------------------------------------

/Empirics/Empirics_Balanced/


# ------ #

Subfunctions are store in functions_emp.jl

---
(1) M2

main_app_SS_M2_parallel.jl

- Generates estimates using the full model in eq (14) and (15)



---
(2) M2(homosk)

main_app_SS_M2_homosk_parallel.jl

- Generates estimates using the constrained model with delta-q = 0



---
(3) M2(RIP)

main_app_SS_M2_RIP_parallel.jl

- Generates estimates using the constrained model with q-alpha = q-rho = 0



---
(4) M2(HIP)

main_app_SS_M2_HIP_parallel.jl

- Generates estimates using the constrained model with q-alpha = q-rho = 1



---
(5) AR

main_app_AR_hetsk_parallel.jl

- Generates estimates for AR(1) model


---
The replication file does not include estimation results, including posterior draws, due to their large size (~6GB).
Instead, you can download them from the following Dropbox link: https://www.dropbox.com/scl/fo/brbtvstaa8kf7v678bh25/h?rlkey=vup4lfrruylazk78anmku9gud&dl=0



---------------------------------------------------------
# Balanced Panel: Tables/Figures in the paper
---------------------------------------------------------

---
(1) Table 5: Prior Distribution for θ

main_app_SS_M2_prior_simul.jl

- Generates prior draws and estimate 5%/95% percentiles.



---
(2) Figure 4: Posterior for Idiosyncratic Parameters, M2, T = 20

main_app_SS_M2_plot_paper.jl

- Generates figures using the output of (1a).



---
(3) Figure 5: Posterior Densities for the Sizes of α and ρ Group, M2, T = 20

main_app_SS_M2_core_size.jl

- Generates overlapping histograms (change t_smpl for different years)



---
(4) Table 6: Posterior Distribution for θ, M2, T = 20

main_app_SS_M2_estimate.jl



---
(5) Figure 6: Effect of α Heterogeneity on Income Inequality

main_app_Decomp_Income.jl



---
(6) Figure 7: Evolution of Average Idiosyncratic Volatility

main_app_SS_M2_plot_paper.jl



---
(7) Figure 8: Characteristics of Core Group vs. Deviators, B_{20,1991} Sample

main_app_demographic.jl

- Generates the histograms of demographic info for core and deviators.



---
(8) Figure 9: One-Step-Ahead Predictive Performance Relative to M2, T = 20, various samples τ

main_app_MSE.jl

- Calculates MSE for each sample.

main_app_LPS.jl

- Calculates LPS for each sample.

main_app_predictive_performance_plot.jl

- Generates MSE and LPS figures. It uses the output of above scripts.



---
(9) Figure 10: Individual Earnings Forecasts, B_{20,1991} sample

main_app_Multi_Fcst.jl

- Generates multi-step forecasts based estimates of M2 (first row), M2 w/ parameter uncertainty (second row) and AR (third row).



---
(10) Figure 11: Ratio of Predictive Interval Widths, B_{20,1991} sample

main_app_Multi_Fcst.jl

- Generates interval width ratio of 90% predictive interval at various H.








----------------------------------------
# Unbalanced Panel: Estimation
----------------------------------------

/Empirics/Empirics_Unbalanced/



# ------ #

Subfunctions are store in functions_emp_unbalanced.jl

---
(1) M2

main_app_SS_M2_unbalanced.jl

- Generates estimates for the full model in eq (14) and (15)



---
(2) M2(homosk)

main_app_SS_M2_homosk_unbalanced.jl

- Generates estimates for the constrained model with delta-q = 0



---
(3) M2(RIP)

main_app_SS_M2_RIP_unbalanced.jl

- Generates estimates for the constrained model with q-alpha = q-rho = 0



---
(4) M2(HIP)

main_app_SS_M2_HIP_unbalanced.jl

- Generates estimates for the constrained model with q-alpha = q-rho = 1



---
(5) AR

main_app_AR_hetsk_unbalanced.jl

- Generates estimates for AR(1) model



---
The replication file does not include estimation results, including posterior draws, due to their large size (~12GB).
Instead, you can download them from the following Dropbox link: https://www.dropbox.com/scl/fo/b86jgic64sjme2noqd582/h?rlkey=a8bi51xzv1lv0toxu1i8pjs7w&dl=0




---------------------------------------------------------
# Unbalanced Panel: Tables/Figures in the paper
---------------------------------------------------------

---
(1) Figure 3: Unbalanced Panel

main_app_unbalanced_desc_stats_plot.jl

- Generates units per period and periods in panel for unbalanced sample.



---
(2) Table 8: Posterior Distribution for θ, Unbalanced Panel

main_app_SS_M2_estimate_unbalanced.jl



---
(3) Figure 12: Posterior Idiosyncratic Parameters, Unbalanced Panel

main_app_SS_M2_unbalanced_plot.jl

- Generates histograms and plots for posterior median
